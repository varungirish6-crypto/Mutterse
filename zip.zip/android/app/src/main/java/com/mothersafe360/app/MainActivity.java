package com.mothersafe360.app;

import com.getcapacitor.BridgeActivity;

/**
 * Mutterse Main Activity
 * Extends BridgeActivity to let Capacitor manage plugins and permission contracts cleanly.
 */
public class MainActivity extends BridgeActivity {}
