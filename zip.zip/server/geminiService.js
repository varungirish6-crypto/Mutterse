import { GoogleGenAI, Type } from '@google/genai';
import fs from 'node:fs';
import path from 'node:path';

// Load .env if present and not already in environment
function loadEnvFile() {
  if (process.env.GEMINI_API_KEY) return;
  try {
    const envPath = path.resolve(process.cwd(), '.env');
    if (fs.existsSync(envPath)) {
      const content = fs.readFileSync(envPath, 'utf8');
      for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx !== -1) {
          const key = trimmed.slice(0, eqIdx).trim();
          const val = trimmed.slice(eqIdx + 1).trim().replace(/^['"]|['"]$/g, '');
          if (!process.env[key]) {
            process.env[key] = val;
          }
        }
      }
    }
  } catch (err) {
    console.warn('[GeminiService] Note: Could not read .env file:', err.message);
  }
}

loadEnvFile();

// Supported current Gemini models (fastest lowest-latency first, with reliable fallbacks)
const MODELS_TO_TRY = ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.8-flash'];

export function getGeminiClient() {
  loadEnvFile();
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is not configured. Please set it in your .env file.');
  }
  return new GoogleGenAI({ apiKey });
}

function withTimeout(promise, ms = 20000, label = 'Operation') {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms)
    ),
  ]);
}

/**
 * Execute Gemini generation with model fallback
 */
async function generateWithFallback(client, contents, extraConfig = {}) {
  let lastError = null;

  for (let i = 0; i < MODELS_TO_TRY.length; i++) {
    const model = MODELS_TO_TRY[i];
    const timeoutMs = 20000;
    try {
      const config = { ...extraConfig };
      const call = client.models.generateContent({
        model,
        contents,
        config: Object.keys(config).length > 0 ? config : undefined,
      });

      const response = await withTimeout(call, timeoutMs, `Model ${model}`);
      if (response && response.text) {
        return { response, modelUsed: model };
      }
    } catch (err) {
      console.warn(`[GeminiService] Generation attempt on ${model} failed:`, err.message || err);
      lastError = err;
      continue;
    }
  }

  throw lastError || new Error('All Gemini models failed to respond.');
}

/**
 * Clean and parse JSON response from Gemini
 */
function parseJsonFromText(text) {
  let cleaned = text.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```[a-zA-Z]*\n?/, '').replace(/\n?```$/, '');
  }
  return JSON.parse(cleaned.trim());
}

/**
 * Analyzes medicine packaging / label image using Gemini Vision OCR
 */
export async function analyzeMedicineImage(base64Data, mimeType = 'image/jpeg') {
  const client = getGeminiClient();

  let rawBase64 = base64Data;
  let detectedMime = mimeType;
  if (base64Data.includes(',')) {
    const parts = base64Data.split(',');
    rawBase64 = parts[1];
    const mimeMatch = parts[0].match(/:(.*?);/);
    if (mimeMatch && mimeMatch[1]) {
      detectedMime = mimeMatch[1];
    }
  }

  const prompt = `You are an expert maternal healthcare pharmaceutical vision assistant.
Examine this image carefully and evaluate whether it contains a legible medicine, vitamin, prescription, or dietary supplement label.

CRITICAL INSTRUCTIONS:
1. IDENTIFICATION ACCURACY:
   - Identify the medicine ONLY when the image provides clear, legible evidence.
   - If the image is NOT a medicine (e.g. food, scenery, object, person), or if the label is too blurry, truncated, or dark to read reliably:
     * Set "title" to "Unidentified / Non-Medicine Image" or "Unidentified Medicine"
     * Set "isLegible" to false
     * In "confidenceNotes", clearly state that the medicine could not be identified reliably from the image.
     * NEVER guess the medicine name, dosage, strength, or active ingredients.
2. WHEN IDENTIFIED:
   - Extract the visible medicine title, potency/strength, active ingredients, label dosage directions, and packaging warnings.
   - In "confidenceNotes", provide general maternal safety context: what the medicine is used for, general pregnancy safety considerations, precautions, and when to seek advice.
   - Set "isLegible" to true.
3. SAFETY BOUNDARIES:
   - Do NOT claim that any medicine is completely risk-free.
   - Do NOT make unsupported claims about autism, ADHD, or other developmental outcomes.
   - Always state that medication decisions must be confirmed with an obstetrician, doctor, or pharmacist.
4. Return clean structured JSON conforming to the schema.`;

  const contents = [
    {
      role: 'user',
      parts: [
        { text: prompt },
        {
          inlineData: {
            mimeType: detectedMime,
            data: rawBase64,
          },
        },
      ],
    },
  ];

  const config = {
    responseMimeType: 'application/json',
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        title: {
          type: Type.STRING,
          description: 'Visible medicine or supplement name (or Unidentified Medicine if illegible/non-medicine)',
        },
        strength: {
          type: Type.STRING,
          description: 'Visible strength e.g. 500mg, 100mcg (or Not clearly visible on label)',
        },
        ingredients: {
          type: Type.STRING,
          description: 'Visible active ingredients with quantities if printed (or Not clearly visible on label)',
        },
        dosage: {
          type: Type.STRING,
          description: 'Visible label directions or intake instructions (or Not specified on visible label)',
        },
        warnings: {
          type: Type.STRING,
          description: 'Visible warnings, storage instructions, or manufacturer details printed on label',
        },
        isLegible: {
          type: Type.BOOLEAN,
          description: 'True if packaging text was clearly legible, false if blurry, obscured, or not a medicine',
        },
        confidenceNotes: {
          type: Type.STRING,
          description: 'Notes on clarity and clinical pregnancy overview (or clear statement if unidentified)',
        },
        disclaimer: {
          type: Type.STRING,
          description: 'Mandatory clinical disclaimer notice',
        },
      },
      required: ['title', 'strength', 'ingredients', 'dosage', 'warnings', 'isLegible', 'confidenceNotes', 'disclaimer'],
    },
  };

  const { response, modelUsed } = await generateWithFallback(client, contents, config);
  const text = response.text || '{}';

  try {
    const parsed = parseJsonFromText(text);
    parsed.disclaimer = 'This extraction reflects visible packaging text and general clinical guidance. It does NOT replace professional medical advice. Always consult your obstetrician, midwife, or doctor before taking any medication during pregnancy.';
    return {
      success: true,
      data: parsed,
      modelUsed,
    };
  } catch {
    return {
      success: true,
      data: {
        title: 'Scanned Packaging Details',
        strength: 'See label text',
        ingredients: text,
        dosage: 'Consult physician or pharmacist',
        warnings: 'Packaging scanned via Gemini.',
        isLegible: true,
        confidenceNotes: 'Raw OCR extracted from image.',
        disclaimer: 'This extraction reflects visible packaging text and general clinical guidance. It does NOT replace professional medical advice. Always consult your obstetrician, midwife, or doctor before taking any medication during pregnancy.',
      },
      modelUsed,
    };
  }
}

/**
 * Chat assistant for maternal healthcare, medicine inquiries, and image analysis
 */
export async function chatAboutMedicine({
  message,
  history = [],
  medicineContext = null,
  image = null,
  mimeType = 'image/jpeg',
}) {
  const client = getGeminiClient();

  const systemInstruction = `You are "Mutterse AI", an evidence-based clinical maternal-care AI guide within the Mutterse app.

CORE CLINICAL INSTRUCTIONS & RESPONSE STYLE:
1. When asked about any medicine or supplement during pregnancy, provide a concise, balanced, reassuring paragraph covering:
   - What the medicine is used for.
   - General pregnancy safety information based on established clinical guidance (e.g. ACOG, RCOG, FDA).
   - Important precautions (e.g. lowest effective dose, shortest necessary duration, avoiding unauthorized switches to NSAIDs such as ibuprofen unless clinician-advised).
   - When professional medical advice is needed (e.g. high fever, severe pain, persistent symptoms).
   - A concluding statement that this information is for educational purposes and does not replace consultation with an obstetrician, midwife, or doctor.

2. EXAMPLE OF TARGET STYLE:
   "Paracetamol is generally considered a first-choice option for treating pain or fever during pregnancy when used as directed. It is recommended to use the lowest effective dose for the shortest necessary duration and to consult an obstetrician, midwife, or other healthcare professional before taking medication. Avoid switching to medicines such as ibuprofen unless specifically advised by a clinician. If you have a high fever, severe pain, or persistent symptoms, seek medical guidance. This information is for general educational purposes and does not replace professional medical advice."

3. SAFETY BOUNDARIES:
   - Identify a medicine only when there is enough evidence. If a medicine or uploaded image cannot be identified reliably, CLEARLY state that it could not be identified.
   - NEVER guess or hallucinate a medicine name, dosage, or active ingredients.
   - Do NOT claim that any medicine is completely risk-free.
   - Do NOT make unsupported claims about autism, ADHD, or other developmental outcomes.
   - For non-medicine questions (e.g. nutrition, fetal kicks, sleep, hydration, pregnancy symptoms), offer warm, evidence-based guidance while advising consultation with healthcare professionals for urgent or severe symptoms.
   - Keep answers concise, empathetic, and easily readable (1-2 clear paragraphs).`;

  let contextPrompt = '';
  if (medicineContext && (medicineContext.title || medicineContext.ingredients)) {
    contextPrompt = `[SCANNED MEDICINE CONTEXT:
Name: ${medicineContext.title || 'Unidentified'}
Strength: ${medicineContext.strength || 'Not specified'}
Ingredients: ${medicineContext.ingredients || 'Not specified'}
Label Directions: ${medicineContext.dosage || 'Not specified'}
Warnings on Label: ${medicineContext.warnings || 'Not specified'}
Image Confidence / Clarity: ${medicineContext.confidenceNotes || 'Not specified'}]

`;
  }

  // Construct conversation contents
  const contents = [];

  // Add conversation history (limited to last 8 turns)
  const recentHistory = history.slice(-8);
  for (const h of recentHistory) {
    if (h.sender === 'user') {
      contents.push({ role: 'user', parts: [{ text: h.text }] });
    } else if (h.sender === 'ai' || h.sender === 'midwife' || h.sender === 'model') {
      contents.push({ role: 'model', parts: [{ text: h.text }] });
    }
  }

  // Current turn
  const userTurnParts = [];

  // If an image was attached in the chat
  if (image) {
    let rawBase64 = image;
    let detectedMime = mimeType;
    if (image.includes(',')) {
      const parts = image.split(',');
      rawBase64 = parts[1];
      const mimeMatch = parts[0].match(/:(.*?);/);
      if (mimeMatch && mimeMatch[1]) detectedMime = mimeMatch[1];
    }
    userTurnParts.push({
      inlineData: {
        mimeType: detectedMime,
        data: rawBase64,
      },
    });
  }

  const promptText = contents.length === 0 && contextPrompt
    ? `${contextPrompt}User Question: ${message || 'Please examine this image and provide maternal clinical guidance.'}`
    : message || 'Please examine this image and provide maternal clinical guidance.';

  userTurnParts.push({ text: promptText });
  contents.push({ role: 'user', parts: userTurnParts });

  const { response, modelUsed } = await generateWithFallback(client, contents, { systemInstruction });

  return {
    reply: response.text || 'I am unable to generate a response at the moment. Please consult your obstetrician or pharmacist.',
    modelUsed,
  };
}
