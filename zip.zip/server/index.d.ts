import type { IncomingMessage, ServerResponse } from 'node:http';

export function handleGeminiApiRequest(
  req: IncomingMessage,
  res: ServerResponse
): Promise<boolean>;
