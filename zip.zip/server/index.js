import http from 'node:http';
import { analyzeMedicineImage, chatAboutMedicine, getGeminiClient } from './geminiService.js';

const PORT = process.env.PORT || 3001;

function setCorsHeaders(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function sendJson(res, statusCode, data) {
  setCorsHeaders(res);
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

function parseJsonBody(req, limit = 25 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let body = '';
    let bytes = 0;
    req.on('data', (chunk) => {
      body += chunk;
      bytes += chunk.length;
      if (bytes > limit) {
        reject(new Error('Payload too large. Maximum size is 25MB.'));
      }
    });
    req.on('end', () => {
      try {
        if (!body) resolve({});
        else resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON payload: ' + err.message));
      }
    });
    req.on('error', reject);
  });
}

export async function handleGeminiApiRequest(req, res) {
  setCorsHeaders(res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return true;
  }

  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname.replace(/\/$/, '') || '/';

  // Health check
  if (pathname === '/api/gemini/health') {
    if (req.method !== 'GET') {
      sendJson(res, 405, { success: false, error: `Method ${req.method} not allowed for /api/gemini/health` });
      return true;
    }
    try {
      getGeminiClient();
      sendJson(res, 200, {
        status: 'ok',
        service: 'Mutterse Gemini AI Proxy',
        configured: true,
      });
    } catch (err) {
      sendJson(res, 503, {
        status: 'unconfigured',
        service: 'Mutterse Gemini AI Proxy',
        configured: false,
        error: err.message,
      });
    }
    return true;
  }

  // Scan medicine image
  if (pathname === '/api/gemini/scan') {
    if (req.method !== 'POST') {
      sendJson(res, 405, { success: false, error: `Method ${req.method} not allowed for /api/gemini/scan` });
      return true;
    }
    try {
      const body = await parseJsonBody(req);
      const { image, mimeType } = body;
      if (!image) {
        sendJson(res, 400, { success: false, error: 'Missing image data in request payload.' });
        return true;
      }
      const result = await analyzeMedicineImage(image, mimeType || 'image/jpeg');
      sendJson(res, 200, result);
    } catch (err) {
      console.error('[GeminiProxy] Scan error:', err);
      let errorMsg = err.message || 'Failed to analyze medicine image with Gemini.';
      try {
        const parsed = JSON.parse(errorMsg);
        if (parsed.error?.message) errorMsg = parsed.error.message;
      } catch {}
      sendJson(res, 500, {
        success: false,
        error: errorMsg,
      });
    }
    return true;
  }

  // Chat with medicine context
  if (pathname === '/api/gemini/chat') {
    if (req.method !== 'POST') {
      sendJson(res, 405, { success: false, error: `Method ${req.method} not allowed for /api/gemini/chat` });
      return true;
    }
    try {
      const body = await parseJsonBody(req);
      const { message, history, medicineContext, image, mimeType } = body;
      if ((!message || typeof message !== 'string') && !image) {
        sendJson(res, 400, { success: false, error: 'Missing message or image in request payload.' });
        return true;
      }
      const result = await chatAboutMedicine({
        message: message || '',
        history,
        medicineContext,
        image,
        mimeType,
      });
      sendJson(res, 200, { success: true, ...result });
    } catch (err) {
      console.error('[GeminiProxy] Chat error:', err);
      let errorMsg = err.message || 'Failed to process chat query with Gemini.';
      try {
        const parsed = JSON.parse(errorMsg);
        if (parsed.error?.message) errorMsg = parsed.error.message;
      } catch {}
      sendJson(res, 500, {
        success: false,
        error: errorMsg,
      });
    }
    return true;
  }

  // Any unmatched /api/gemini path returns 404 JSON, never HTML
  if (pathname.startsWith('/api/gemini')) {
    sendJson(res, 404, { success: false, error: `Endpoint not found: ${pathname}` });
    return true;
  }

  return false;
}

// If executed directly via `node server/index.js`
if (process.argv[1] && process.argv[1].endsWith('server/index.js') || process.argv[1]?.endsWith('server\\index.js')) {
  const server = http.createServer(async (req, res) => {
    const handled = await handleGeminiApiRequest(req, res);
    if (!handled) {
      sendJson(res, 404, { error: 'Not found' });
    }
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Mutterse] Gemini AI Proxy Server running at http://0.0.0.0:${PORT} (LAN accessible)`);
  });
}
