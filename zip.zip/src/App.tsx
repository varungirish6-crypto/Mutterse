import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { BottomNav } from './components/layout/BottomNav';
import { DesktopNav } from './components/layout/DesktopNav';
import { HomeScreen } from './components/home/HomeScreen';
import { AIScanScreen } from './components/scanner/AIScanScreen';
import { MyCareScreen } from './components/care/MyCareScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';
import ProfileSetupScreen from './components/profile/ProfileSetupScreen';
import LoginPage from './components/auth/LoginPage';
import { ToastContainer } from './components/common/UI';
import { initNotificationListeners } from './services/notificationService';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Capacitor } from '@capacitor/core';

const MainApp: React.FC = () => {
  const { activeTab, setActiveTab, isSetupMode, toasts, removeToast, showToast } = useApp();

  useEffect(() => {
    const cleanup = initNotificationListeners(
      (_reminderId) => {
        setActiveTab('care');
      },
      (title, body) => {
        showToast('info', `🔔 ${title}: ${body}`);
      }
    );
    return cleanup;
  }, [setActiveTab, showToast]);

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    StatusBar.setStyle({ style: Style.Light }).catch(() => {});
    StatusBar.setBackgroundColor({ color: '#ffffff' }).catch(() => {});

    const backListener = CapApp.addListener('backButton', () => {
      if (activeTab !== 'home') {
        setActiveTab('home');
      } else {
        CapApp.exitApp();
      }
    });

    return () => {
      backListener.then((handle) => handle.remove()).catch(() => {});
    };
  }, [activeTab, setActiveTab]);

  if (isSetupMode) {
    return (
      <div className="app-wallpaper-bg min-h-screen text-[#181c1b] flex flex-col justify-center">
        <ProfileSetupScreen />
        <ToastContainer toasts={toasts} onRemove={removeToast} />
      </div>
    );
  }

  return (
    <div className="app-wallpaper-bg min-h-[100dvh] text-[#181c1b] flex flex-col w-full overflow-x-hidden selection:bg-[#c6e8cf] selection:text-[#062919]">
      {/* Desktop Responsive Top Navigation */}
      <DesktopNav />

      {/* Active Tab Screen */}
      <main className="flex-1 w-full max-w-2xl mx-auto overflow-x-hidden md:px-4 md:py-4">
        <div className={activeTab === 'home' ? 'block' : 'hidden'}>
          <HomeScreen />
        </div>
        <div className={activeTab === 'scan' ? 'block' : 'hidden'}>
          <AIScanScreen />
        </div>
        <div className={activeTab === 'care' ? 'block' : 'hidden'}>
          <MyCareScreen />
        </div>
        <div className={activeTab === 'settings' ? 'block' : 'hidden'}>
          <SettingsScreen />
        </div>
      </main>

      {/* Mobile-first Persistent Bottom Navigation (Hidden on desktop) */}
      <div className="md:hidden">
        <BottomNav />
      </div>

      {/* Global Toast Notifications */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
};

const AppShell: React.FC = () => {
  const { isAuthenticated, toasts, removeToast } = useApp();

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    if (!isAuthenticated) {
      const backListener = CapApp.addListener('backButton', () => {
        CapApp.exitApp();
      });
      return () => {
        backListener.then((handle) => handle.remove()).catch(() => {});
      };
    }
  }, [isAuthenticated]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#f7faf7] flex flex-col justify-center">
        <LoginPage />
        <ToastContainer toasts={toasts} onRemove={removeToast} />
      </div>
    );
  }

  return <MainApp />;
};

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
