import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import authBg from '../../assets/auth-bg.jpg';
import './LoginPage.css';

export default function LoginPage() {
  const { login, signup, resetPassword, loginWithGoogle, loginAsDemo, showToast } = useApp();

  const [mode, setMode] = useState<'landing' | 'signin' | 'signup'>('landing');
  const [identifier, setIdentifier] = useState('elena.vance@mutterse.health');
  const [password, setPassword] = useState('maternalCare2024');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (mode === 'signup') {
      if (!name.trim()) {
        setErrorMessage('Please enter your full name.');
        return;
      }
      if (!identifier.trim()) {
        setErrorMessage('Please enter an email or phone number.');
        return;
      }
      if (password.length < 6) {
        setErrorMessage('Password must be at least 6 characters.');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMessage('Passwords do not match.');
        return;
      }

      setIsLoading(true);
      try {
        const result = await signup(name, identifier, password);
        if (!result.success) {
          setErrorMessage(result.message || 'Signup failed.');
        }
      } catch {
        setErrorMessage('An unexpected error occurred during signup.');
      } finally {
        setIsLoading(false);
      }
    } else {
      if (!identifier.trim()) {
        setErrorMessage('Please enter your email or phone number.');
        return;
      }
      if (!password.trim()) {
        setErrorMessage('Please enter your password.');
        return;
      }

      setIsLoading(true);
      try {
        const result = await login(identifier, password);
        if (!result.success) {
          setErrorMessage(result.message || 'Login failed. Please check your credentials.');
        }
      } catch {
        setErrorMessage('An unexpected error occurred during sign in.');
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleGoogleAuth = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await loginWithGoogle();
      if (!res.success) {
        setErrorMessage(res.message || 'Google sign-in could not be completed.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to initialize Google sign-in.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) {
      showToast('warning', 'Please enter your account email.');
      return;
    }
    setIsLoading(true);
    try {
      const res = await resetPassword(forgotEmail.trim());
      if (res.success) {
        setForgotSent(true);
        setTimeout(() => {
          setShowForgotModal(false);
          setForgotSent(false);
          setForgotEmail('');
        }, 3000);
      } else {
        showToast('error', res.message || 'Could not send recovery link.');
      }
    } catch {
      showToast('error', 'Failed to send recovery link.');
    } finally {
      setIsLoading(false);
    }
  };

  const resetToLanding = () => {
    setMode('landing');
    setErrorMessage(null);
  };

  return (
    <div className="auth-root">
      {/* Full-screen background image */}
      <img
        src={authBg}
        alt=""
        aria-hidden="true"
        className="auth-bg-img"
      />

      {/* Dark gradient overlay for legibility */}
      <div className="auth-overlay" />

      {/* ── LANDING VIEW: four buttons ── */}
      {mode === 'landing' && (
        <div className="auth-landing">
          {/* App brand mark */}
          <div className="auth-brand">
            <div className="auth-brand-icon">
              <span
                className="material-symbols-outlined"
                style={{ fontSize: 36, fontVariationSettings: "'FILL' 1" }}
              >
                spa
              </span>
            </div>
            <h1 className="auth-brand-name">Mutterse</h1>
            <p className="auth-brand-tagline">Gentle, intelligent maternal care</p>
          </div>

          {/* Action buttons */}
          <div className="auth-btn-group">
            {/* Login */}
            <button
              type="button"
              className="auth-btn auth-btn--primary"
              onClick={() => setMode('signin')}
            >
              <span className="material-symbols-outlined auth-btn-icon">login</span>
              Login
            </button>

            {/* Continue with Google */}
            <button
              type="button"
              className="auth-btn auth-btn--google"
              onClick={handleGoogleAuth}
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="auth-spinner" />
              ) : (
                <svg aria-hidden="true" className="auth-google-icon" viewBox="0 0 24 24">
                  <path d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z" fill="#4285F4" />
                  <path d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z" fill="#34A853" />
                  <path d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z" fill="#FBBC05" />
                  <path d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" fill="#EA4335" />
                </svg>
              )}
              Continue with Google
            </button>

            {/* Create Account */}
            <button
              type="button"
              className="auth-btn auth-btn--outline"
              onClick={() => setMode('signup')}
            >
              <span className="material-symbols-outlined auth-btn-icon">person_add</span>
              Create Account
            </button>

            {/* Continue as Demo */}
            <button
              type="button"
              className="auth-btn auth-btn--ghost"
              onClick={loginAsDemo}
            >
              <span className="material-symbols-outlined auth-btn-icon">clinical_notes</span>
              Continue as Demo
            </button>
          </div>

          {/* Privacy badge */}
          <div className="auth-privacy">
            <span className="material-symbols-outlined" style={{ fontSize: 14 }}>verified_user</span>
            <span>Encrypted &amp; HIPAA-compliant</span>
          </div>
        </div>
      )}

      {/* ── SIGN-IN / SIGN-UP FORM VIEW ── */}
      {(mode === 'signin' || mode === 'signup') && (
        <div className="auth-form-view">
          {/* Back button */}
          <button
            type="button"
            className="auth-back-btn"
            onClick={resetToLanding}
            aria-label="Back"
          >
            <span className="material-symbols-outlined" style={{ fontSize: 22 }}>arrow_back</span>
          </button>

          {/* Scrollable form sheet */}
          <div className="auth-sheet">
            {/* Header */}
            <div className="auth-sheet-header">
              <h2 className="auth-sheet-title">
                {mode === 'signin' ? 'Welcome back, mama' : 'Create your sanctuary'}
              </h2>
              <p className="auth-sheet-subtitle">
                {mode === 'signin'
                  ? 'Sign in to continue your care journey'
                  : 'Personalized guidance designed for your journey'}
              </p>
            </div>

            {/* Error alert */}
            {errorMessage && (
              <div className="auth-error">
                <span className="material-symbols-outlined" style={{ fontSize: 18 }}>error</span>
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Form */}
            <form className="auth-form" onSubmit={handleSubmit}>
              {/* Name — signup only */}
              {mode === 'signup' && (
                <div className="auth-field">
                  <label className="auth-label" htmlFor="name">Mother's full name</label>
                  <div className="auth-input-wrap">
                    <span className="material-symbols-outlined auth-input-icon">person</span>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Elena Vance"
                      className="auth-input"
                    />
                  </div>
                </div>
              )}

              {/* Email / Phone */}
              <div className="auth-field">
                <label className="auth-label" htmlFor="identifier">Email or phone number</label>
                <div className="auth-input-wrap">
                  <span className="material-symbols-outlined auth-input-icon">alternate_email</span>
                  <input
                    id="identifier"
                    name="identifier"
                    type="text"
                    required
                    autoComplete="username"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="name@example.com"
                    className="auth-input"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="auth-field">
                <div className="auth-label-row">
                  <label className="auth-label" htmlFor="password">Password</label>
                  {mode === 'signin' && (
                    <button
                      type="button"
                      className="auth-forgot-link"
                      onClick={() => setShowForgotModal(true)}
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="auth-input-wrap">
                  <span className="material-symbols-outlined auth-input-icon">lock</span>
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="auth-input auth-input--padded-r"
                  />
                  <button
                    type="button"
                    aria-label="Toggle password visibility"
                    onClick={() => setShowPassword(!showPassword)}
                    className="auth-eye-btn"
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: 20 }}>
                      {showPassword ? 'visibility_off' : 'visibility'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Confirm Password — signup only */}
              {mode === 'signup' && (
                <div className="auth-field">
                  <label className="auth-label" htmlFor="confirmPassword">Confirm Password</label>
                  <div className="auth-input-wrap">
                    <span className="material-symbols-outlined auth-input-icon">lock_clock</span>
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="auth-input auth-input--padded-r"
                    />
                    <button
                      type="button"
                      aria-label="Toggle password visibility"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="auth-eye-btn"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: 20 }}>
                        {showConfirmPassword ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className="auth-btn auth-btn--primary auth-btn--full"
              >
                {isLoading ? (
                  <span className="auth-spinner" />
                ) : (
                  <>
                    <span>{mode === 'signin' ? 'Sign In' : 'Create Sanctuary'}</span>
                    <span className="material-symbols-outlined auth-btn-icon">arrow_forward</span>
                  </>
                )}
              </button>

              {/* Divider & Google Sign-In */}
              <div className="auth-divider">
                <span>or</span>
              </div>

              <button
                type="button"
                className="auth-btn auth-btn--google-sheet"
                onClick={handleGoogleAuth}
                disabled={isLoading}
              >
                <svg aria-hidden="true" className="auth-google-icon" viewBox="0 0 24 24">
                  <path d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z" fill="#4285F4" />
                  <path d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z" fill="#34A853" />
                  <path d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z" fill="#FBBC05" />
                  <path d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" fill="#EA4335" />
                </svg>
                <span>Continue with Google</span>
              </button>
            </form>

            {/* Switch mode */}
            <p className="auth-switch">
              {mode === 'signin' ? "Don't have an account?" : 'Already have an account?'}
              <button
                type="button"
                className="auth-switch-btn"
                onClick={() => {
                  setMode(mode === 'signin' ? 'signup' : 'signin');
                  setErrorMessage(null);
                }}
              >
                {mode === 'signin' ? 'Create account' : 'Sign in'}
              </button>
            </p>
          </div>
        </div>
      )}

      {/* ── FORGOT PASSWORD MODAL ── */}
      {showForgotModal && (
        <div className="auth-modal-backdrop">
          <div className="auth-modal">
            <div className="auth-modal-header">
              <div className="auth-modal-title-row">
                <span className="material-symbols-outlined" style={{ color: '#1e3f2e' }}>lock_reset</span>
                <h3 className="auth-modal-title">Password Recovery</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="auth-modal-close"
              >
                <span className="material-symbols-outlined" style={{ fontSize: 20 }}>close</span>
              </button>
            </div>

            {forgotSent ? (
              <div className="auth-modal-success">
                <span className="material-symbols-outlined" style={{ fontSize: 40, color: '#476551' }}>mark_email_read</span>
                <p className="auth-modal-success-title">Reset instructions sent!</p>
                <p className="auth-modal-success-sub">Check your inbox for a secure verification code.</p>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="auth-modal-form">
                <p className="auth-modal-body">
                  Enter your registered email address and we will dispatch clinical account recovery instructions.
                </p>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  className="auth-modal-input"
                />
                <button type="submit" className="auth-modal-submit">
                  Send Recovery Link
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
