import React from 'react';
import { useApp } from '../../context/AppContext';

export const BioTrackScreen: React.FC = () => {
  const { routine, profile, logWater, logPelvicFloor } = useApp();

  return (
    <div className="w-full max-w-lg min-h-screen relative flex flex-col pb-28 mx-auto px-5 pt-4 space-y-4">
      <header className="pb-2 border-b border-white/40">
        <h1 className="font-serif text-2xl font-bold text-[#062919]">BioTrack &amp; Maternal Vitals</h1>
        <p className="text-xs text-[#424843] mt-0.5">Clinical logs for Week {profile.gestationalWeek}</p>
      </header>

      {/* Blood Pressure Summary */}
      <section className="lg-card rounded-3xl p-5 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#476551] uppercase tracking-wider">Blood Pressure Monitoring</span>
          <span className="text-xs font-bold text-[#062919] bg-[#c6e8cf] px-2.5 py-0.5 rounded-xl">
            {routine.bloodPressure}
          </span>
        </div>
        <p className="text-xs text-[#424843] leading-relaxed">Within standard normotensive range for Second Trimester.</p>
        <div className="pt-2 border-t border-white/50 space-y-1.5">
          {routine.bpHistory.map((bp) => (
            <div key={bp.id} className="flex items-center justify-between text-xs text-[#181c1b]">
              <span>
                {bp.date} ({bp.time})
              </span>
              <span className="font-bold text-[#062919]">
                {bp.bp} · Pulse {bp.pulse} bpm
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Hydration & Pelvic Floor */}
      <section className="grid grid-cols-2 gap-3">
        <div className="lg-card rounded-3xl p-4.5">
          <span className="text-xs text-[#476551] font-bold block mb-1">Hydration</span>
          <span className="text-2xl font-serif font-bold text-[#062919]">
            {routine.hydrationCount} / {routine.hydrationTarget}
          </span>
          <p className="text-xs font-medium text-[#424843] mt-1">Glasses of water today</p>
          <button
            type="button"
            onClick={logWater}
            className="mt-3 w-full py-2 bg-[#c6e8cf] text-[#062919] text-xs font-bold rounded-2xl hover:bg-[#c9ebd2] active:scale-95 transition-all cursor-pointer"
          >
            + Log Glass
          </button>
        </div>

        <div className="lg-card rounded-3xl p-4.5">
          <span className="text-xs text-[#476551] font-bold block mb-1">Pelvic Floor</span>
          <span className="text-2xl font-serif font-bold text-[#062919]">
            {routine.pelvicFloorMinutes}m
          </span>
          <p className="text-xs font-medium text-[#424843] mt-1">Kegel exercises logged</p>
          <button
            type="button"
            onClick={() => logPelvicFloor(5)}
            className="mt-3 w-full py-2 bg-[#c6e8cf] text-[#062919] text-xs font-bold rounded-2xl hover:bg-[#c9ebd2] active:scale-95 transition-all cursor-pointer"
          >
            + 5 Minutes
          </button>
        </div>
      </section>

      {/* Fetal Movement Sessions */}
      <section className="lg-card rounded-3xl p-5 space-y-2">
        <span className="text-xs font-bold text-[#476551] uppercase tracking-wider">Fetal Kick Count History</span>
        <div className="space-y-1.5 pt-1">
          {routine.kicks.map((k) => (
            <div key={k.id} className="p-3 rounded-2xl lg-surface flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#062919]">{k.count} Kicks</span>
                <span className="text-[#424843] ml-2 font-medium">({k.duration})</span>
                <p className="text-xs text-[#525a53] mt-0.5">{k.notes}</p>
              </div>
              <span className="text-xs font-semibold text-[#476551]">{k.time}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default BioTrackScreen;
