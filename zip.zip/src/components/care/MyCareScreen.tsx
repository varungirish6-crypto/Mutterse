import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RemindersView } from './RemindersView';

type CareSegment = 'appointments' | 'careplan' | 'reminders';

export const MyCareScreen: React.FC = () => {
  const [segment, setSegment] = useState<CareSegment>('appointments');

  return (
    <div className="w-full min-h-[100dvh] relative flex flex-col bottom-nav-pad overflow-x-hidden">
      {/* Top Header Bar */}
      <header className="px-4 sm:px-5 pb-3 sticky top-0 z-40 lg-header border-b border-[#c1c8c1]/30 safe-header-pad">
        <h1 className="font-serif text-2xl font-bold text-[#062919]">
          {segment === 'reminders' ? 'Reminders' : segment === 'careplan' ? 'Care Plan & Vitals' : 'Antenatal Care'}
        </h1>
        <p className="text-xs text-[#424843] mt-0.5">
          {segment === 'reminders'
            ? 'Medication alarms, appointments & daily care'
            : 'Clinical appointments and maternal milestones'}
        </p>

        {/* 3-Tab Segmented Pill Control */}
        <div className="flex bg-white border border-[#c1c8c1]/40 rounded-3xl p-1 mt-3 gap-1 shadow-xs">
          {(['appointments', 'careplan', 'reminders'] as const).map((s) => {
            const active = segment === s;
            const label = s === 'appointments' ? 'Appointments' : s === 'careplan' ? 'Care Plan' : 'Reminders';
            return (
              <button
                key={s}
                type="button"
                onClick={() => setSegment(s)}
                className={`flex-1 py-2 px-1 text-center rounded-2xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                  active
                    ? 'bg-[#1e3f2e] text-white shadow-xs'
                    : 'text-[#424843] hover:text-[#062919] hover:bg-[#f1f4f1]'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </header>

      <main className="px-4 sm:px-5 pt-4 space-y-4 flex-1">
        {segment === 'appointments' && <AppointmentsView />}
        {segment === 'careplan' && <CarePlanView />}
        {segment === 'reminders' && <RemindersView />}
      </main>
    </div>
  );
};

// ── Segment 1: Appointments ──────────────────────────────────────────────────
const AppointmentsView: React.FC = () => {
  const { appointments, addAppointment, toggleAppointment, profile, showToast } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [filter, setFilter] = useState<'upcoming' | 'past'>('upcoming');

  const [title, setTitle] = useState(profile.doctor || 'Dr. Sarah Jenkins - Ultrasound');
  const [type, setType] = useState('Ultrasound Scan');
  const [date, setDate] = useState('2024-05-10');
  const [time, setTime] = useState('10:30 AM');
  const [location, setLocation] = useState(profile.deliveryHospital || "St. Jude Women's Hospital");

  const filtered = appointments.filter((a) =>
    filter === 'upcoming' ? a.status === 'Upcoming' : a.status === 'Completed'
  );

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('warning', 'Please provide an appointment title.');
      return;
    }
    addAppointment({
      title: title.trim(),
      type,
      date,
      time,
      location,
      clinicianName: profile.doctor,
      status: 'Upcoming',
      reminderEnabled: true,
      phase: 'pregnancy',
    });
    setShowAddModal(false);
    showToast('success', 'Appointment successfully scheduled!');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setFilter('upcoming')}
            className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold cursor-pointer ${
              filter === 'upcoming' ? 'bg-[#c6e8cf] text-[#062919]' : 'bg-[#f1f4f1] text-[#424843]'
            }`}
          >
            Upcoming ({appointments.filter((a) => a.status === 'Upcoming').length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('past')}
            className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold cursor-pointer ${
              filter === 'past' ? 'bg-[#c6e8cf] text-[#062919]' : 'bg-[#f1f4f1] text-[#424843]'
            }`}
          >
            Past ({appointments.filter((a) => a.status === 'Completed').length})
          </button>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="px-3.5 py-2 rounded-2xl bg-[#1e3f2e] text-white text-xs font-semibold flex items-center gap-1 hover:bg-[#062919] cursor-pointer"
        >
          <span className="material-symbols-outlined text-sm">add</span>
          <span>Book Visit</span>
        </button>
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-8 text-center lg-card rounded-3xl text-xs text-[#424843]">
            No appointments in this category.
          </div>
        ) : (
          filtered.map((apt) => (
            <div
              key={apt.id}
              className="lg-card rounded-3xl p-4 space-y-2.5"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] font-bold text-[#476551] uppercase tracking-wider block">
                    {apt.type}
                  </span>
                  <h3 className="text-sm font-bold text-[#062919] mt-0.5 leading-snug">{apt.title}</h3>
                </div>
                <span
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded-xl ${
                    apt.status === 'Completed'
                      ? 'bg-[#ecefeb] text-[#424843]'
                      : 'bg-[#c6e8cf] text-[#062919]'
                  }`}
                >
                  {apt.status}
                </span>
              </div>

              <div className="space-y-1 text-xs text-[#424843] leading-relaxed">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm text-[#476551]">calendar_today</span>
                  <span>
                    {apt.date} · {apt.time}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm text-[#476551]">location_on</span>
                  <span>{apt.location || 'St. Jude Women’s Clinic'}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#ecefeb] flex justify-end">
                <button
                  type="button"
                  onClick={() => toggleAppointment(apt.id)}
                  className="text-xs font-semibold text-[#1e3f2e] hover:underline cursor-pointer"
                >
                  {apt.status === 'Completed' ? 'Mark as Upcoming' : 'Mark as Completed'}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Book Visit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <h3 className="font-serif font-bold text-lg text-[#062919]">Schedule Hospital Visit</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">Appointment Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                >
                  <option value="Ultrasound Scan">Ultrasound Scan</option>
                  <option value="Antenatal Checkup">Antenatal Checkup</option>
                  <option value="Glucose Screen">Glucose Screen</option>
                  <option value="Blood Test / Lab Work">Blood Test / Lab Work</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-[#424843] mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#424843] mb-1">Time</label>
                  <input
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">Hospital / Clinic</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#1e3f2e] text-white text-xs font-bold hover:bg-[#062919] cursor-pointer"
              >
                Confirm Appointment
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// ── Segment 2: Care Plan & Tasks ─────────────────────────────────────────────
const CarePlanView: React.FC = () => {
  const { tasks, toggleTask, addTask, profile } = useApp();
  const [newTaskTitle, setNewTaskTitle] = useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    addTask({
      title: newTaskTitle.trim(),
      description: 'Personal maternal wellness task',
      category: 'Self Care',
      completed: false,
      dueDate: 'Today',
    });
    setNewTaskTitle('');
  };

  return (
    <div className="space-y-4">
      {/* Gestational Progress Overview Card */}
      <div className="lg-card rounded-3xl p-4 space-y-2">
        <span className="text-[11px] font-bold text-[#476551] uppercase">Trimester 2 Milestones</span>
        <h3 className="text-base font-bold text-[#062919]">Week {profile.gestationalWeek} Physiological Care</h3>
        <p className="text-xs text-[#424843] leading-relaxed">
          Baby's hearing is fully operational. Continue calcium intake for bone ossification and monitor fetal kick
          sessions daily.
        </p>
      </div>

      {/* Care Tasks List */}
      <div className="lg-card rounded-3xl p-4 space-y-3">
        <h3 className="text-sm font-bold text-[#062919]">Today's Care Tasks</h3>
        <div className="space-y-2">
          {tasks.map((task) => (
            <div
              key={task.id}
              onClick={() => toggleTask(task.id)}
              className={`p-3.5 rounded-2xl flex items-center justify-between cursor-pointer border transition-all ${
                task.completed
                  ? 'bg-[#c6e8cf]/20 border-[#c6e8cf] text-[#424843]'
                  : 'bg-[#f1f4f1]/70 border-[#c1c8c1]/30 text-[#181c1b]'
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`material-symbols-outlined text-lg ${
                    task.completed ? 'text-[#062919]' : 'text-[#727973]'
                  }`}
                >
                  {task.completed ? 'check_circle' : 'radio_button_unchecked'}
                </span>
                <span className={`text-xs ${task.completed ? 'line-through text-[#727973]' : 'font-semibold text-[#181c1b]'}`}>
                  {task.title}
                </span>
              </div>
              <span className="text-[10px] text-[#476551] font-semibold bg-white px-2.5 py-0.5 rounded-xl border border-[#c1c8c1]/30">
                {task.category}
              </span>
            </div>
          ))}
        </div>

        {/* Add new task input */}
        <form onSubmit={handleAddTask} className="pt-2 flex gap-2">
          <input
            type="text"
            placeholder="Add personal care reminder..."
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            className="flex-1 px-3 py-2 border border-[#c1c8c1] rounded-2xl text-xs"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-[#1e3f2e] text-white rounded-2xl text-xs font-semibold hover:bg-[#062919] cursor-pointer"
          >
            Add
          </button>
        </form>
      </div>
    </div>
  );
};


