/**
 * RemindersView — Manual Reminder Management
 * Part of the Mutterse Care section (Reminders segment)
 */
import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import type { ManualReminder, ReminderCategory, ReminderRepeat } from '../../types';

// ── Category meta ─────────────────────────────────────────────────────────────
const CATEGORIES: ReminderCategory[] = [
  'Medication',
  'Doctor Appointment',
  'Health Check-up',
  'Hydration',
  'Personal Care',
  'Other',
];

const CATEGORY_ICON: Record<ReminderCategory, string> = {
  Medication: 'medication',
  'Doctor Appointment': 'local_hospital',
  'Health Check-up': 'stethoscope',
  Hydration: 'water_drop',
  'Personal Care': 'spa',
  Other: 'alarm',
};

const CATEGORY_COLOR: Record<ReminderCategory, string> = {
  Medication: 'bg-[#ffdad6] text-[#93000a]',
  'Doctor Appointment': 'bg-[#d8e9ff] text-[#003c73]',
  'Health Check-up': 'bg-[#c6e8cf] text-[#032111]',
  Hydration: 'bg-[#c8f0f9] text-[#003447]',
  'Personal Care': 'bg-[#ead5ff] text-[#370069]',
  Other: 'bg-[#fef2cc] text-[#5a4500]',
};

const REPEAT_OPTIONS: ReminderRepeat[] = [
  'Does not repeat',
  'Daily',
  'Weekly',
  'Custom',
];

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

// ── Format time for display ───────────────────────────────────────────────────
function formatTime(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${m.toString().padStart(2, '0')} ${period}`;
}

function formatDate(dateStr: string): string {
  const today = new Date();
  const d = new Date(`${dateStr}T00:00:00`);
  const todayStr = today.toISOString().split('T')[0];
  const tomorrowStr = new Date(today.getTime() + 86400000).toISOString().split('T')[0];
  if (dateStr === todayStr) return 'Today';
  if (dateStr === tomorrowStr) return 'Tomorrow';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// ── Empty form state ──────────────────────────────────────────────────────────
function emptyForm() {
  const today = new Date().toISOString().split('T')[0];
  // Default to 15 minutes in the future for a new reminder
  const now = new Date(Date.now() + 15 * 60 * 1000);
  const hh = now.getHours().toString().padStart(2, '0');
  const mm = now.getMinutes().toString().padStart(2, '0');
  return {
    title: '',
    description: '',
    category: 'Medication' as ReminderCategory,
    date: today,
    time: `${hh}:${mm}`,
    repeat: 'Does not repeat' as ReminderRepeat,
    customDays: [] as number[],
  };
}

type FormState = ReturnType<typeof emptyForm>;

// ── Main component ────────────────────────────────────────────────────────────
export const RemindersView: React.FC = () => {
  const {
    reminders,
    medicines,
    toggleMedicine,
    addReminder,
    updateReminder,
    deleteReminder,
    toggleReminderComplete,
    notificationPermissionGranted,
    exactAlarmGranted,
    remindersLoading,
    remindersInitError,
    requestNotifPermission,
    requestExactAlarmPermission,
    retryRemindersInit,
    showToast,
  } = useApp();

  const [showPrescriptions, setShowPrescriptions] = useState(true);
  const [filter, setFilter] = useState<'upcoming' | 'completed'>('upcoming');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [saving, setSaving] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isRequestingPermission, setIsRequestingPermission] = useState(false);

  const upcoming = useMemo(
    () => reminders.filter((r) => !r.completed),
    [reminders]
  );
  const completed = useMemo(
    () => reminders.filter((r) => r.completed),
    [reminders]
  );
  const displayed = filter === 'upcoming' ? upcoming : completed;

  // Find next upcoming reminder (soonest in future)
  const nextReminder = useMemo(() => {
    const now = new Date();
    return upcoming
      .filter((r) => {
        const d = new Date(`${r.date}T${r.time}`);
        return d > now || r.repeat !== 'Does not repeat';
      })
      .sort((a, b) => {
        const da = new Date(`${a.date}T${a.time}`).getTime();
        const db = new Date(`${b.date}T${b.time}`).getTime();
        return da - db;
      })[0];
  }, [upcoming]);

  function openAdd() {
    setEditingId(null);
    setForm(emptyForm());
    setShowModal(true);
  }

  function openEdit(r: ManualReminder) {
    setEditingId(r.id);
    setForm({
      title: r.title,
      description: r.description ?? '',
      category: r.category,
      date: r.date,
      time: r.time,
      repeat: r.repeat,
      customDays: r.customDays ?? [],
    });
    setShowModal(true);
  }

  function closeModal() {
    setShowModal(false);
    setEditingId(null);
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      showToast('warning', 'Please enter a reminder title.');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim() || undefined,
        category: form.category,
        date: form.date,
        time: form.time,
        repeat: form.repeat,
        customDays: form.repeat === 'Custom' ? form.customDays : undefined,
        completed: false,
      };
      if (editingId) {
        await updateReminder(editingId, payload);
      } else {
        await addReminder(payload);
      }
      closeModal();
    } catch (err) {
      console.error('[Reminders] Save failed:', err);
      showToast('error', 'Could not save reminder. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    await deleteReminder(id);
    setConfirmDeleteId(null);
  };

  const handleToggleDay = (day: number) => {
    setForm((prev) => {
      const days = prev.customDays.includes(day)
        ? prev.customDays.filter((d) => d !== day)
        : [...prev.customDays, day];
      return { ...prev, customDays: days };
    });
  };

  const handlePromptPermission = async () => {
    setIsRequestingPermission(true);
    try {
      await requestNotifPermission();
    } finally {
      setIsRequestingPermission(false);
    }
  };

  return (
    <div className="space-y-4 w-full">
      {/* Loading state indicator */}
      {remindersLoading && (
        <div className="p-2.5 rounded-xl lg-badge flex items-center justify-between gap-2 text-xs text-[#062919]">
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 border-2 border-[#1e3f2e]/30 border-t-[#1e3f2e] rounded-full animate-spin" />
            <span>Synchronizing reminder services…</span>
          </div>
        </div>
      )}

      {/* Initialization error banner with retry */}
      {remindersInitError && (
        <div className="p-3 rounded-2xl bg-[#ffdad6]/80 border border-[#ba1a1a]/30 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-[#93000a] min-w-0">
            <span className="material-symbols-outlined text-base shrink-0">warning</span>
            <span className="truncate">{remindersInitError}</span>
          </div>
          <button
            type="button"
            onClick={retryRemindersInit}
            className="shrink-0 px-2.5 py-1 bg-white border border-[#ba1a1a]/40 text-[#93000a] font-bold rounded-lg cursor-pointer hover:bg-[#ffdad6]"
          >
            Retry
          </button>
        </div>
      )}

      {/* Notification permission banner */}
      {!notificationPermissionGranted ? (
        <div className="p-3.5 rounded-2xl bg-[#fff3cd]/90 border border-[#ffc107]/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5 min-w-0">
            <span className="material-symbols-outlined text-[#856404] text-xl shrink-0 mt-0.5">notifications_off</span>
            <div className="min-w-0">
              <p className="text-xs font-bold text-[#533f03]">Notifications not enabled</p>
              <p className="text-xs text-[#705400] mt-0.5 leading-relaxed font-medium">
                Allow notifications to receive medical alarms and vitals reminders on time.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handlePromptPermission}
            disabled={isRequestingPermission}
            className="self-end sm:self-auto shrink-0 px-3.5 py-1.5 bg-[#1e3f2e] text-white text-xs font-bold rounded-xl cursor-pointer hover:bg-[#062919] disabled:opacity-50 flex items-center gap-1.5 transition-all shadow-xs"
          >
            {isRequestingPermission ? (
              <>
                <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Allowing…</span>
              </>
            ) : (
              'Allow Notifications'
            )}
          </button>
        </div>
      ) : !exactAlarmGranted ? (
        <div className="p-3.5 rounded-2xl bg-[#fff8e1]/90 border border-[#ffe082]/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5 min-w-0">
            <span className="material-symbols-outlined text-[#f57f17] text-xl shrink-0 mt-0.5">more_time</span>
            <div className="min-w-0">
              <p className="text-xs font-bold text-[#5d4037]">Exact Alarms Recommended</p>
              <p className="text-xs text-[#5d4037] mt-0.5 leading-relaxed font-medium">
                Allow exact alarms in system settings for to-the-minute reliability.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={requestExactAlarmPermission}
            className="self-end sm:self-auto shrink-0 px-3.5 py-1.5 bg-[#476551] text-white text-xs font-bold rounded-xl cursor-pointer hover:bg-[#1e3f2e] transition-all shadow-xs"
          >
            Enable Exact
          </button>
        </div>
      ) : null}

      {/* Next upcoming reminder hero card */}
      {nextReminder && (
        <div className="bg-gradient-to-br from-[#1e3f2e] to-[#28523c] rounded-3xl p-4.5 text-white space-y-2 shadow-md border border-white/10">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#c9ebd2] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-sm">alarm</span>
              Next Reminder
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/15 text-white backdrop-blur-xs">
              {nextReminder.category}
            </span>
          </div>

          <h3 className="text-base font-serif font-bold text-white break-words leading-tight">
            {nextReminder.title}
          </h3>

          {nextReminder.description && (
            <p className="text-xs text-[#c9ebd2]/90 break-words line-clamp-2 leading-relaxed">
              {nextReminder.description}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-[#c9ebd2]">
            <span className="inline-flex items-center gap-1 bg-black/20 px-2.5 py-1 rounded-xl backdrop-blur-xs">
              <span className="material-symbols-outlined text-[14px]">calendar_today</span>
              {formatDate(nextReminder.date)}
            </span>
            <span className="inline-flex items-center gap-1 bg-black/20 px-2.5 py-1 rounded-xl backdrop-blur-xs">
              <span className="material-symbols-outlined text-[14px]">schedule</span>
              {formatTime(nextReminder.time)}
            </span>
            {nextReminder.repeat !== 'Does not repeat' && (
              <span className="inline-flex items-center gap-1 bg-black/20 px-2.5 py-1 rounded-xl backdrop-blur-xs">
                <span className="material-symbols-outlined text-[14px]">repeat</span>
                {nextReminder.repeat}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Header controls: Filter segmented pill & Add Reminder button */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
        <div className="inline-flex items-center p-1 bg-white/60 backdrop-blur-sm rounded-2xl border border-white/60 shadow-2xs">
          <button
            type="button"
            onClick={() => setFilter('upcoming')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'upcoming'
                ? 'bg-[#1e3f2e] text-white shadow-2xs'
                : 'text-[#424843] hover:text-[#062919] hover:bg-white/40'
            }`}
          >
            Upcoming ({upcoming.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('completed')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'completed'
                ? 'bg-[#1e3f2e] text-white shadow-2xs'
                : 'text-[#424843] hover:text-[#062919] hover:bg-white/40'
            }`}
          >
            Completed ({completed.length})
          </button>
        </div>

        <button
          type="button"
          onClick={openAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1e3f2e] text-white text-xs font-bold rounded-2xl hover:bg-[#062919] active:scale-95 transition-all cursor-pointer shadow-xs ml-auto"
        >
          <span className="material-symbols-outlined text-[18px]">add</span>
          <span>Add Reminder</span>
        </button>
      </div>

      {/* Reminder list */}
      <div className="space-y-3">
        {displayed.length === 0 && (
          <div className="p-8 text-center lg-card rounded-2xl text-xs text-[#424843] space-y-2">
            <span className="material-symbols-outlined text-4xl text-[#c1c8c1] block">alarm_off</span>
            <p className="font-semibold text-sm text-[#181c1b]">
              {filter === 'upcoming' ? 'No upcoming reminders' : 'No completed reminders'}
            </p>
            <p className="text-xs text-[#727973]">
              {filter === 'upcoming'
                ? 'Tap "+ Add Reminder" above to set a new medication or appointment alert.'
                : 'Reminders you mark completed will appear here.'}
            </p>
          </div>
        )}
        {displayed.map((r) => (
          <ReminderCard
            key={r.id}
            reminder={r}
            onEdit={() => openEdit(r)}
            onDelete={() => setConfirmDeleteId(r.id)}
            onToggle={() => toggleReminderComplete(r.id)}
          />
        ))}
      </div>

      {/* Prescribed Medications Section */}
      <div className="pt-2">
        <button
          type="button"
          onClick={() => setShowPrescriptions(!showPrescriptions)}
          className="w-full flex items-center justify-between py-2 text-left cursor-pointer select-none"
        >
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-base text-[#476551]">prescriptions</span>
            <span className="text-xs font-bold text-[#062919]">
              Prescribed Medications ({medicines.length})
            </span>
          </div>
          <span className="material-symbols-outlined text-lg text-[#727973] transition-transform">
            {showPrescriptions ? 'expand_less' : 'expand_more'}
          </span>
        </button>

        {showPrescriptions && (
          <div className="space-y-2 mt-1">
            {medicines.map((med) => (
              <div
                key={med.id}
                className="lg-card rounded-3xl p-3.5 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-9 h-9 aspect-square rounded-2xl bg-[#c9ebd2] flex items-center justify-center text-[#062919] shrink-0">
                    <span className="material-symbols-outlined text-lg">medication</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] text-[#476551] font-bold uppercase tracking-wider block">
                      {med.time}
                    </span>
                    <h4 className="text-xs font-bold text-[#062919] break-words">{med.name}</h4>
                    <p className="text-[11px] text-[#424843] break-words">{med.dosage}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => toggleMedicine(med.id)}
                  className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold cursor-pointer shrink-0 transition-all active:scale-95 ${
                    med.taken
                      ? 'bg-[#c6e8cf] text-[#062919] border border-[#adcfb7]/60'
                      : 'bg-[#1e3f2e] text-white hover:bg-[#062919] shadow-2xs'
                  }`}
                >
                  {med.taken ? '✓ Taken' : 'Mark Taken'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {showModal && (
        <ReminderModal
          form={form}
          setForm={setForm}
          onSave={handleSave}
          onClose={closeModal}
          saving={saving}
          isEdit={!!editingId}
          onToggleDay={handleToggleDay}
        />
      )}

      {/* Confirm delete dialog */}
      {confirmDeleteId && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="lg-modal rounded-3xl p-6 max-w-xs w-full space-y-4 text-center">
            <span className="material-symbols-outlined text-4xl text-[#ba1a1a] block">delete</span>
            <p className="text-sm font-bold text-[#062919]">Delete this reminder?</p>
            <p className="text-xs text-[#424843]">
              The reminder and its scheduled notification will be permanently removed.
            </p>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteId(null)}
                className="flex-1 py-2.5 rounded-2xl border border-[#c1c8c1] text-xs font-semibold text-[#424843] hover:bg-white/60 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDelete(confirmDeleteId)}
                className="flex-1 py-2.5 rounded-2xl bg-[#ba1a1a] text-white text-xs font-bold cursor-pointer hover:bg-[#93000a] active:scale-95 transition-all"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ── Reminder Card ─────────────────────────────────────────────────────────────
interface ReminderCardProps {
  reminder: ManualReminder;
  onEdit: () => void;
  onDelete: () => void;
  onToggle: () => void;
}

const ReminderCard: React.FC<ReminderCardProps> = ({ reminder, onEdit, onDelete, onToggle }) => {
  const icon = CATEGORY_ICON[reminder.category];
  const colorClass = CATEGORY_COLOR[reminder.category];

  return (
    <div
      className={`lg-card rounded-3xl p-4 space-y-3 transition-opacity ${
        reminder.completed ? 'opacity-70' : ''
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Category Icon */}
        <div
          className={`w-10 h-10 aspect-square rounded-2xl flex items-center justify-center shrink-0 ${colorClass}`}
        >
          <span className="material-symbols-outlined text-xl" style={{ fontVariationSettings: "'FILL' 1" }}>
            {icon}
          </span>
        </div>

        {/* Title, Category & Meta */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-1.5 mb-1">
            <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-xl ${colorClass}`}>
              {reminder.category}
            </span>
            {reminder.repeat !== 'Does not repeat' && (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#476551] bg-[#c6e8cf]/40 px-2.5 py-0.5 rounded-xl">
                <span className="material-symbols-outlined text-xs">repeat</span>
                {reminder.repeat}
              </span>
            )}
          </div>

          <h3
            className={`text-sm font-bold text-[#062919] leading-snug break-words ${
              reminder.completed ? 'line-through text-[#727973]' : ''
            }`}
          >
            {reminder.title}
          </h3>

          {reminder.description && (
            <p className="text-xs text-[#424843] mt-1 break-words line-clamp-2 leading-relaxed font-medium">
              {reminder.description}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-[#476551] font-semibold">
            <span className="inline-flex items-center gap-1 bg-white/60 px-2.5 py-0.5 rounded-xl border border-white/60">
              <span className="material-symbols-outlined text-[14px]">calendar_today</span>
              {formatDate(reminder.date)}
            </span>
            <span className="inline-flex items-center gap-1 bg-white/60 px-2.5 py-0.5 rounded-xl border border-white/60">
              <span className="material-symbols-outlined text-[14px]">schedule</span>
              {formatTime(reminder.time)}
            </span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between pt-2.5 border-t border-white/60">
        <button
          type="button"
          onClick={onToggle}
          aria-label={reminder.completed ? 'Mark reminder active' : 'Mark reminder completed'}
          className={`inline-flex items-center gap-1.5 text-xs font-bold cursor-pointer px-3.5 py-1.5 rounded-2xl transition-all active:scale-95 ${
            reminder.completed
              ? 'bg-white/70 text-[#424843] hover:bg-white border border-white/70'
              : 'bg-[#c6e8cf] text-[#062919] hover:bg-[#b5e0bf] border border-[#adcfb7]/50 shadow-2xs'
          }`}
        >
          <span
            className="material-symbols-outlined text-[16px]"
            style={{ fontVariationSettings: `'FILL' ${reminder.completed ? 0 : 1}` }}
          >
            {reminder.completed ? 'radio_button_unchecked' : 'check_circle'}
          </span>
          <span>{reminder.completed ? 'Mark Active' : 'Complete'}</span>
        </button>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onEdit}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-[#476551] hover:bg-white/70 active:scale-95 transition-all cursor-pointer"
            aria-label="Edit reminder"
            title="Edit reminder"
          >
            <span className="material-symbols-outlined text-[18px]">edit</span>
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-[#ba1a1a] hover:bg-red-50/80 active:scale-95 transition-all cursor-pointer"
            aria-label="Delete reminder"
            title="Delete reminder"
          >
            <span className="material-symbols-outlined text-[18px]">delete</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// ── Add / Edit Modal ──────────────────────────────────────────────────────────
interface ReminderModalProps {
  form: FormState;
  setForm: React.Dispatch<React.SetStateAction<FormState>>;
  onSave: (e: React.FormEvent) => Promise<void>;
  onClose: () => void;
  saving: boolean;
  isEdit: boolean;
  onToggleDay: (day: number) => void;
}

const ReminderModal: React.FC<ReminderModalProps> = ({
  form,
  setForm,
  onSave,
  onClose,
  saving,
  isEdit,
  onToggleDay,
}) => {
  const set = <K extends keyof FormState>(key: K, val: FormState[K]) =>
    setForm((prev) => ({ ...prev, [key]: val }));

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-xs">
      <div className="lg-modal rounded-t-3xl sm:rounded-3xl w-full max-w-lg max-h-[88dvh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="shrink-0 rounded-t-3xl px-5 pt-4 pb-3 border-b border-white/30 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#1e3f2e] text-xl">alarm_add</span>
            <h2 className="font-serif font-bold text-lg text-[#062919]">
              {isEdit ? 'Edit Reminder' : 'New Reminder'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-[#727973] hover:text-[#181c1b] hover:bg-white/60 cursor-pointer transition-colors"
          >
            <span className="material-symbols-outlined text-xl">close</span>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={onSave} className="px-5 py-4 space-y-4 overflow-y-auto flex-1">
          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-[#424843] mb-1.5">
              Reminder Title <span className="text-[#ba1a1a]">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Take prenatal vitamins"
              value={form.title}
              onChange={(e) => set('title', e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-2xl border border-white/60 text-sm text-[#181c1b] bg-white/70 focus:bg-white focus:outline-none focus:border-[#1e3f2e] focus:ring-2 focus:ring-[#1e3f2e]/10 transition-all"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-[#424843] mb-1.5">
              Notes <span className="text-[#727973] font-normal">(optional)</span>
            </label>
            <textarea
              placeholder="Additional instructions or notes…"
              value={form.description}
              onChange={(e) => set('description', e.target.value)}
              rows={2}
              className="w-full px-3.5 py-2.5 rounded-2xl border border-white/60 text-sm text-[#181c1b] bg-white/70 focus:bg-white focus:outline-none focus:border-[#1e3f2e] focus:ring-2 focus:ring-[#1e3f2e]/10 resize-none transition-all"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-bold text-[#424843] mb-2">Category</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => set('category', cat)}
                  className={`flex items-center gap-2 p-2.5 rounded-2xl border text-xs font-semibold text-left cursor-pointer transition-all ${
                    form.category === cat
                      ? 'border-[#1e3f2e] bg-[#1e3f2e] text-white shadow-2xs'
                      : 'border-white/60 text-[#424843] bg-white/70 hover:bg-white'
                  }`}
                >
                  <span
                    className="material-symbols-outlined text-[16px] shrink-0"
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    {CATEGORY_ICON[cat]}
                  </span>
                  <span className="truncate">{cat}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#424843] mb-1.5">Date</label>
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => set('date', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-2xl border border-white/60 text-sm text-[#181c1b] bg-white/70 focus:bg-white focus:outline-none focus:border-[#1e3f2e] transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#424843] mb-1.5">Time</label>
              <input
                type="time"
                required
                value={form.time}
                onChange={(e) => set('time', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-2xl border border-white/60 text-sm text-[#181c1b] bg-white/70 focus:bg-white focus:outline-none focus:border-[#1e3f2e] transition-all"
              />
            </div>
          </div>

          <p className="text-[11px] text-[#476551] flex items-center gap-1.5 -mt-1">
            <span className="material-symbols-outlined text-sm shrink-0">volume_up</span>
            <span>Triggers audible chime, vibration &amp; push notification alert when due.</span>
          </p>

          {/* Repeat */}
          <div>
            <label className="block text-xs font-bold text-[#424843] mb-2">Repeat</label>
            <div className="grid grid-cols-2 gap-2">
              {REPEAT_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => set('repeat', opt)}
                  className={`py-2.5 px-3 rounded-2xl border text-xs font-semibold cursor-pointer transition-all text-left ${
                    form.repeat === opt
                      ? 'border-[#1e3f2e] bg-[#1e3f2e] text-white shadow-2xs'
                      : 'border-white/60 text-[#424843] bg-white/70 hover:bg-white'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>

          {/* Custom days picker - perfectly responsive 7-column grid */}
          {form.repeat === 'Custom' && (
            <div>
              <label className="block text-xs font-bold text-[#424843] mb-2">Select Days</label>
              <div className="grid grid-cols-7 gap-1.5">
                {DAY_NAMES.map((name, idx) => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => onToggleDay(idx)}
                    className={`aspect-square rounded-2xl text-xs font-bold cursor-pointer border transition-all flex items-center justify-center ${
                      form.customDays.includes(idx)
                        ? 'bg-[#1e3f2e] text-white border-[#1e3f2e] shadow-2xs'
                        : 'bg-white/70 text-[#424843] border-white/60 hover:bg-white'
                    }`}
                  >
                    {name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Notification info note */}
          <div className="p-3.5 rounded-2xl lg-badge text-xs text-[#032111] flex items-start gap-2">
            <span className="material-symbols-outlined text-[#1e3f2e] text-lg shrink-0">info</span>
            <p>
              A notification will be scheduled at the selected time. For best results, keep Mutterse exempt from
              Android battery optimisation in Settings → Apps → Mutterse → Battery.
            </p>
          </div>

          {/* Actions */}
          <div
            className="flex gap-3 pt-2"
            style={{ paddingBottom: 'max(14px, env(safe-area-inset-bottom, 0px))' }}
          >
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-2xl border border-white/60 text-xs font-bold text-[#424843] bg-white/60 hover:bg-white/90 cursor-pointer transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-3 rounded-2xl bg-[#1e3f2e] text-white text-xs font-bold hover:bg-[#062919] disabled:opacity-60 cursor-pointer flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95"
            >
              {saving ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Saving…
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-sm">alarm_add</span>
                  {isEdit ? 'Save Changes' : 'Save Reminder'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
