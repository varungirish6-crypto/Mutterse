import React from 'react';

// ── Pregnant Mother Illustration (matches Screen 1 & 2) ────────────────────────
export const MotherIllustration: React.FC<{ width?: number; height?: number; className?: string }> = ({
  width = 110,
  height = 110,
  className = '',
}) => (
  <svg
    width={width}
    height={height}
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <defs>
      <linearGradient id="bgGlow" x1="0" y1="0" x2="120" y2="120" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F9EEF6" />
        <stop offset="1" stopColor="#FEEFF2" />
      </linearGradient>
      <linearGradient id="shirtPink" x1="45" y1="55" x2="75" y2="105" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F397B1" />
        <stop offset="1" stopColor="#E27595" />
      </linearGradient>
      <linearGradient id="hairDark" x1="40" y1="15" x2="80" y2="70" gradientUnits="userSpaceOnUse">
        <stop stopColor="#2A1E2B" />
        <stop offset="1" stopColor="#1B131D" />
      </linearGradient>
    </defs>

    {/* Background Soft Glow */}
    <circle cx="60" cy="60" r="54" fill="url(#bgGlow)" />

    {/* Floating Hearts */}
    <path
      d="M26 38 C26 35 28 33 31 33 C33 33 35 34 36 36 C37 34 39 33 41 33 C44 33 46 35 46 38 C46 42 41 46 36 49 C31 46 26 42 26 38 Z"
      fill="#F6B1C5"
      opacity="0.8"
    />
    <path
      d="M94 48 C94 46 95 45 97 45 C98 45 99 46 100 47 C101 46 102 45 103 45 C105 45 106 46 106 48 C106 51 103 54 100 56 C97 54 94 51 94 48 Z"
      fill="#EE9BB5"
      opacity="0.75"
    />
    <circle cx="22" cy="54" r="3" fill="#F8C8D7" opacity="0.8" />
    <circle cx="102" cy="36" r="2.5" fill="#E8B2D5" opacity="0.7" />

    {/* Body / Maternity Shape */}
    {/* Neck */}
    <path d="M57 42 L67 42 L65 52 L59 52 Z" fill="#E8B097" />

    {/* Pink Blouse / Torso with Pregnant Bump */}
    <path
      d="M52 52 C45 54 38 60 40 70 C42 80 47 88 53 92 C60 97 72 98 80 94 C88 90 94 82 92 72 C90 62 82 54 70 52 Z"
      fill="url(#shirtPink)"
    />

    {/* Maternity Bump Contour */}
    <path
      d="M74 65 C85 70 88 80 84 88 C80 94 72 96 66 95"
      stroke="#D35F82"
      strokeWidth="2.5"
      strokeLinecap="round"
      opacity="0.5"
    />

    {/* Arm & Hand resting on belly */}
    <path
      d="M48 56 C44 65 46 76 54 84 C59 88 66 89 72 87"
      stroke="#E8B097"
      strokeWidth="6"
      strokeLinecap="round"
      fill="none"
    />
    <ellipse cx="71" cy="86" rx="5" ry="3.5" fill="#E8B097" transform="rotate(-15 71 86)" />

    {/* Head & Face */}
    <ellipse cx="62" cy="34" rx="11" ry="13" fill="#E8B097" />
    {/* Gentle closed eye & serene smile */}
    <path d="M64 34 Q67 36 69 34" stroke="#5A3A40" strokeWidth="1.2" strokeLinecap="round" fill="none" />
    <path d="M65 40 Q68 42 71 39" stroke="#B8596E" strokeWidth="1.2" strokeLinecap="round" fill="none" />
    {/* Rosy Cheek */}
    <ellipse cx="69" cy="37" rx="2.5" ry="1.5" fill="#F495AA" opacity="0.6" />

    {/* Long Dark Hair */}
    <path
      d="M52 32 C52 22 58 18 67 18 C76 18 78 24 76 31 C74 34 72 37 72 38 C70 34 68 28 62 28 C56 28 53 33 52 38 Z"
      fill="url(#hairDark)"
    />
    {/* Flowing hair cascading back */}
    <path
      d="M54 28 C48 32 44 40 44 52 C44 65 47 75 51 80 C50 72 49 60 51 50 C52 42 55 35 55 28 Z"
      fill="url(#hairDark)"
    />
  </svg>
);

// ── Baby Fetus In Womb Illustration (matches Screen 3) ────────────────────────
export const BabyFetusIllustration: React.FC<{ width?: number; height?: number; className?: string }> = ({
  width = 96,
  height = 96,
  className = '',
}) => (
  <svg
    width={width}
    height={height}
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <defs>
      <radialGradient id="wombGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#FDE1EB" />
        <stop offset="70%" stopColor="#F9D2E0" />
        <stop offset="100%" stopColor="#F5C0D4" />
      </radialGradient>
      <linearGradient id="babySkin" x1="30" y1="25" x2="70" y2="75" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F9C6B3" />
        <stop offset="1" stopColor="#ECA792" />
      </linearGradient>
    </defs>

    {/* Womb Shape */}
    <circle cx="50" cy="50" r="46" fill="url(#wombGlow)" opacity="0.85" />
    <circle cx="50" cy="50" r="44" stroke="#F0B5CC" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.6" />

    {/* Curled Baby Figure */}
    {/* Head */}
    <circle cx="48" cy="38" r="14" fill="url(#babySkin)" />
    {/* Sweet Closed Eye */}
    <path d="M44 38 Q46 40 49 38" stroke="#8E5B4B" strokeWidth="1.2" strokeLinecap="round" fill="none" />

    {/* Curled Body / Spine */}
    <path
      d="M55 46 C62 50 64 62 58 70 C52 76 42 75 38 68 C35 63 36 55 42 50"
      stroke="url(#babySkin)"
      strokeWidth="11"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />

    {/* Cute Little Arm */}
    <path
      d="M48 48 C44 52 42 56 46 60"
      stroke="#F6BDAB"
      strokeWidth="4"
      strokeLinecap="round"
      fill="none"
    />
    <circle cx="46" cy="60" r="2.5" fill="#F6BDAB" />

    {/* Little Leg */}
    <path
      d="M54 68 C50 72 45 74 42 71"
      stroke="#ECA792"
      strokeWidth="5"
      strokeLinecap="round"
      fill="none"
    />

    {/* Heartbeats */}
    <circle cx="74" cy="30" r="3" fill="#E26D8E" opacity="0.7" />
    <circle cx="26" cy="65" r="2.5" fill="#E26D8E" opacity="0.6" />
  </svg>
);

// ── Priya Sharma Avatar (matches reference circular avatar) ───────────────────
export const PriyaAvatar: React.FC<{ size?: number; className?: string }> = ({
  size = 44,
  className = '',
}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: size / 2,
      padding: 2,
      background: 'linear-gradient(135deg, #E8A8BC 0%, #C48EBA 100%)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 6px rgba(139, 75, 139, 0.18)',
    }}
    className={className}
  >
    <div
      style={{
        width: '100%',
        height: '100%',
        borderRadius: (size - 4) / 2,
        background: '#FFF5F8',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <svg width={size - 4} height={size - 4} viewBox="0 0 48 48" fill="none">
        {/* Background */}
        <circle cx="24" cy="24" r="24" fill="#FDEEF3" />
        {/* Blouse */}
        <path d="M12 48 C12 36 20 33 24 33 C28 33 36 36 36 48 Z" fill="#E6829F" />
        {/* Neck */}
        <rect x="21" y="27" width="6" height="7" rx="3" fill="#E7B19E" />
        {/* Face */}
        <ellipse cx="24" cy="22" rx="9" ry="10" fill="#E7B19E" />
        {/* Gentle Eyes & Smile */}
        <path d="M19 22 Q21 23 23 22" stroke="#482F36" strokeWidth="1" strokeLinecap="round" />
        <path d="M25 22 Q27 23 29 22" stroke="#482F36" strokeWidth="1" strokeLinecap="round" />
        <path d="M22 26 Q24 28 26 26" stroke="#B8596E" strokeWidth="1.2" strokeLinecap="round" fill="none" />
        <circle cx="20" cy="24" r="1.5" fill="#F495AA" opacity="0.6" />
        <circle cx="28" cy="24" r="1.5" fill="#F495AA" opacity="0.6" />
        {/* Bindi */}
        <circle cx="24" cy="18" r="0.8" fill="#B83A52" />
        {/* Dark Hair */}
        <path
          d="M15 22 C15 13 18 10 24 10 C30 10 33 13 33 22 C33 24 32 26 31 28 C29 22 27 16 24 16 C21 16 19 22 17 28 C16 26 15 24 15 22 Z"
          fill="#251B26"
        />
        {/* Hair Bun / Parting */}
        <path d="M16 18 Q24 13 32 18" stroke="#1F1520" strokeWidth="3" strokeLinecap="round" fill="none" />
      </svg>
    </div>
  </div>
);
