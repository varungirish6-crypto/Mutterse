import React from 'react';
import { Trash2, X, Check } from 'lucide-react';
import type { ToastMessage } from '../../types';

// ── Toast Container ───────────────────────────────────────────────────────────
interface ToastContainerProps {
  toasts: ToastMessage[];
  onRemove: (id: string) => void;
}

const TOAST_THEMES: Record<ToastMessage['type'], { bg: string; text: string; border: string }> = {
  success: { bg: '#1E3F2E', text: '#FFFFFF', border: '#446652' },
  info:    { bg: '#062919', text: '#FFFFFF', border: '#2C4D3C' },
  warning: { bg: '#5D2A16', text: '#FFFFFF', border: '#DA9075' },
  error:   { bg: '#BA1A1A', text: '#FFFFFF', border: '#FFDAD6' },
};

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onRemove }) => (
  <div
    style={{
      position: 'fixed',
      bottom: 84,
      left: 0,
      right: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      padding: '0 16px',
      zIndex: 250,
      pointerEvents: 'none',
      maxWidth: 440,
      margin: '0 auto',
    }}
  >
    {toasts.map((t) => {
      const theme = TOAST_THEMES[t.type] || TOAST_THEMES.info;
      return (
        <div
          key={t.id}
          onClick={() => onRemove(t.id)}
          style={{
            background: theme.bg,
            color: theme.text,
            border: `1px solid ${theme.border}`,
            borderRadius: 18,
            padding: '11px 18px',
            fontSize: 13,
            fontWeight: 600,
            width: '100%',
            maxWidth: 360,
            pointerEvents: 'auto',
            cursor: 'pointer',
            boxShadow: '0 8px 24px -4px rgba(115, 63, 119, 0.28)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 12,
            animation: 'msToastSlide 0.22s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span style={{ flex: 1 }}>{t.message}</span>
          <span style={{ opacity: 0.7, fontSize: 11 }}>Tap to close</span>
        </div>
      );
    })}
    <style>{`
      @keyframes msToastSlide {
        from { opacity: 0; transform: translateY(14px) scale(0.97); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
      }
    `}</style>
  </div>
);

// ── Modal / Mobile Bottom Sheet ───────────────────────────────────────────────
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 200,
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
        background: 'rgba(45, 35, 50, 0.45)',
        backdropFilter: 'blur(4px)',
        WebkitBackdropFilter: 'blur(4px)',
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: 440,
          maxHeight: '90dvh',
          background: '#FFF6F8',
          borderRadius: '28px 28px 0 0',
          borderTop: '1px solid #F5E3E8',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 -8px 32px rgba(115, 63, 119, 0.15)',
          animation: 'msSheetSlide 0.24s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Handle bar */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 10, paddingBottom: 4 }}>
          <div style={{ width: 40, height: 4.5, borderRadius: 3, background: '#E6D3DA' }} />
        </div>

        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '12px 20px 10px',
            borderBottom: '1px solid #F6E6EA',
          }}
        >
          <h2
            style={{
              margin: 0,
              fontSize: 17,
              fontWeight: 700,
              color: '#2D2332',
              letterSpacing: -0.2,
            }}
          >
            {title}
          </h2>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            style={{
              border: 'none',
              background: '#F6E6EA',
              borderRadius: 20,
              width: 28,
              height: 28,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              color: '#7E7284',
              transition: 'background 0.12s',
            }}
          >
            <X size={15} />
          </button>
        </div>

        {/* Body */}
        <div style={{ overflowY: 'auto', padding: '16px 20px 32px', WebkitOverflowScrolling: 'touch' }}>
          {children}
        </div>
      </div>
      <style>{`
        @keyframes msSheetSlide {
          from { transform: translateY(100%); }
          to   { transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

// ── Form helpers ──────────────────────────────────────────────────────────────
interface FieldProps {
  label: string;
  children: React.ReactNode;
  hint?: string;
}

export const Field: React.FC<FieldProps> = ({ label, children, hint }) => (
  <div style={{ marginBottom: 15 }}>
    <label
      style={{
        display: 'block',
        fontSize: 11,
        fontWeight: 700,
        color: '#7E7284',
        marginBottom: 6,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
      }}
    >
      {label}
    </label>
    {children}
    {hint && <p style={{ margin: '4px 0 0', fontSize: 11, color: '#A59AA9' }}>{hint}</p>}
  </div>
);

export const INPUT_STYLE: React.CSSProperties = {
  width: '100%',
  padding: '12px 14px',
  borderRadius: 16,
  border: '1.5px solid #F5E3E8',
  background: '#FFFFFF',
  fontSize: 13.5,
  color: '#2D2332',
  outline: 'none',
  boxSizing: 'border-box',
  transition: 'border-color 0.15s, box-shadow 0.15s',
  fontFamily: 'inherit',
};

export const SELECT_STYLE: React.CSSProperties = {
  ...INPUT_STYLE,
  appearance: 'none',
  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1.5 2l4.5 4.5 4.5-4.5' stroke='%23733F77' stroke-width='1.75' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
  backgroundRepeat: 'no-repeat',
  backgroundPosition: 'right 14px center',
  paddingRight: 38,
};

// ── Task item (matches reference checklist with purple check circle) ───────────
interface TaskItemProps {
  title: string;
  description?: string;
  category?: string;
  completed: boolean;
  onToggle: () => void;
  onDelete?: () => void;
  dueDate?: string;
  time?: string;
}

export const TaskItem: React.FC<TaskItemProps> = ({
  title,
  description,
  category,
  completed,
  onToggle,
  onDelete,
  dueDate,
  time,
}) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '12px 14px',
      background: '#FFFFFF',
      border: '1px solid #F5E3E8',
      borderRadius: 18,
      marginBottom: 8,
      boxShadow: '0 2px 8px rgba(115, 63, 119, 0.04)',
      transition: 'background 0.15s, border-color 0.15s',
    }}
  >
    <button
      onClick={onToggle}
      aria-label={completed ? 'Mark task incomplete' : 'Mark task complete'}
      style={{
        border: 'none',
        background: 'none',
        padding: 0,
        cursor: 'pointer',
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {completed ? (
        <span
          style={{
            width: 22,
            height: 22,
            borderRadius: 11,
            background: '#733F77',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#FFFFFF',
            boxShadow: '0 2px 6px rgba(115, 63, 119, 0.3)',
          }}
        >
          <Check size={13} strokeWidth={3} />
        </span>
      ) : (
        <span
          style={{
            width: 22,
            height: 22,
            borderRadius: 11,
            border: '1.5px solid #D8C7D0',
            background: '#FFFFFF',
          }}
        />
      )}
    </button>
    <div style={{ flex: 1, minWidth: 0 }}>
      <p
        style={{
          margin: 0,
          fontSize: 13.5,
          fontWeight: 600,
          color: completed ? '#A59AA9' : '#2D2332',
          textDecoration: completed ? 'line-through' : 'none',
          lineHeight: 1.35,
        }}
      >
        {title}
      </p>
      {description && !completed && (
        <p style={{ margin: '2px 0 0', fontSize: 11.5, color: '#7E7284', lineHeight: 1.4 }}>
          {description}
        </p>
      )}
      <div style={{ display: 'flex', gap: 7, marginTop: 4, flexWrap: 'wrap', alignItems: 'center' }}>
        {time && (
          <span style={{ fontSize: 11, fontWeight: 600, color: '#733F77' }}>
            {time}
          </span>
        )}
        {category && (
          <span
            style={{
              fontSize: 10,
              fontWeight: 700,
              color: '#733F77',
              background: '#F1E5F4',
              borderRadius: 6,
              padding: '2px 6px',
            }}
          >
            {category}
          </span>
        )}
        {dueDate && !completed && (
          <span style={{ fontSize: 10.5, fontWeight: 500, color: '#D4613B' }}>
            Due {dueDate}
          </span>
        )}
      </div>
    </div>
    {onDelete && (
      <button
        onClick={onDelete}
        aria-label="Delete task"
        style={{
          border: 'none',
          background: 'none',
          padding: 4,
          cursor: 'pointer',
          flexShrink: 0,
          color: '#C6B8C0',
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Trash2 size={13} />
      </button>
    )}
  </div>
);

// ── Section header ─────────────────────────────────────────────────────────────
interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({ title, subtitle, action }) => (
  <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 12 }}>
    <div>
      <h2 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#2D2332', letterSpacing: -0.2 }}>
        {title}
      </h2>
      {subtitle && <p style={{ margin: '2px 0 0', fontSize: 11.5, color: '#7E7284' }}>{subtitle}</p>}
    </div>
    {action}
  </div>
);

// ── Status badge ──────────────────────────────────────────────────────────────
const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  'Upcoming':                 { bg: '#F1E5F4', text: '#733F77' },
  'Completed':                { bg: '#E8F8F0', text: '#1E7D48' },
  'Normal':                   { bg: '#E8F8F0', text: '#1E7D48' },
  'Reviewed by Clinician':    { bg: '#E8F8F0', text: '#1E7D48' },
  'Overdue':                  { bg: '#FEEBF0', text: '#C34267' },
  'Action Required':          { bg: '#FEEBF0', text: '#C34267' },
  'Pending Clinician Review': { bg: '#FEF3E8', text: '#BA6818' },
  'Pending':                  { bg: '#FEF3E8', text: '#BA6818' },
  'Appointment Booked':       { bg: '#F1E5F4', text: '#733F77' },
  'Cancelled':                { bg: '#F3EDF1', text: '#8E828E' },
};

interface StatusBadgeProps {
  value: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ value }) => {
  const c = STATUS_COLORS[value] ?? { bg: '#F1E5F4', text: '#733F77' };
  return (
    <span
      style={{
        fontSize: 10.5,
        fontWeight: 700,
        letterSpacing: 0.2,
        background: c.bg,
        color: c.text,
        borderRadius: 12,
        padding: '3px 9px',
        whiteSpace: 'nowrap',
        display: 'inline-block',
      }}
    >
      {value}
    </span>
  );
};

// ── Empty state ────────────────────────────────────────────────────────────────
interface EmptyProps {
  icon: React.ReactNode;
  message: string;
  action?: React.ReactNode;
}

export const EmptyState: React.FC<EmptyProps> = ({ icon, message, action }) => (
  <div
    style={{
      textAlign: 'center',
      padding: '36px 20px',
      background: '#FFFFFF',
      border: '1.5px dashed #F5E3E8',
      borderRadius: 20,
      color: '#A59AA9',
    }}
  >
    <div
      style={{
        width: 48,
        height: 48,
        borderRadius: 24,
        background: '#FAF1F4',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto 12px',
        color: '#733F77',
      }}
    >
      {icon}
    </div>
    <p style={{ margin: '0 0 14px', fontSize: 13, color: '#7E7284', lineHeight: 1.4, maxWidth: 280, marginLeft: 'auto', marginRight: 'auto' }}>
      {message}
    </p>
    {action}
  </div>
);
