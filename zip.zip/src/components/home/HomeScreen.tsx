import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { sendMedicineChatMessage, type ChatMessage } from '../../services/geminiApi';
import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

export const HomeScreen: React.FC = () => {
  const {
    profile,
    medicines,
    toggleMedicine,
    tasks,
    appointments,
    routine,
    logWater,
    logPelvicFloor,
    logBloodPressure,
    logKickSession,
    logContraction,
    setActiveTab,
    showToast,
  } = useApp();

  // Modals state
  const [showSosModal, setShowSosModal] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showKickCounterModal, setShowKickCounterModal] = useState(false);
  const [showMidwifeModal, setShowMidwifeModal] = useState(false);
  const [showVitalsModal, setShowVitalsModal] = useState(false);
  const [showContractionModal, setShowContractionModal] = useState(false);
  const [showNutritionModal, setShowNutritionModal] = useState<string | null>(null);

  // Kick counter temporary state
  const [kickCount, setKickCount] = useState(0);
  const [kickTimerSec, setKickTimerSec] = useState(0);
  const [isKickTimerRunning, setIsKickTimerRunning] = useState(false);
  const kickTimerRef = React.useRef<any>(null);

  // Vitals modal form
  const [vitalsBpSystolic, setVitalsBpSystolic] = useState('118');
  const [vitalsBpDiastolic, setVitalsBpDiastolic] = useState('76');
  const [vitalsPulse, setVitalsPulse] = useState('72');
  const [vitalsWeight, setVitalsWeight] = useState('62.5');

  // Contraction timer state
  const [isContractionRunning, setIsContractionRunning] = useState(false);
  const [contractionDurationSec, setContractionDurationSec] = useState(0);
  const contractionTimerRef = React.useRef<any>(null);

  // Kick Counter Timer handlers
  const handleStartKickCounter = () => {
    setIsKickTimerRunning(true);
    kickTimerRef.current = setInterval(() => {
      setKickTimerSec((prev) => prev + 1);
    }, 1000);
  };

  const handleStopAndSaveKicks = () => {
    if (kickTimerRef.current) clearInterval(kickTimerRef.current);
    setIsKickTimerRunning(false);
    const mins = Math.floor(kickTimerSec / 60);
    const secs = kickTimerSec % 60;
    const durationStr = `${mins}m ${secs}s`;
    if (kickCount > 0) {
      logKickSession(kickCount, durationStr, 'Active session recorded');
    }
    setKickCount(0);
    setKickTimerSec(0);
    setShowKickCounterModal(false);
  };

  // Contraction timer handlers
  const handleToggleContractionTimer = () => {
    if (isContractionRunning) {
      if (contractionTimerRef.current) clearInterval(contractionTimerRef.current);
      setIsContractionRunning(false);
      logContraction(contractionDurationSec, 20, 'Mild');
      setContractionDurationSec(0);
    } else {
      setIsContractionRunning(true);
      setContractionDurationSec(0);
      contractionTimerRef.current = setInterval(() => {
        setContractionDurationSec((prev) => prev + 1);
      }, 1000);
    }
  };

  // Midwife AI state
  const [midwifeQuery, setMidwifeQuery] = useState('');
  const [midwifeMessages, setMidwifeMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'midwife',
      text: 'Good morning, Elena. I am your 24/7 Maternal AI Guide. How can I assist you with your pregnancy, symptoms, or medications today?',
      time: '9:30 AM',
    },
  ]);
  const [isMidwifeTyping, setIsMidwifeTyping] = useState(false);
  const [midwifeAttachedImage, setMidwifeAttachedImage] = useState<string | null>(null);
  const [midwifeAttachedMime, setMidwifeAttachedMime] = useState<string>('image/jpeg');
  const [midwifeError, setMidwifeError] = useState<string | null>(null);
  const midwifeFileInputRef = useRef<HTMLInputElement>(null);
  const midwifeChatScrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat modal when messages or typing changes
  useEffect(() => {
    if (midwifeChatScrollRef.current) {
      midwifeChatScrollRef.current.scrollTop = midwifeChatScrollRef.current.scrollHeight;
    }
  }, [midwifeMessages, isMidwifeTyping]);

  const handleMidwifeFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('warning', 'Please select a valid image file (JPEG, PNG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      const dataUrl = loadEvt.target?.result as string;
      if (dataUrl) {
        setMidwifeAttachedImage(dataUrl);
        setMidwifeAttachedMime(file.type || 'image/jpeg');
        setMidwifeError(null);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleMidwifePickPhoto = async () => {
    if (Capacitor.isNativePlatform()) {
      try {
        const photo = await Camera.getPhoto({
          quality: 85,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Prompt,
        });
        if (photo.dataUrl) {
          setMidwifeAttachedImage(photo.dataUrl);
          setMidwifeAttachedMime(photo.format ? `image/${photo.format}` : 'image/jpeg');
          setMidwifeError(null);
        }
      } catch (err: any) {
        if (!err.message?.toLowerCase().includes('cancel')) {
          midwifeFileInputRef.current?.click();
        }
      }
    } else {
      midwifeFileInputRef.current?.click();
    }
  };

  // Midwife AI send handler - Real Gemini API Integration
  const handleSendMidwifeMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = midwifeQuery.trim();
    const imageToSend = midwifeAttachedImage;
    const mimeToSend = midwifeAttachedMime;

    if ((!query && !imageToSend) || isMidwifeTyping) return;

    setMidwifeError(null);
    setMidwifeQuery('');
    setMidwifeAttachedImage(null);

    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query || (imageToSend ? 'Please examine this medicine/packaging image and provide maternal clinical guidance on its use, safety in pregnancy, and precautions.' : ''),
      time: nowTime,
      image: imageToSend || undefined,
    };

    const newHistory = [...midwifeMessages, userMessage];
    setMidwifeMessages(newHistory);
    setIsMidwifeTyping(true);

    try {
      const reply = await sendMedicineChatMessage(
        userMessage.text,
        newHistory,
        null,
        imageToSend,
        mimeToSend
      );

      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'midwife',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMidwifeMessages((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      console.error('[MidwifeAI] Error:', err);
      setMidwifeError(err.message || 'Unable to connect to Mutterse AI. Please check your network or try again.');
    } finally {
      setIsMidwifeTyping(false);
    }
  };

  // Primary medicine
  const primaryMed = medicines[0] || {
    id: 'med-1',
    name: 'Prenatal Multivitamin & Iron',
    dosage: 'Take with lunch & full glass of water',
    time: '1:00 PM',
    taken: false,
  };

  const firstName = profile.name.split(' ')[0] || 'Elena';

  // Dynamic Care Progress Calculation
  // Automatically computes progress whenever care activities, tasks, medicines, or appointments update
  const totalTasks = tasks?.length || 0;
  const completedTasks = tasks?.filter((t) => t.completed).length || 0;

  const totalMedicines = medicines?.length || 0;
  const completedMedicines = medicines?.filter((m) => m.taken).length || 0;

  const totalAppointments = appointments?.length || 0;
  const completedAppointments = appointments?.filter((a) => a.status === 'Completed').length || 0;

  const totalCareItems = totalTasks + totalMedicines + totalAppointments;
  const completedCareItems = completedTasks + completedMedicines + completedAppointments;

  // Handle zero progress (0%) and 100% completion cleanly and accurately
  const progressPercentage =
    totalCareItems > 0
      ? Math.min(100, Math.max(0, Math.round((completedCareItems / totalCareItems) * 100)))
      : 0;

  // Dynamic Gestational Days Calculation (40 weeks full term = 280 days)
  const currentGestationalDays = (profile.gestationalWeek || 24) * 7 + (profile.gestationalDay || 0);
  const daysUntilBirth = Math.max(0, 280 - currentGestationalDays);
  const trimester =
    (profile.gestationalWeek || 24) < 13 ? 1 : (profile.gestationalWeek || 24) < 27 ? 2 : 3;

  return (
    <div className="w-full min-h-[100dvh] relative flex flex-col bottom-nav-pad overflow-x-hidden">
      {/* Top Navigation Anchor (Shared Component: TopAppBar) */}
      <header className="w-full flex items-center justify-between px-4 sm:px-5 pb-3 wallpaper-header sticky top-0 z-40 border-b border-[#c1c8c1]/30 backdrop-blur-md safe-header-pad">
        <div className="flex items-center gap-3">
          {/* Avatar thumbnail */}
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className="relative w-10 h-10 rounded-full overflow-hidden border border-[#c1c8c1] bg-[#e6e9e6] flex-shrink-0 cursor-pointer active:scale-95 transition-transform"
            aria-label="View Profile & Settings"
          >
            <img
              src={profile.avatarUrl}
              alt={profile.name}
              className="w-full h-full object-cover"
            />
          </button>
          <div>
            <span className="font-serif font-bold text-lg text-[#062919] tracking-tight block">
              Mutterse
            </span>
            <span className="text-[11px] text-[#424843]">Maternal Care Companion</span>
          </div>
        </div>

        {/* Quick Action SOS / Notification Bell */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowSosModal(true)}
            aria-label="Emergency SOS Midwife"
            className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#ffdad6] text-[#ba1a1a] hover:bg-[#ffdad6]/80 transition-opacity active:scale-95 cursor-pointer font-semibold shadow-xs"
          >
            <span className="material-symbols-outlined text-base" style={{ fontVariationSettings: "'FILL' 1" }}>
              emergency
            </span>
            <span className="text-xs font-bold">SOS</span>
          </button>
          <button
            type="button"
            onClick={() => setShowNotificationsModal(true)}
            aria-label="Notifications"
            className="w-9 h-9 rounded-full flex items-center justify-center text-[#062919] hover:bg-[#f1f4f1] transition-colors duration-150 active:scale-95 cursor-pointer relative"
          >
            <span className="material-symbols-outlined text-xl">notifications</span>
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#da9075] ring-2 ring-[#f7faf7]"></span>
          </button>
        </div>
      </header>

      {/* Main Dashboard Content Stream */}
      <main className="flex-1 px-5 space-y-4 pt-3">
        {/* Personalized Greeting & Gestational Badge */}
        <section className="flex items-center justify-between pt-1">
          <div>
            <h1
              className="text-2xl font-serif font-bold text-[#FFFFFF] leading-snug drop-shadow-[0_2px_4px_rgba(6,41,25,0.75)] tracking-tight"
              style={{
                color: '#FFFFFF',
                fontWeight: 700,
                textShadow: '0 2px 4px rgba(6, 41, 25, 0.75), 0 1px 2px rgba(0, 0, 0, 0.65)',
              }}
            >
              Good morning, {firstName} 🌿
            </h1>
            <p className="text-xs text-[#2a382e] mt-0.5 leading-relaxed font-semibold drop-shadow-[0_1px_1px_rgba(255,255,255,0.85)]">
              Here is your gentle body update for today.
            </p>
          </div>
          <div className="flex-shrink-0 bg-[#c6e8cf] text-[#062919] text-xs px-3 py-1.5 rounded-full border border-[#c9ebd2] font-semibold shadow-xs animate-float-gentle">
            Week {profile.gestationalWeek} · Day {profile.gestationalDay || 3}
          </div>
        </section>

        {/* Pregnancy Progress Hero Card */}
        <section className="lg-card-elevated rounded-3xl p-5 relative overflow-hidden">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex-1">
              <span className="text-[11px] uppercase tracking-wider text-[#476551] font-bold">
                Trimester {trimester} Milestone
              </span>
              <h2 className="text-3xl font-serif text-[#062919] mt-1 font-bold">{daysUntilBirth} Days</h2>
              <p className="text-xs text-[#424843] mt-0.5 leading-relaxed">until you hold your baby in your arms</p>
            </div>
            {/* Tactile Countdown Visual Circle / Progress Indicator */}
            <div
              className="relative w-16 h-16 flex items-center justify-center flex-shrink-0"
              role="progressbar"
              aria-valuenow={progressPercentage}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={`Overall care activities and tasks progress: ${progressPercentage}%`}
            >
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-[#ecefeb]"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3.5"
                />
                <path
                  className="text-[#1e3f2e] transition-all duration-500 ease-out"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="currentColor"
                  strokeDasharray={`${progressPercentage}, 100`}
                  strokeLinecap="round"
                  strokeWidth="3.5"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-xs font-bold text-[#062919]">{progressPercentage}%</span>
              </div>
            </div>
          </div>

          {/* Fruit/Vegetable Size Comparison Bento Block */}
          <div className="lg-surface rounded-2xl p-3 flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-[#1e3f2e] border border-[#c1c8c1]/30 flex-shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-2xl text-[#1e3f2e]">eco</span>
            </div>
            <div>
              <div className="text-xs text-[#062919] font-bold">Size of an ear of corn</div>
              <div className="text-[11px] text-[#424843]">Approx. 30 cm long · 600g</div>
            </div>
          </div>

          {/* Fetal milestone note */}
          <div className="flex items-start gap-2 text-[#424843] lg-surface rounded-2xl p-2.5 px-3">
            <span className="material-symbols-outlined text-[#476551] text-lg flex-shrink-0 mt-0.5">
              hearing
            </span>
            <p className="text-xs italic leading-snug">
              Hearing is developing rapidly; baby can recognize your voice and maternal heartbeat!
            </p>
          </div>
        </section>

        {/* Timely Care & Schedule */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-[#062919]">Timely Care &amp; Schedule</h3>
            <button
              type="button"
              onClick={() => setActiveTab('care')}
              className="text-xs text-[#476551] font-semibold hover:underline cursor-pointer"
            >
              View Calendar
            </button>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            {/* Next Hospital Appointment */}
            <div className="lg-card rounded-3xl p-4 flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#c6e8cf] flex items-center justify-center text-[#062919] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">stethoscope</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#476551] font-bold uppercase tracking-wider">
                    Hospital Visit
                  </span>
                  <span className="text-[11px] text-[#424843] bg-[#ecefeb] px-2.5 py-0.5 rounded-xl font-medium">
                    Tomorrow, 10:30 AM
                  </span>
                </div>
                <p className="text-sm font-bold text-[#062919] mt-1 break-words leading-snug">
                  {profile.doctor || 'Dr. Sarah Jenkins'} - Anatomy Ultrasound
                </p>
                <p className="text-xs text-[#424843] mt-0.5 flex items-center gap-1 leading-relaxed">
                  <span className="material-symbols-outlined text-xs text-[#476551]">location_on</span>
                  <span>{profile.deliveryHospital || "St. Jude Women's Wing"} · Room 304</span>
                </p>
              </div>
            </div>

            {/* Next Medicine Intake */}
            <div className="lg-card rounded-3xl p-4 flex items-center justify-between gap-3">
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-[#c9ebd2] flex items-center justify-center text-[#032111] flex-shrink-0">
                  <span className="material-symbols-outlined text-xl">medication</span>
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] text-[#476551] font-bold uppercase tracking-wider">
                    Medicine · {primaryMed.time}
                  </span>
                  <p className="text-sm font-bold text-[#062919] break-words leading-snug">{primaryMed.name}</p>
                  <p className="text-xs text-[#424843] break-words leading-relaxed">{primaryMed.dosage}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => toggleMedicine(primaryMed.id)}
                className={`flex-shrink-0 text-xs font-semibold px-3.5 py-2 rounded-2xl transition-all duration-150 active:scale-95 cursor-pointer flex items-center gap-1 ${
                  primaryMed.taken
                    ? 'bg-[#c6e8cf] text-[#062919] border border-[#adcfb7]'
                    : 'bg-[#1e3f2e] text-white hover:bg-[#062919] shadow-xs'
                }`}
              >
                {primaryMed.taken ? (
                  <>
                    <span className="material-symbols-outlined text-sm">check</span>
                    <span>Taken</span>
                  </>
                ) : (
                  <span>Mark Taken</span>
                )}
              </button>
            </div>
          </div>
        </section>

        {/* Daily Care Checklist Bento */}
        <section className="space-y-2.5">
          <h3 className="text-base font-bold text-[#062919]">Daily Vitals &amp; Routine</h3>
          <div className="grid grid-cols-3 gap-2.5">
            {/* Hydration Tracker */}
            <div className="lg-card rounded-3xl p-3.5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-[#476551]">
                <span className="material-symbols-outlined text-xl">water_drop</span>
                <button
                  type="button"
                  aria-label="Add glass of water"
                  onClick={logWater}
                  className="w-6 h-6 rounded-xl bg-[#c6e8cf] text-[#062919] flex items-center justify-center hover:bg-[#c9ebd2] active:scale-90 transition-transform cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">add</span>
                </button>
              </div>
              <div className="mt-3">
                <span className="text-lg font-bold text-[#062919] block">
                  {routine.hydrationCount}{' '}
                  <span className="text-xs text-[#424843] font-normal">/ {routine.hydrationTarget}</span>
                </span>
                <span className="text-[11px] text-[#424843]">Glasses logged</span>
              </div>
            </div>

            {/* Pelvic floor exercise */}
            <div
              onClick={() => logPelvicFloor(5)}
              className="lg-card rounded-3xl p-3.5 flex flex-col justify-between cursor-pointer hover:bg-white/90 transition-colors"
            >
              <div className="text-[#476551] flex justify-between items-center">
                <span className="material-symbols-outlined text-xl">self_improvement</span>
                <span className="text-[10px] text-[#476551] font-semibold bg-[#c6e8cf]/50 px-1.5 py-0.5 rounded-lg">+5m</span>
              </div>
              <div className="mt-3">
                <span className="text-lg font-bold text-[#062919] block">
                  {routine.pelvicFloorMinutes}{' '}
                  <span className="text-xs text-[#424843] font-normal">mins</span>
                </span>
                <span className="text-[11px] text-[#424843]">Pelvic floor done</span>
              </div>
            </div>

            {/* Blood pressure log */}
            <div
              onClick={() => setShowVitalsModal(true)}
              className="lg-card rounded-3xl p-3.5 flex flex-col justify-between cursor-pointer hover:bg-white/90 transition-colors"
            >
              <div className="text-[#476551]">
                <span className="material-symbols-outlined text-xl">monitor_heart</span>
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold text-[#062919] block">{routine.bloodPressure}</span>
                <span className="text-[11px] text-[#4b6956] font-semibold">Normal BP</span>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Access Action Grid */}
        <section className="space-y-2.5">
          <h3 className="text-base font-bold text-[#062919]">Quick Maternal Actions</h3>
          <div className="grid grid-cols-2 gap-2.5">
            {/* Log Kicks */}
            <button
              type="button"
              onClick={() => setShowKickCounterModal(true)}
              className="lg-card p-3.5 rounded-3xl text-left hover:bg-white/90 active:scale-[0.98] transition-all flex items-center gap-3 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#c9ebd2] flex items-center justify-center text-[#062919] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">footprint</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#062919] block">Log Kicks</span>
                <span className="text-[11px] text-[#424843]">Fetal movement</span>
              </div>
            </button>

            {/* Ask AI Midwife */}
            <button
              type="button"
              onClick={() => setShowMidwifeModal(true)}
              className="lg-card p-3.5 rounded-3xl text-left hover:bg-white/90 active:scale-[0.98] transition-all flex items-center gap-3 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#c6e8cf] flex items-center justify-center text-[#062919] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">smart_toy</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#062919] block">Ask Midwife</span>
                <span className="text-[11px] text-[#424843]">24/7 AI Guidance</span>
              </div>
            </button>

            {/* Vitals Log */}
            <button
              type="button"
              onClick={() => setShowVitalsModal(true)}
              className="lg-card p-3.5 rounded-3xl text-left hover:bg-white/90 active:scale-[0.98] transition-all flex items-center gap-3 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#e6e9e6] flex items-center justify-center text-[#062919] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">vital_signs</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#062919] block">Vitals Log</span>
                <span className="text-[11px] text-[#424843]">Weight, pulse, labs</span>
              </div>
            </button>

            {/* Contraction Timer */}
            <button
              type="button"
              onClick={() => setShowContractionModal(true)}
              className="lg-card p-3.5 rounded-3xl text-left hover:bg-white/90 active:scale-[0.98] transition-all flex items-center gap-3 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#e6e9e6] flex items-center justify-center text-[#062919] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">timer</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#062919] block">Contraction Timer</span>
                <span className="text-[11px] text-[#424843]">Frequency tracker</span>
              </div>
            </button>
          </div>
        </section>

        {/* Nutrition Guide Section */}
        <section className="lg-card rounded-3xl p-5 space-y-3.5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-[#062919]">Nutritional Safety Guide</h3>
              <p className="text-xs text-[#424843] leading-relaxed">Tailored for Week {profile.gestationalWeek} mineral balance</p>
            </div>
            <span className="material-symbols-outlined text-[#476551]">restaurant</span>
          </div>

          {/* Foods to Include */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center gap-1.5 text-[#476551]">
              <span className="material-symbols-outlined text-base">check_circle</span>
              <span className="text-xs font-bold uppercase tracking-wider">Foods to Include</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                { name: 'Spinach & Iron-rich greens', icon: 'nutrition', benefit: 'Boosts maternal hemoglobin and baby oxygen transport.' },
                { name: 'Wild Salmon (Omega-3)', icon: 'set_meal', benefit: 'DHA for fetal brain and retinal photoreceptor development.' },
                { name: 'Greek Yogurt & Calcium', icon: 'egg_alt', benefit: 'Essential for fetal skeletal bone density and tooth enamel.' },
                { name: 'Avocados (Folate & Fats)', icon: 'eco', benefit: 'Supports rapid maternal tissue growth and healthy placenta.' },
              ].map((item) => (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => setShowNutritionModal(item.benefit)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#c6e8cf] text-[#062919] text-xs font-medium border border-[#c9ebd2] hover:bg-[#c9ebd2] transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-xs">{item.icon}</span>
                  <span>{item.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Foods to Avoid */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center gap-1.5 text-[#ba1a1a]">
              <span className="material-symbols-outlined text-base">warning</span>
              <span className="text-xs font-bold uppercase tracking-wider">Foods to Avoid</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                { name: 'Unpasteurized cheeses', risk: 'Listeria risk can cause intrauterine infection.' },
                { name: 'High-mercury fish', risk: 'Methylmercury can harm developing fetal nervous system.' },
                { name: 'Raw sprouts & raw meats', risk: 'Salmonella and toxoplasmosis bacterial contamination risk.' },
                { name: 'Excess caffeine (>200mg)', risk: 'Crosses placenta, may affect fetal heart rate and growth.' },
              ].map((item) => (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => setShowNutritionModal(item.risk)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#ffdad6] text-[#93000a] text-xs font-medium border border-[#ba1a1a]/20 hover:bg-[#ffdad6]/80 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-xs">block</span>
                  <span>{item.name}</span>
                </button>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* ── MODALS & DRAWERS ── */}

      {/* Emergency SOS Modal */}
      {showSosModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2 text-[#ba1a1a]">
                <span className="material-symbols-outlined text-2xl" style={{ fontVariationSettings: "'FILL' 1" }}>
                  emergency
                </span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Maternal Emergency SOS</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSosModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <p className="text-xs text-[#424843] leading-relaxed">
              If you are experiencing severe bleeding, sudden abdominal pain, fluid leakage, or reduced fetal
              movement, contact your care team or emergency services immediately:
            </p>
            <div className="space-y-2 pt-1">
              <a
                href={`tel:${profile.triageLine?.phone || '8005556262'}`}
                className="w-full py-3 px-4 rounded-2xl bg-[#ba1a1a] text-white text-xs font-bold flex items-center justify-between shadow-xs hover:bg-[#ba1a1a]/90"
              >
                <span>Call 24/7 OB Triage Hotline</span>
                <span className="material-symbols-outlined text-lg">call</span>
              </a>
              <a
                href={`tel:${profile.primaryContact?.phone || '5553829104'}`}
                className="w-full py-2.5 px-4 rounded-2xl bg-[#c6e8cf] text-[#062919] text-xs font-semibold flex items-center justify-between border border-[#c1c8c1]/40"
              >
                <span>Call Partner ({profile.primaryContact?.name || 'Marcus'})</span>
                <span className="material-symbols-outlined text-lg">contact_phone</span>
              </a>
              <a
                href="tel:911"
                className="w-full py-2 px-4 rounded-2xl bg-[#f1f4f1] text-[#424843] text-xs font-semibold flex items-center justify-between"
              >
                <span>Call 911 (General Emergency)</span>
                <span className="material-symbols-outlined text-lg">local_hospital</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Notifications Drawer Modal */}
      {showNotificationsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">notifications</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Care Notifications</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowNotificationsModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="space-y-2.5 max-h-72 overflow-y-auto">
              <div className="p-3.5 rounded-2xl lg-surface">
                <div className="flex items-center justify-between text-[11px] text-[#476551] font-bold">
                  <span>CLINICAL APPOINTMENT</span>
                  <span>Tomorrow</span>
                </div>
                <p className="text-xs font-semibold text-[#062919] mt-0.5">Ultrasound anatomy scan with Dr. Jenkins</p>
                <p className="text-[11px] text-[#424843]">Please arrive 15 minutes early and hydrate moderately.</p>
              </div>
              <div className="p-3.5 rounded-2xl lg-surface">
                <div className="flex items-center justify-between text-[11px] text-[#476551] font-bold">
                  <span>MEDICATION REMINDER</span>
                  <span>1:00 PM</span>
                </div>
                <p className="text-xs font-semibold text-[#062919] mt-0.5">Prenatal Multivitamin &amp; Iron</p>
                <p className="text-[11px] text-[#424843]">Take with a full meal and avoid dairy.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Kick Counter Modal */}
      {showKickCounterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4 text-center">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">footprint</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Fetal Kick Counter</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowKickCounterModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <p className="text-xs text-[#424843]">
              Lie quietly on your left side. Tap the kick button every time you feel a distinct flutter, roll, or kick.
            </p>
            <div className="py-2">
              <span className="text-5xl font-serif font-bold text-[#062919]">{kickCount}</span>
              <span className="block text-xs text-[#476551] mt-1 font-semibold">
                {kickCount >= 10 ? '🎉 10 Kicks Milestone reached!' : 'Kicks recorded'}
              </span>
              <span className="text-[11px] text-[#727973] mt-1 block">
                Session timer: {Math.floor(kickTimerSec / 60)}m {kickTimerSec % 60}s
              </span>
            </div>
            <div className="flex justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  if (!isKickTimerRunning) handleStartKickCounter();
                  setKickCount((prev) => prev + 1);
                  showToast('info', 'Kick recorded! 💕');
                }}
                className="w-24 h-24 rounded-full bg-[#1e3f2e] text-white flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform cursor-pointer"
              >
                <span className="material-symbols-outlined text-3xl">touch_app</span>
                <span className="text-xs font-semibold mt-1">Tap Kick</span>
              </button>
            </div>
            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={handleStopAndSaveKicks}
                className="flex-1 py-2.5 rounded-2xl bg-[#c6e8cf] text-[#062919] text-xs font-bold hover:bg-[#c9ebd2] cursor-pointer"
              >
                Save &amp; Finish Session
              </button>
              <button
                type="button"
                onClick={() => {
                  setKickCount(0);
                  setKickTimerSec(0);
                }}
                className="py-2.5 px-3 rounded-2xl bg-[#f1f4f1] text-[#424843] text-xs font-semibold cursor-pointer"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Midwife AI 24/7 Guidance Modal */}
      {showMidwifeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-5 max-w-md w-full flex flex-col h-[540px]">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#c6e8cf] flex items-center justify-center text-[#062919]">
                  <span className="material-symbols-outlined text-lg">smart_toy</span>
                </div>
                <div>
                  <h3 className="font-serif font-semibold text-base text-[#062919]">24/7 Maternal AI Guide</h3>
                  <span className="text-[10px] text-[#476551] flex items-center gap-1 font-semibold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#476551]"></span>
                    Clinical Evidence-based Support
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {midwifeMessages.length > 1 && (
                  <button
                    type="button"
                    onClick={() => {
                      setMidwifeMessages([
                        {
                          id: 'init-1',
                          sender: 'midwife',
                          text: `Good morning, ${firstName}. I am your 24/7 Maternal AI Guide. How can I assist you with your pregnancy, symptoms, or medications today?`,
                          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                        },
                      ]);
                      setMidwifeError(null);
                      setMidwifeAttachedImage(null);
                    }}
                    className="text-[#727973] hover:text-[#181c1b] p-1.5 rounded-full cursor-pointer text-xs flex items-center gap-0.5"
                    title="Clear history"
                  >
                    <span className="material-symbols-outlined text-base">restart_alt</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowMidwifeModal(false)}
                  className="text-[#727973] hover:text-[#181c1b] p-1.5 rounded-full cursor-pointer"
                >
                  <span className="material-symbols-outlined text-xl">close</span>
                </button>
              </div>
            </div>

            {/* Chat message stream */}
            <div
              ref={midwifeChatScrollRef}
              className="flex-1 overflow-y-auto py-3 space-y-3 px-1 text-xs"
            >
              {midwifeMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-2xl ${
                      msg.sender === 'user'
                        ? 'bg-[#1e3f2e] text-white rounded-tr-xs'
                        : 'bg-[#f1f4f1] text-[#181c1b] rounded-tl-xs border border-[#c1c8c1]/30'
                    }`}
                  >
                    {/* Render image thumbnail if present */}
                    {msg.image && (
                      <div className="mb-2 rounded-xl overflow-hidden border border-white/20 max-w-[200px]">
                        <img
                          src={msg.image}
                          alt="Uploaded attachment"
                          className="w-full max-h-36 object-cover"
                        />
                      </div>
                    )}
                    <p className="leading-relaxed whitespace-pre-line">{msg.text}</p>
                  </div>
                  <span className="text-[10px] text-[#727973] mt-0.5 px-1">{msg.time}</span>
                </div>
              ))}

              {isMidwifeTyping && (
                <div className="flex items-center gap-1.5 text-xs text-[#476551] italic px-2">
                  <span className="w-2 h-2 rounded-full bg-[#476551] animate-bounce"></span>
                  <span className="w-2 h-2 rounded-full bg-[#476551] animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-2 h-2 rounded-full bg-[#476551] animate-bounce [animation-delay:0.4s]"></span>
                  <span>Mutterse AI is analyzing...</span>
                </div>
              )}

              {midwifeError && (
                <div className="p-3 rounded-2xl bg-[#ffdad6] border border-[#ba1a1a]/30 text-[#93000a] text-xs flex items-start gap-2">
                  <span className="material-symbols-outlined text-base shrink-0 mt-0.5">error</span>
                  <p className="leading-snug">{midwifeError}</p>
                </div>
              )}
            </div>

            {/* Attached image preview banner */}
            {midwifeAttachedImage && (
              <div className="px-2.5 py-1.5 mb-1.5 rounded-xl bg-[#c6e8cf]/40 border border-[#476551]/30 flex items-center justify-between">
                <div className="flex items-center gap-2 truncate">
                  <img
                    src={midwifeAttachedImage}
                    alt="Preview"
                    className="w-8 h-8 rounded-lg object-cover border border-[#476551]/30 shrink-0"
                  />
                  <span className="text-[11px] text-[#062919] font-medium truncate">
                    Image attached — ready to analyze
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setMidwifeAttachedImage(null)}
                  className="text-[#727973] hover:text-[#ba1a1a] p-1 cursor-pointer"
                  title="Remove image"
                >
                  <span className="material-symbols-outlined text-base">close</span>
                </button>
              </div>
            )}

            {/* Prompt input with image upload button */}
            <form onSubmit={handleSendMidwifeMessage} className="pt-2 border-t border-[#ecefeb] flex items-center gap-2">
              <input
                ref={midwifeFileInputRef}
                type="file"
                accept="image/*"
                onChange={handleMidwifeFileSelect}
                className="hidden"
              />
              <button
                type="button"
                onClick={handleMidwifePickPhoto}
                className="w-10 h-10 rounded-2xl bg-[#f1f4f1] text-[#062919] hover:bg-[#c6e8cf] flex items-center justify-center cursor-pointer transition-colors shrink-0"
                title="Attach photo or medicine image"
                aria-label="Attach photo"
              >
                <span className="material-symbols-outlined text-lg">add_a_photo</span>
              </button>

              <input
                type="text"
                value={midwifeQuery}
                onChange={(e) => setMidwifeQuery(e.target.value)}
                disabled={isMidwifeTyping}
                placeholder={midwifeAttachedImage ? "Add an optional question..." : "Ask about paracetamol, symptoms, kicks..."}
                className="flex-1 px-3.5 py-2.5 rounded-2xl border border-[#c1c8c1] text-xs focus:outline-none focus:border-[#1e3f2e] disabled:opacity-60"
              />
              <button
                type="submit"
                disabled={(!midwifeQuery.trim() && !midwifeAttachedImage) || isMidwifeTyping}
                className="w-10 h-10 rounded-2xl bg-[#1e3f2e] text-white flex items-center justify-center hover:bg-[#062919] cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all shrink-0"
                aria-label="Send message"
              >
                <span className="material-symbols-outlined text-lg">send</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Vitals Log Modal */}
      {showVitalsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">monitor_heart</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Record Daily Vitals</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowVitalsModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                logBloodPressure(`${vitalsBpSystolic}/${vitalsBpDiastolic}`, Number(vitalsPulse) || 72);
                setShowVitalsModal(false);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">
                  Blood Pressure (Systolic / Diastolic)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={vitalsBpSystolic}
                    onChange={(e) => setVitalsBpSystolic(e.target.value)}
                    placeholder="118"
                    className="px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                  />
                  <input
                    type="number"
                    value={vitalsBpDiastolic}
                    onChange={(e) => setVitalsBpDiastolic(e.target.value)}
                    placeholder="76"
                    className="px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">Pulse (bpm)</label>
                <input
                  type="number"
                  value={vitalsPulse}
                  onChange={(e) => setVitalsPulse(e.target.value)}
                  placeholder="72"
                  className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">Weight (kg)</label>
                <input
                  type="number"
                  step="0.1"
                  value={vitalsWeight}
                  onChange={(e) => setVitalsWeight(e.target.value)}
                  placeholder="62.5"
                  className="w-full px-3 py-2 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-2xl bg-[#1e3f2e] text-white text-xs font-bold hover:bg-[#062919] cursor-pointer"
              >
                Save Vitals Record
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Contraction Timer Modal */}
      {showContractionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4 text-center">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">timer</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Contraction Monitor</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (contractionTimerRef.current) clearInterval(contractionTimerRef.current);
                  setIsContractionRunning(false);
                  setShowContractionModal(false);
                }}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="py-3">
              <span className="text-4xl font-serif font-bold text-[#062919]">
                {contractionDurationSec}s
              </span>
              <span className="block text-xs text-[#476551] mt-1 font-semibold">
                {isContractionRunning ? 'Contraction in progress... Breathe deeply' : 'Ready to time next wave'}
              </span>
            </div>
            <button
              type="button"
              onClick={handleToggleContractionTimer}
              className={`w-full py-3 rounded-2xl text-xs font-bold transition-all shadow-sm cursor-pointer ${
                isContractionRunning
                  ? 'bg-[#ba1a1a] text-white hover:bg-[#ba1a1a]/90'
                  : 'bg-[#1e3f2e] text-white hover:bg-[#062919]'
              }`}
            >
              {isContractionRunning ? 'Stop Contraction Wave' : 'Start Contraction Wave'}
            </button>
            <div className="text-[11px] text-[#424843] bg-[#f1f4f1] p-3 rounded-2xl text-left">
              <strong>The 5-1-1 Rule:</strong> If contractions occur every 5 minutes, lasting 1 minute each, for 1 full
              hour, contact your labor ward or triage line.
            </div>
          </div>
        </div>
      )}

      {/* Nutrition Detail Info Modal */}
      {showNutritionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-5 max-w-xs w-full space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <span className="font-semibold text-xs text-[#062919] uppercase tracking-wider">
                Clinical Nutrition Note
              </span>
              <button
                type="button"
                onClick={() => setShowNutritionModal(null)}
                className="text-[#727973] hover:text-[#181c1b]"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>
            <p className="text-xs text-[#424843] leading-relaxed">{showNutritionModal}</p>
            <button
              type="button"
              onClick={() => setShowNutritionModal(null)}
              className="w-full py-2 rounded-2xl bg-[#c6e8cf] text-[#062919] text-xs font-bold"
            >
              Understood
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
