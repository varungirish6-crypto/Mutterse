import React, { useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import type { TabId } from '../../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  const navItems: { id: TabId; label: string; icon: string }[] = [
    { id: 'home', label: 'Dashboard', icon: 'dashboard' },
    { id: 'scan', label: 'Scan', icon: 'document_scanner' },
    { id: 'care', label: 'Care', icon: 'favorite' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];

  const handleTabPress = useCallback((id: TabId) => {
    setActiveTab(id);
  }, [setActiveTab]);

  return (
    <nav
      aria-label="Bottom Navigation"
      className="fixed bottom-0 left-0 right-0 z-50 lg-nav"
      style={{ paddingBottom: 'max(8px, env(safe-area-inset-bottom, 0px))' }}
    >
      <div className="w-full max-w-2xl mx-auto flex justify-around items-center px-2 py-1.5">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleTabPress(item.id)}
              aria-label={item.label}
              className="relative flex flex-col items-center justify-center transition-all duration-150 cursor-pointer min-w-[56px] min-h-[48px] select-none"
            >
              {/* Active pill background */}
              {isActive && (
                <span
                  className="absolute inset-0 bg-[#c6e8cf]/80 backdrop-blur-sm rounded-2xl pointer-events-none transition-all duration-200"
                  aria-hidden="true"
                />
              )}

              <span
                className={`relative flex flex-col items-center px-3.5 py-1.5 rounded-2xl transition-all duration-150 pointer-events-none ${
                  isActive
                    ? 'text-[#062919] font-bold scale-[1.02]'
                    : 'text-[#363c37] font-semibold hover:text-[#062919] active:scale-95'
                }`}
              >
                <span
                  className="material-symbols-outlined text-2xl leading-none"
                  style={{
                    fontVariationSettings: isActive
                      ? "'FILL' 1, 'wght' 700"
                      : "'FILL' 0, 'wght' 500",
                  }}
                >
                  {item.icon}
                </span>
                <span className="text-xs mt-0.5 leading-tight">{item.label}</span>
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
