import React from 'react';
import { useApp } from '../../context/AppContext';
import type { TabId } from '../../types';

export const DesktopNav: React.FC = () => {
  const { activeTab, setActiveTab, profile, logout } = useApp();

  const navItems: { id: TabId; label: string; icon: string }[] = [
    { id: 'home', label: 'Dashboard', icon: 'dashboard' },
    { id: 'scan', label: 'Scan', icon: 'document_scanner' },
    { id: 'care', label: 'Care', icon: 'favorite' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];

  return (
    <header className="hidden md:flex w-full lg-desktop-nav px-6 py-3.5 sticky top-0 z-50">
      <div className="max-w-5xl w-full mx-auto flex items-center justify-between">
        {/* Brand */}
        <div
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-2xl bg-[#c6e8cf] flex items-center justify-center text-[#062919] group-hover:scale-105 transition-transform">
            <span className="material-symbols-outlined text-2xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              spa
            </span>
          </div>
          <div>
            <span className="font-serif font-bold text-xl text-[#062919] block leading-none">Mutterse</span>
            <span className="text-[11px] text-[#476551] font-semibold">Maternal Healthcare Suite</span>
          </div>
        </div>

        {/* Center Nav Links */}
        <nav className="flex items-center gap-2 bg-[#f1f4f1] p-1.5 rounded-2xl border border-[#c1c8c1]/30">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#1e3f2e] text-white font-bold shadow-xs'
                    : 'text-[#2d332e] font-semibold hover:text-[#062919] hover:bg-white/60'
                }`}
              >
                <span
                  className="material-symbols-outlined text-lg"
                  style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                >
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Profile Pill & Quick Logout */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className="flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-[#f1f4f1] hover:bg-[#ecefeb] border border-[#c1c8c1]/40 transition-colors cursor-pointer"
          >
            <div className="w-7 h-7 rounded-full overflow-hidden border border-[#c1c8c1]">
              <img src={profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" />
            </div>
            <div className="text-left text-xs">
              <span className="font-bold text-[#062919] block leading-tight">{profile.name}</span>
              <span className="text-[10px] text-[#476551]">Week {profile.gestationalWeek}</span>
            </div>
          </button>

          <button
            type="button"
            onClick={logout}
            aria-label="Sign out"
            className="p-2 rounded-full text-[#ba1a1a] hover:bg-[#ffdad6]/40 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};
