import React from 'react';
import { SettingsScreen } from '../settings/SettingsScreen';

export const ProfileScreen: React.FC = () => {
  return <SettingsScreen />;
};

export default ProfileScreen;
