import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import type { BloodGroup, BirthPlanType } from '../../types';

interface ProfileSetupScreenProps {
  onComplete?: () => void;
}

export default function ProfileSetupScreen({ onComplete }: ProfileSetupScreenProps) {
  const { profile, updateProfile, setIsSetupMode, setActiveTab, showToast } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State initialized with current profile
  const [name, setName] = useState(profile.name || 'Elena Vance');
  const [dob, setDob] = useState(profile.dob || '1993-10-14');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>(profile.bloodGroup || 'O+');
  const [avatarUrl, setAvatarUrl] = useState(profile.avatarUrl);

  const [gestationalWeek, setGestationalWeek] = useState<number>(profile.gestationalWeek || 24);
  const [lmp, setLmp] = useState(profile.lmp || '2023-11-12');
  const [edd, setEdd] = useState(profile.edd || '2024-08-18');
  const [deliveryHospital, setDeliveryHospital] = useState(
    profile.deliveryHospital || "St. Jude Women's Hospital - Labor & Delivery Ward"
  );
  const [birthPlan, setBirthPlan] = useState<BirthPlanType>(profile.birthPlan || 'Natural Vaginal');

  const [allergies, setAllergies] = useState(profile.allergies || 'Penicillin, seasonal pollen');

  const [primaryName, setPrimaryName] = useState(profile.primaryContact?.name || 'Marcus Vance');
  const [primaryRel, setPrimaryRel] = useState(profile.primaryContact?.relationship || 'Partner');
  const [primaryPhone, setPrimaryPhone] = useState(profile.primaryContact?.phone || '+1 (555) 382-9104');
  const [primarySos, setPrimarySos] = useState(profile.primaryContact?.sosAlert ?? true);

  const [secondaryName, setSecondaryName] = useState(profile.secondaryContact?.name || 'Clara Vance');
  const [secondaryRel, setSecondaryRel] = useState(profile.secondaryContact?.relationship || 'Mother');
  const [secondaryPhone, setSecondaryPhone] = useState(profile.secondaryContact?.phone || '+1 (555) 491-2209');

  const [triageFacility, setTriageFacility] = useState(
    profile.triageLine?.facility || 'St. Jude Labor & Delivery 24/7 Triage Desk'
  );
  const [triagePhone, setTriagePhone] = useState(profile.triageLine?.phone || '+1 (800) 555-MAMA (6262)');

  const [doctor, setDoctor] = useState(profile.doctor || 'Dr. Sarah Jenkins, MD - St. Jude Maternal Clinic');

  const [doulaName, setDoulaName] = useState(profile.doula?.name || 'Maya Lin, CD(DONA) - Holistic Birth Care');
  const [doulaPhone, setDoulaPhone] = useState(profile.doula?.phone || '+1 (555) 720-4491');

  const [insuranceProvider, setInsuranceProvider] = useState(profile.insurance?.provider || 'BlueCross Anthem');
  const [groupNumber, setGroupNumber] = useState(profile.insurance?.groupNumber || 'MTR-88219');
  const [policyId, setPolicyId] = useState(profile.insurance?.policyId || 'BC-99401827-01');

  // Blood groups
  const bloodGroups: BloodGroup[] = ['O+', 'A+', 'B+', 'AB+', 'O-', 'A-', 'B-', 'AB-'];

  // Birth plan preferences
  const birthPlans: BirthPlanType[] = [
    'Natural Vaginal',
    'Water Birth',
    'Planned Cesarean',
    'Undecided / Flexible',
  ];

  // Trimester calculation
  const getTrimester = (w: number) => {
    if (w <= 12) return 'First Trimester';
    if (w <= 26) return 'Second Trimester';
    return 'Third Trimester';
  };

  // Auto-calculate EDD when LMP changes (Naegele's rule: +280 days)
  const handleLmpChange = (val: string) => {
    setLmp(val);
    try {
      const d = new Date(val);
      if (!isNaN(d.getTime())) {
        d.setDate(d.getDate() + 280);
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        setEdd(`${yyyy}-${mm}-${dd}`);
      }
    } catch {
      // Keep existing EDD
    }
  };

  // Image Upload Handler – compresses to max 800×800px, JPEG 0.7 before storing
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        showToast('error', 'Image size should be less than 10MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const img = new Image();
          img.onload = () => {
            const MAX = 800;
            let { width, height } = img;
            if (width > MAX || height > MAX) {
              if (width > height) {
                height = Math.round((height * MAX) / width);
                width = MAX;
              } else {
                width = Math.round((width * MAX) / height);
                height = MAX;
              }
            }
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(img, 0, 0, width, height);
              const compressed = canvas.toDataURL('image/jpeg', 0.7);
              setAvatarUrl(compressed);
              showToast('success', 'Profile photo updated! ✨');
            }
          };
          img.src = reader.result;
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveAndContinue = () => {
    if (!name.trim()) {
      showToast('warning', "Mother's name is required.");
      return;
    }

    updateProfile({
      name: name.trim(),
      dob,
      bloodGroup,
      avatarUrl,
      gestationalWeek: Number(gestationalWeek) || 24,
      gestationalDay: 3,
      lmp,
      edd,
      deliveryHospital,
      birthPlan,
      allergies,
      primaryContact: {
        name: primaryName,
        relationship: primaryRel,
        phone: primaryPhone,
        sosAlert: primarySos,
      },
      secondaryContact: {
        name: secondaryName,
        relationship: secondaryRel,
        phone: secondaryPhone,
      },
      triageLine: {
        facility: triageFacility,
        phone: triagePhone,
      },
      doctor,
      doula: {
        name: doulaName,
        phone: doulaPhone,
      },
      insurance: {
        provider: insuranceProvider,
        groupNumber,
        policyId,
      },
      profileSetupComplete: true,
    });

    setIsSetupMode(false);
    setActiveTab('home');
    if (onComplete) onComplete();
  };

  const handleSkip = () => {
    setIsSetupMode(false);
    setActiveTab('home');
    if (onComplete) onComplete();
  };

  return (
    <div className="text-[#181c1b] antialiased min-h-screen flex justify-center selection:bg-[#c6e8cf] selection:text-[#062919]">
      {/* Mobile Viewport Shell (Android max-w-lg container) */}
      <div className="w-full max-w-lg min-h-screen flex flex-col relative pb-36">
        {/* Top App Bar (Task Setup Bar) */}
        <header className="sticky top-0 z-40 wallpaper-header backdrop-blur-md px-5 py-2.5 flex items-center justify-between border-b border-[#c1c8c1]/30">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSkip}
              aria-label="Go back"
              className="w-10 h-10 rounded-full flex items-center justify-center text-[#062919] hover:bg-[#f1f4f1] transition-colors duration-150 active:opacity-80"
            >
              <span className="material-symbols-outlined text-[22px]">arrow_back</span>
            </button>
            <div>
              <span className="text-[11px] font-bold text-[#476551] block tracking-wider uppercase">
                Step 1 of 3
              </span>
              <h1 className="text-lg font-bold text-[#062919] tracking-tight">Profile Setup</h1>
            </div>
          </div>
          <button
            type="button"
            onClick={handleSkip}
            className="text-xs font-bold text-[#424843] hover:text-[#062919] px-2 py-1 transition-colors duration-150 cursor-pointer"
          >
            Skip
          </button>
        </header>

        {/* Progress indicator bar */}
        <div className="w-full h-1 bg-[#ecefeb]">
          <div className="w-1/3 h-full bg-[#1e3f2e] rounded-r-full transition-all duration-300"></div>
        </div>

        {/* Main Content Canvas */}
        <main className="px-5 pt-6 space-y-6">
          {/* Serene Welcome Editorial */}
          <section className="space-y-1">
            <h2 className="text-2xl font-serif font-bold text-[#062919] tracking-tight">
              Welcome to your sanctuary
            </h2>
            <p className="text-sm text-[#424843] leading-relaxed">
              Let’s personalize your maternal companion. Your medical details ensure clinical precision, guidance,
              and peace of mind throughout your journey.
            </p>
          </section>

          {/* Centered Elegant Avatar Upload */}
          <section className="flex flex-col items-center justify-center pt-1">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handlePhotoUpload}
            />
            <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              <div className="w-28 h-28 rounded-full p-1 bg-white ring-1 ring-[#c1c8c1]/60 shadow-sm overflow-hidden flex items-center justify-center">
                <img
                  src={avatarUrl}
                  alt="Mother profile"
                  className="w-full h-full object-cover rounded-full group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <button
                type="button"
                aria-label="Upload mother profile photo"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-[#062919] text-white flex items-center justify-center ring-2 ring-[#f7faf7] shadow-md hover:bg-[#1e3f2e] transition-colors duration-150 active:scale-95"
              >
                <span className="material-symbols-outlined text-[18px]">photo_camera</span>
              </button>
            </div>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="mt-2 text-xs font-semibold text-[#062919] hover:underline transition-all duration-150 cursor-pointer"
            >
              Tap to add or change photo
            </button>
          </section>

          {/* FORM SECTION 1: Personal Information */}
          <section className="lg-card rounded-3xl p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-[#ecefeb]">
              <span className="material-symbols-outlined text-[#476551] text-[20px]">person</span>
              <h3 className="font-bold text-[#062919] text-base">Personal Information</h3>
            </div>

            <div className="space-y-4">
              {/* Mother's Full Name */}
              <div>
                <label className="block text-xs font-bold text-[#424843] mb-1.5" htmlFor="fullName">
                  Mother's full name
                </label>
                <div className="relative">
                  <input
                    id="fullName"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full h-12 px-4 rounded-2xl bg-white/80 border border-[#c1c8c1]/60 text-sm text-[#181c1b] focus:outline-none focus:border-[#1e3f2e] transition-colors"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-[#476551]">
                    <span className="material-symbols-outlined text-[20px]">badge</span>
                  </div>
                </div>
              </div>

              {/* Date of Birth */}
              <div>
                <label className="block text-xs font-bold text-[#424843] mb-1.5" htmlFor="dob">
                  Date of birth
                </label>
                <div className="relative">
                  <input
                    id="dob"
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full h-12 px-4 rounded-2xl bg-white/80 border border-[#c1c8c1]/60 text-sm text-[#181c1b] focus:outline-none focus:border-[#1e3f2e] transition-colors"
                  />
                </div>
              </div>

              {/* Blood Group Chips */}
              <div>
                <span className="block text-xs font-bold text-[#424843] mb-2">Blood group</span>
                <div className="grid grid-cols-4 gap-2">
                  {bloodGroups.map((bg) => {
                    const isSelected = bloodGroup === bg;
                    return (
                      <button
                        key={bg}
                        type="button"
                        onClick={() => setBloodGroup(bg)}
                        className={`h-10 rounded-full flex items-center justify-center text-xs font-semibold transition-all duration-150 cursor-pointer ${
                          isSelected
                            ? 'bg-[#c6e8cf] text-[#062919] ring-1 ring-[#062919]/30 shadow-xs'
                            : 'bg-[#f1f4f1] text-[#424843] hover:text-[#062919] ring-1 ring-[#c1c8c1]/40 active:scale-95'
                        }`}
                      >
                        {bg}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>

          {/* FORM SECTION 2: Pregnancy Details */}
          <section className="lg-card rounded-3xl p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-[#ecefeb]">
              <span className="material-symbols-outlined text-[#476551] text-[20px]">pregnant_woman</span>
              <h3 className="font-bold text-[#062919] text-base">Pregnancy Details</h3>
            </div>

            <div className="space-y-4">
              {/* Gestational Timeline Visual Anchor */}
              <div className="p-4 rounded-2xl bg-[#f1f4f1] border border-[#c1c8c1]/30 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-semibold text-[#476551] uppercase">
                      Gestational Progress
                    </span>
                    <p className="text-base font-semibold text-[#062919]">
                      Week {gestationalWeek}{' '}
                      <span className="text-xs text-[#424843] font-normal">
                        · {getTrimester(gestationalWeek)}
                      </span>
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-[#c6e8cf] flex items-center justify-center text-[#062919]">
                    <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      spa
                    </span>
                  </div>
                </div>

                {/* Milestone Slider */}
                <div className="pt-2">
                  <input
                    type="range"
                    min="1"
                    max="40"
                    value={gestationalWeek}
                    onChange={(e) => setGestationalWeek(Number(e.target.value))}
                    className="w-full accent-[#1e3f2e] h-2 bg-[#e0e3e0] rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] font-medium text-[#424843] mt-1.5">
                    <span>Week 1</span>
                    <span className="text-[#062919] font-bold">Week {gestationalWeek} (Current)</span>
                    <span>Week 40</span>
                  </div>
                </div>
              </div>

              {/* Last Menstrual Period Date */}
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1.5" htmlFor="lmp">
                  Last menstrual period (LMP)
                </label>
                <div className="relative">
                  <input
                    id="lmp"
                    type="date"
                    value={lmp}
                    onChange={(e) => handleLmpChange(e.target.value)}
                    className="w-full h-12 px-4 rounded-2xl bg-white/80 border border-[#c1c8c1]/60 text-sm text-[#181c1b] focus:outline-none focus:border-[#1e3f2e] transition-colors"
                  />
                </div>
              </div>

              {/* Estimated Due Date (EDD) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-[#424843]" htmlFor="edd">
                    Estimated Due Date (EDD)
                  </label>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-xl bg-[#c6e8cf]/70 text-[#2f4d3b] text-[11px] font-semibold">
                    <span className="material-symbols-outlined text-[13px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      auto_awesome
                    </span>
                    Auto-calculated
                  </span>
                </div>
                <div className="relative">
                  <input
                    id="edd"
                    type="date"
                    value={edd}
                    onChange={(e) => setEdd(e.target.value)}
                    className="w-full h-12 px-4 rounded-2xl bg-[#f1f4f1] border border-[#c1c8c1]/50 text-sm text-[#062919] font-semibold focus:outline-none"
                  />
                </div>
                <p className="text-xs text-[#476551] mt-1 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px]">info</span>
                  Calculated using standard 280-day Naegele's clinical rule
                </p>
              </div>

              {/* Planned Delivery Hospital / Birth Center */}
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1.5" htmlFor="deliveryHospital">
                  Planned Delivery Hospital / Birth Center
                </label>
                <div className="relative">
                  <input
                    id="deliveryHospital"
                    type="text"
                    value={deliveryHospital}
                    onChange={(e) => setDeliveryHospital(e.target.value)}
                    placeholder="e.g. Hospital or birthing center name"
                    className="w-full h-12 px-4 rounded-2xl bg-white/80 border border-[#c1c8c1]/60 text-sm text-[#181c1b] focus:outline-none focus:border-[#1e3f2e] transition-colors"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-[#476551]">
                    <span className="material-symbols-outlined text-[20px]">local_hospital</span>
                  </div>
                </div>
              </div>

              {/* Birth Plan Preference */}
              <div>
                <span className="block text-xs font-semibold text-[#424843] mb-2">Birth Plan Preference</span>
                <div className="grid grid-cols-2 gap-2">
                  {birthPlans.map((plan) => {
                    const isSelected = birthPlan === plan;
                    return (
                      <button
                        key={plan}
                        type="button"
                        onClick={() => setBirthPlan(plan)}
                        className={`h-11 px-3.5 rounded-2xl flex items-center justify-between text-xs font-semibold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#c6e8cf] text-[#062919] ring-1 ring-[#062919]/25 shadow-xs'
                            : 'bg-[#f1f4f1] text-[#424843] hover:text-[#062919] ring-1 ring-[#c1c8c1]/40'
                        }`}
                      >
                        <span>{plan}</span>
                        <span
                          className={`material-symbols-outlined text-[18px] ${
                            isSelected ? 'text-[#062919]' : 'text-[#727973]'
                          }`}
                        >
                          {isSelected ? 'check_circle' : 'radio_button_unchecked'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>

          {/* FORM SECTION 3: Medical & Safety Contacts */}
          <section className="lg-card rounded-3xl p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-[#ecefeb]">
              <span className="material-symbols-outlined text-[#476551] text-[20px]">health_and_safety</span>
              <h3 className="font-bold text-[#062919] text-base">Medical &amp; Safety Contacts</h3>
            </div>

            <div className="space-y-4">
              {/* Known Allergies */}
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1.5" htmlFor="allergies">
                  Known allergies &amp; sensitivities
                </label>
                <div className="relative">
                  <input
                    id="allergies"
                    type="text"
                    value={allergies}
                    onChange={(e) => setAllergies(e.target.value)}
                    placeholder="List any drug or food sensitivities"
                    className="w-full h-12 px-4 rounded-2xl bg-white/80 border border-[#c1c8c1]/60 text-sm text-[#181c1b] focus:outline-none focus:border-[#1e3f2e] transition-colors"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-[#476551]">
                    <span className="material-symbols-outlined text-[20px]">warning</span>
                  </div>
                </div>
              </div>

              {/* Primary Emergency Contact Card */}
              <div className="p-4 rounded-2xl bg-[#f1f4f1]/80 border border-[#c1c8c1]/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#062919] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[18px] text-[#476551]">emergency</span>
                    Primary Emergency Contact
                  </span>
                  <span className="px-2.5 py-0.5 rounded-xl bg-[#c6e8cf]/70 text-[#062919] text-[11px] font-semibold">
                    {primaryRel || 'Partner'}
                  </span>
                </div>
                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">
                      Full name &amp; relationship
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={primaryName}
                        onChange={(e) => setPrimaryName(e.target.value)}
                        placeholder="Marcus Vance"
                        className="col-span-2 h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                      <input
                        type="text"
                        value={primaryRel}
                        onChange={(e) => setPrimaryRel(e.target.value)}
                        placeholder="Partner"
                        className="h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">Phone number</label>
                    <div className="relative">
                      <input
                        type="tel"
                        value={primaryPhone}
                        onChange={(e) => setPrimaryPhone(e.target.value)}
                        className="w-full h-10 px-3.5 pr-10 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-[#476551]">
                        <span className="material-symbols-outlined text-[18px]">call</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      id="sosAlertPrimary"
                      type="checkbox"
                      checked={primarySos}
                      onChange={(e) => setPrimarySos(e.target.checked)}
                      className="w-4 h-4 rounded text-[#062919] accent-[#1e3f2e] cursor-pointer"
                    />
                    <label htmlFor="sosAlertPrimary" className="text-xs text-[#424843] cursor-pointer">
                      Notify automatically on maternal SOS alerts
                    </label>
                  </div>
                </div>
              </div>

              {/* Secondary Emergency Contact Card */}
              <div className="p-4 rounded-2xl bg-[#f1f4f1]/80 border border-[#c1c8c1]/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#062919] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[18px] text-[#476551]">contact_phone</span>
                    Secondary Emergency Contact
                  </span>
                  <span className="px-2.5 py-0.5 rounded-xl bg-[#e0e3e0] text-[#424843] text-[11px] font-semibold">
                    {secondaryRel || 'Mother'}
                  </span>
                </div>
                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">
                      Full name &amp; relationship
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={secondaryName}
                        onChange={(e) => setSecondaryName(e.target.value)}
                        placeholder="Clara Vance"
                        className="col-span-2 h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                      <input
                        type="text"
                        value={secondaryRel}
                        onChange={(e) => setSecondaryRel(e.target.value)}
                        placeholder="Mother"
                        className="h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">Phone number</label>
                    <div className="relative">
                      <input
                        type="tel"
                        value={secondaryPhone}
                        onChange={(e) => setSecondaryPhone(e.target.value)}
                        className="w-full h-10 px-3.5 pr-10 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-[#476551]">
                        <span className="material-symbols-outlined text-[18px]">call</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 24/7 Maternal Care & OB Triage Line */}
              <div className="p-4 rounded-2xl bg-[#c9ebd2]/30 border border-[#adcfb7]/50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#062919] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[18px] text-[#476551]">support_agent</span>
                    24/7 Maternal Care &amp; OB Triage Line
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-xl bg-[#c6e8cf] text-[#2f4d3b] text-[11px] font-semibold">
                    <span className="material-symbols-outlined text-[13px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      sensors
                    </span>
                    On-Call
                  </span>
                </div>
                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">
                      Triage Unit / Hospital Line
                    </label>
                    <input
                      type="text"
                      value={triageFacility}
                      onChange={(e) => setTriageFacility(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">Direct hotline</label>
                    <div className="relative">
                      <input
                        type="tel"
                        value={triagePhone}
                        onChange={(e) => setTriagePhone(e.target.value)}
                        className="w-full h-10 px-3.5 pr-10 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs font-semibold text-[#062919] focus:outline-none focus:border-[#1e3f2e]"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-[#476551]">
                        <span className="material-symbols-outlined text-[18px]">phone_in_talk</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Attending Obstetrician / Doctor */}
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1.5" htmlFor="doctor">
                  Attending Obstetrician / Doctor
                </label>
                <div className="relative">
                  <input
                    id="doctor"
                    type="text"
                    value={doctor}
                    onChange={(e) => setDoctor(e.target.value)}
                    placeholder="Doctor name and hospital/clinic"
                    className="w-full h-12 px-4 rounded-2xl bg-white/80 border border-[#c1c8c1]/60 text-sm text-[#181c1b] focus:outline-none focus:border-[#1e3f2e] transition-colors"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-[#476551]">
                    <span className="material-symbols-outlined text-[20px]">medical_services</span>
                  </div>
                </div>
              </div>

              {/* Doula / Birth Support Specialist */}
              <div className="p-4 rounded-2xl bg-[#f1f4f1]/80 border border-[#c1c8c1]/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#062919] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[18px] text-[#476551]">volunteer_activism</span>
                    Doula / Birth Support Specialist
                  </span>
                  <span className="px-2.5 py-0.5 rounded-xl bg-[#c6e8cf]/70 text-[#2f4d3b] text-[11px] font-semibold">
                    Registered
                  </span>
                </div>
                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">
                      Doula name &amp; credential
                    </label>
                    <input
                      type="text"
                      value={doulaName}
                      onChange={(e) => setDoulaName(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">Direct phone</label>
                    <div className="relative">
                      <input
                        type="tel"
                        value={doulaPhone}
                        onChange={(e) => setDoulaPhone(e.target.value)}
                        className="w-full h-10 px-3.5 pr-10 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-[#476551]">
                        <span className="material-symbols-outlined text-[18px]">call</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Maternal Health Insurance & Clinical ID */}
              <div className="p-4 rounded-2xl bg-[#f1f4f1] border border-[#c1c8c1]/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#062919] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[18px] text-[#476551]">badge</span>
                    Maternal Health Insurance &amp; Clinical ID
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-xl bg-[#c6e8cf] text-[#2f4d3b] text-[11px] font-semibold">
                    <span className="material-symbols-outlined text-[13px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      check_circle
                    </span>
                    Pre-authorized
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">
                      Insurance provider
                    </label>
                    <input
                      type="text"
                      value={insuranceProvider}
                      onChange={(e) => setInsuranceProvider(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#424843] mb-1">Group #</label>
                    <input
                      type="text"
                      value={groupNumber}
                      onChange={(e) => setGroupNumber(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-[#424843] mb-1">Policy / Member ID</label>
                  <input
                    type="text"
                    value={policyId}
                    onChange={(e) => setPolicyId(e.target.value)}
                    className="w-full h-10 px-3.5 rounded-2xl bg-white border border-[#c1c8c1]/60 text-xs text-[#181c1b] focus:outline-none focus:border-[#1e3f2e]"
                  />
                </div>
              </div>

              {/* Assurance Disclaimer */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-[#c9ebd2]/30 border border-[#adcfb7]/40">
                <span className="material-symbols-outlined text-[#476551] text-[18px] shrink-0 mt-0.5">
                  verified_user
                </span>
                <p className="text-xs text-[#2f4d3b] leading-relaxed">
                  Encrypted to HIPAA-standard clinical confidentiality. Your maternal records are only accessible to
                  you and your authorized care team.
                </p>
              </div>
            </div>
          </section>
        </main>

        {/* Floating / Sticky Bottom Primary Action Panel */}
        <aside className="fixed bottom-0 left-0 w-full z-50 pointer-events-none">
          <div className="w-full max-w-lg mx-auto px-5 pb-6 pt-3 bg-gradient-to-t from-white/90 via-white/60 to-transparent flex flex-col pointer-events-auto backdrop-blur-sm">
            <button
              type="button"
              onClick={handleSaveAndContinue}
              className="w-full h-14 rounded-2xl bg-[#062919] hover:bg-[#1e3f2e] text-white font-semibold text-sm flex items-center justify-center gap-2 cta-shadow active:scale-[0.98] transition-all duration-150 cursor-pointer"
            >
              <span>Save &amp; Continue to Care Plan</span>
              <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
