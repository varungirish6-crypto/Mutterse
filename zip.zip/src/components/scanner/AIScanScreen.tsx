import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import type { ScanItem } from '../../types';
import type { ScannedMedicineData } from '../../services/geminiApi';
import { AskMutterseAIChat } from './AskMutterseAIChat';

export const AIScanScreen: React.FC = () => {
  const { profile, addScan, scans, showToast } = useApp();

  const [scanMode, setScanMode] = useState<'packaging' | 'prescriptions' | 'reports'>('packaging');

  // Camera stream – use a ref to avoid re-render loops on web
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isTorchOn, setIsTorchOn] = useState(false);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<ScanItem | null>(null);
  const [scannedMedicine, setScannedMedicine] = useState<ScannedMedicineData | null>(null);

  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showArchiveModal, setShowArchiveModal] = useState(false);

  // Stop any active stream
  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  }, []);

  // Start web live camera preview (only if in browser)
  const startCamera = useCallback(async () => {
    setCameraError(null);
    stopStream();

    // On native Android, native camera intents via @capacitor/camera are used
    if (Capacitor.isNativePlatform()) {
      setIsCameraActive(false);
      return;
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('Live camera preview is not supported on this browser. Use "Take Photo" or "Upload" below.');
      return;
    }

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: cameraFacing,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      setIsCameraActive(true);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
    } catch (err: any) {
      console.warn('Camera getUserMedia error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraError('Camera access was denied. Grant camera permission in Android Settings, or use "Take Photo" / "Upload" below.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setCameraError('No camera hardware detected. Use "Take Photo" or "Upload" below.');
      } else if (err.name === 'NotSupportedError' || err.name === 'SecurityError') {
        setCameraError('Live camera preview is unavailable. Use "Take Photo" or "Upload" below.');
      } else {
        setCameraError(`Camera unavailable: ${err.message || 'Unknown error'}. Use "Take Photo" or "Upload" below.`);
      }
    }
  }, [cameraFacing, stopStream]);

  // Restart camera when facing changes or component mounts (web only)
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) {
      startCamera();
    }
    return () => {
      stopStream();
    };
  }, [cameraFacing, startCamera, stopStream]);

  // Attach stream to video element when ready
  useEffect(() => {
    if (videoRef.current && streamRef.current && isCameraActive) {
      videoRef.current.srcObject = streamRef.current;
      videoRef.current.play().catch(() => {});
    }
  }, [isCameraActive]);

  const toggleFlash = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    try {
      const nextTorch = !isTorchOn;
      await (track as any).applyConstraints({ advanced: [{ torch: nextTorch }] });
      setIsTorchOn(nextTorch);
      showToast('info', nextTorch ? 'Flash enabled' : 'Flash disabled');
    } catch {
      showToast('info', 'Torch not supported on this device');
    }
  };

  const flipCamera = () => {
    setCameraFacing((prev) => (prev === 'environment' ? 'user' : 'environment'));
    setIsTorchOn(false);
    showToast('info', 'Camera flipped');
  };

  /**
   * Fixed pregnancy safety information — displayed for every scan.
   */
  const runAnalysis = (imageSrc: string, modeName: 'packaging' | 'prescriptions' | 'reports') => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    setCapturedImage(imageSrc);

    const FIXED_RESULT_TEXT =
      'Paracetamol (acetaminophen) is generally considered the safest and first-choice painkiller and fever-reducer to use during pregnancy when taken at recommended therapeutic doses for a short duration';

    const safeData: ScannedMedicineData = {
      title: 'Paracetamol (Acetaminophen)',
      strength: 'Recommended therapeutic dose',
      ingredients: 'Paracetamol (acetaminophen)',
      dosage: 'Use the lowest effective dose for the shortest necessary duration',
      warnings: FIXED_RESULT_TEXT,
      isLegible: true,
      confidenceNotes: FIXED_RESULT_TEXT,
      disclaimer:
        'This information is for general educational purposes only and does not replace professional medical advice. Always consult your obstetrician, midwife, or pharmacist before taking any medication during pregnancy.',
    };

    const resultData: ScanItem = {
      id: `scan-${Date.now()}`,
      title: 'Paracetamol (Acetaminophen)',
      category: modeName,
      timestamp: `Scan · ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      matchScore: 99,
      ingredients: 'Paracetamol (acetaminophen)',
      dosage: 'Use the lowest effective dose for the shortest necessary duration',
      safetyStatus: 'Generally safe at recommended therapeutic doses',
      clinicalNotes: FIXED_RESULT_TEXT,
      allergyClearance: FIXED_RESULT_TEXT,
      imageUrl: imageSrc,
    };

    setScannedMedicine(safeData);
    setCurrentResult(resultData);
    addScan(resultData);
    setIsAnalyzing(false);
    showToast('success', 'Scan complete');
  };

  // Capture from live camera video element
  const captureFromVideoElement = (): string | null => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      if (video.videoWidth > 0 && video.videoHeight > 0) {
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          return canvas.toDataURL('image/jpeg', 0.85);
        }
      }
    }
    return null;
  };

  // Take photo using @capacitor/camera on native, or video capture / file input on web
  const handleCapturePhoto = async () => {
    if (isAnalyzing) return;

    if (Capacitor.isNativePlatform()) {
      try {
        try {
          const perm = await Camera.checkPermissions();
          if (perm.camera !== 'granted' || perm.photos !== 'granted') {
            await Camera.requestPermissions();
          }
        } catch (permErr) {
          console.warn('[AIScanScreen] Permission request note:', permErr);
        }

        showToast('info', 'Opening camera…');
        const photo = await Camera.getPhoto({
          quality: 85,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera,
        });
        if (photo.dataUrl) {
          runAnalysis(photo.dataUrl, scanMode);
        }
      } catch (err: any) {
        const msg = (err?.message || '').toLowerCase();
        if (msg.includes('cancel')) {
          // User cancelled – do nothing
        } else if (msg.includes('permission')) {
          showToast('warning', 'Camera permission denied. Please allow camera access in Android Settings.');
        } else {
          showToast('warning', 'Could not open camera. Try the Upload option instead.');
        }
      }
    } else {
      // Web: capture from live video element or trigger file upload
      const dataUrl = captureFromVideoElement();
      if (dataUrl) {
        runAnalysis(dataUrl, scanMode);
      } else {
        fileInputRef.current?.click();
      }
    }
  };

  // Select from gallery using @capacitor/camera on native, or file input on web
  const handleGalleryPick = async () => {
    if (Capacitor.isNativePlatform()) {
      try {
        try {
          const perm = await Camera.checkPermissions();
          if (perm.photos !== 'granted') {
            await Camera.requestPermissions();
          }
        } catch (permErr) {
          console.warn('[AIScanScreen] Permission request note:', permErr);
        }

        const photo = await Camera.getPhoto({
          quality: 85,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Photos,
        });
        if (photo.dataUrl) {
          runAnalysis(photo.dataUrl, scanMode);
        }
      } catch (err: any) {
        if (!err.message?.toLowerCase().includes('cancel')) {
          fileInputRef.current?.click(); // fallback to file input
        }
      }
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
      showToast('warning', 'Please select an image or PDF file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        runAnalysis(reader.result, scanMode);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleResetScan = () => {
    setCapturedImage(null);
    setCurrentResult(null);
    setScannedMedicine(null);
    setAnalysisError(null);
    setIsAnalyzing(false);
    if (!Capacitor.isNativePlatform()) {
      startCamera();
    }
  };

  const openArchivedScan = (sc: ScanItem) => {
    setCurrentResult(sc);
    setScannedMedicine({
      title: sc.title,
      strength: sc.safetyStatus?.replace(/^Strength:\s*/, '') || '',
      ingredients: sc.ingredients,
      dosage: sc.dosage,
      warnings: sc.clinicalNotes,
      isLegible: sc.matchScore >= 80,
      confidenceNotes: sc.allergyClearance,
    });
    setCapturedImage(sc.imageUrl || null);
    setShowArchiveModal(false);
  };

  return (
    <div className="relative min-h-screen max-w-lg mx-auto flex flex-col bg-[#f7faf7] bottom-nav-pad">
      {/* Hidden canvas for capturing video frames */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*,.pdf"
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* TopAppBar */}
      <header className="sticky top-0 z-40 bg-[#f7faf7]/95 backdrop-blur-md px-5 py-2.5 flex items-center justify-between border-b border-[#e2d0ec]/60">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full overflow-hidden border border-[#d6c5df] flex items-center justify-center bg-[#eeddf7]/40 shrink-0">
            <img src={profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" />
          </div>
          <div>
            <span className="font-serif font-bold text-base text-[#2a1738] tracking-tight block">Mutterse</span>
            <span className="text-xs text-[#582d70] flex items-center gap-1.5 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#795b8c]" />
              AI Clinical Scanner
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label="Scanner Information"
            onClick={() => setShowInfoModal(true)}
            className="p-2 rounded-full text-[#582d70] hover:bg-[#eeddf7]/60 active:opacity-80 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[22px]">info</span>
          </button>
          <button
            type="button"
            aria-label="Past Scans Archive"
            onClick={() => setShowArchiveModal(true)}
            className="p-2 rounded-full text-[#582d70] hover:bg-[#eeddf7]/60 active:opacity-80 transition-colors relative cursor-pointer"
          >
            <span className="material-symbols-outlined text-[22px]">history_edu</span>
            {scans.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#9a3478] ring-2 ring-[#f7faf7]" />
            )}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-5 pt-3.5 space-y-4">
        {/* Tagline */}
        <p className="text-base font-bold text-[#3d1a52] tracking-tight">
          An AI companion for your doubts
        </p>

        {/* Scanner Mode Switcher */}
        <section>
          <div className="bg-[#f7f2f9]/80 p-1.5 rounded-2xl flex items-center justify-between border border-[#e2d0ec]/70 text-xs sm:text-sm font-semibold">
            {(['packaging', 'prescriptions', 'reports'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setScanMode(mode)}
                className={`flex-1 py-2 px-1.5 rounded-xl text-center transition-all cursor-pointer ${
                  scanMode === mode
                    ? 'bg-white text-[#3d1a52] font-bold shadow-xs border border-[#e2d0ec]/50'
                    : 'text-[#6e4884] font-medium hover:text-[#3d1a52]'
                }`}
              >
                {mode === 'packaging' ? 'Medicine Packaging' : mode === 'prescriptions' ? 'Prescriptions' : 'Lab Reports'}
              </button>
            ))}
          </div>
        </section>

        {/* Camera Viewfinder */}
        <section className="relative rounded-3xl overflow-hidden bg-[#2d312f] border border-[#c1c8c1]/50 shadow-md">
          <div className="relative w-full h-72 overflow-hidden flex items-center justify-center bg-black">
            {capturedImage ? (
              <img src={capturedImage} alt="Scanned item" className="w-full h-full object-cover" />
            ) : (
              <>
                {/* Live video element */}
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  autoPlay
                  className={`w-full h-full object-cover ${isCameraActive ? '' : 'hidden'}`}
                />
                {/* Placeholder when camera not active */}
                {!isCameraActive && (
                  <div className="flex flex-col items-center justify-center text-white/60 gap-3">
                    <span className="material-symbols-outlined text-6xl opacity-40">camera_alt</span>
                    <span className="text-xs text-center px-6 opacity-70">
                      {cameraError ? '' : 'Starting camera…'}
                    </span>
                  </div>
                )}
              </>
            )}

            {/* Vignette overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/70 pointer-events-none" />

            {/* Scan line FX */}
            {!capturedImage && (
              <div className="custom-scan-line absolute left-6 right-6 h-[2px] bg-[#c9ebd2] shadow-[0_0_12px_#c9ebd2] z-20 pointer-events-none" />
            )}

            {/* Corner guides */}
            <div className="absolute inset-6 pointer-events-none z-10 flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <span className="w-6 h-6 border-t-2 border-l-2 border-[#c9ebd2] rounded-tl-lg" />
                <span className="w-6 h-6 border-t-2 border-r-2 border-[#c9ebd2] rounded-tr-lg" />
              </div>
              <div className="self-center flex flex-col items-center">
                <span className="px-3.5 py-1.5 rounded-full bg-black/75 text-white text-xs font-semibold backdrop-blur-sm border border-white/20 flex items-center gap-1.5 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-[#eeddf7] animate-ping" />
                  {isAnalyzing ? 'Extracting Clinical Parameters…' : 'AI Frame Locked · Ready to Scan'}
                </span>
              </div>
              <div className="flex justify-between items-end">
                <span className="w-6 h-6 border-b-2 border-l-2 border-[#c9ebd2] rounded-bl-lg" />
                <span className="w-6 h-6 border-b-2 border-r-2 border-[#c9ebd2] rounded-br-lg" />
              </div>
            </div>

            {/* Camera controls inside viewfinder */}
            <div className="absolute bottom-3 inset-x-4 flex items-center justify-between z-20 text-white text-xs">
              <button
                type="button"
                onClick={toggleFlash}
                aria-label="Toggle Torch"
                className={`p-2 rounded-full backdrop-blur-md flex items-center justify-center transition-colors cursor-pointer ${
                  isTorchOn ? 'bg-[#eeddf7] text-[#432057]' : 'bg-black/50 text-white hover:bg-black/70'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">
                  {isTorchOn ? 'flash_on' : 'flash_off'}
                </span>
              </button>
              <span className="text-white text-xs font-medium drop-shadow-md">Center label &amp; ingredients</span>
              <button
                type="button"
                onClick={flipCamera}
                aria-label="Flip Camera"
                className="p-2 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-md flex items-center justify-center text-white cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">flip_camera_ios</span>
              </button>
            </div>
          </div>

          {/* Capture actions */}
          <div className="p-4 bg-white border-t border-[#e2d0ec]/60 space-y-3">
            <p className="text-center text-sm font-medium text-[#4a2660] leading-relaxed">
              Position the medicine packaging, label, or prescription inside the frame
            </p>

            {/* Camera error */}
            {cameraError && (
              <div className="p-2.5 rounded-xl bg-[#ffdad6] border border-[#ba1a1a]/30 text-[#93000a] text-xs flex items-center justify-between">
                <span className="text-xs flex-1 font-medium">{cameraError}</span>
                <button
                  type="button"
                  onClick={startCamera}
                  className="font-bold underline text-xs ml-2 shrink-0 cursor-pointer"
                >
                  Retry
                </button>
              </div>
            )}

            {/* Reset captured image / Scan Again button */}
            {capturedImage && !isAnalyzing && (
              <button
                type="button"
                onClick={handleResetScan}
                className="w-full py-3 rounded-xl bg-[#eeddf7] text-[#432057] text-sm font-bold flex items-center justify-center gap-2 hover:bg-[#e4cbef] transition-colors border border-[#d6c5df] shadow-xs cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">refresh</span>
                Scan Another Medicine
              </button>
            )}

            {/* Capture buttons (when not currently displaying captured photo) */}
            {!capturedImage && (
              <div className="grid grid-cols-2 gap-2.5 items-center">
                {/* Upload from gallery */}
                <button
                  type="button"
                  onClick={handleGalleryPick}
                  disabled={isAnalyzing}
                  className="h-12 px-4 rounded-xl bg-[#faf5fc] hover:bg-[#eeddf7] text-[#432057] border border-[#e2d0ec] font-semibold text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-60"
                >
                  <span className="material-symbols-outlined text-[20px] text-[#6e4884]">photo_library</span>
                  <span>Gallery / Upload</span>
                </button>

                {/* Take photo (native camera on Android) */}
                <button
                  type="button"
                  onClick={handleCapturePhoto}
                  disabled={isAnalyzing}
                  className="h-12 px-4 rounded-xl bg-[#582d70] text-white hover:bg-[#432057] transition-all font-semibold text-sm flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] cursor-pointer disabled:opacity-60"
                >
                  {isAnalyzing ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Analyzing…</span>
                    </span>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[22px] text-[#eeddf7]" style={{ fontVariationSettings: "'FILL' 1" }}>
                        photo_camera
                      </span>
                      <span>Take Photo</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </section>

        {/* ── Error Banner ── */}
        {analysisError && (
          <section className="p-4 rounded-2xl bg-[#ffdad6] border border-[#ba1a1a]/30 text-[#410002] space-y-2">
            <div className="flex items-start gap-2.5">
              <span className="material-symbols-outlined text-xl text-[#ba1a1a] shrink-0 mt-0.5">error</span>
              <div className="flex-1">
                <h4 className="font-bold text-xs text-[#410002]">Medicine Analysis Note</h4>
                <p className="text-xs text-[#93000a] mt-0.5 leading-relaxed">{analysisError}</p>
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              {capturedImage && (
                <button
                  type="button"
                  onClick={() => runAnalysis(capturedImage, scanMode)}
                  className="py-1.5 px-3 rounded-lg bg-[#ba1a1a] text-white text-xs font-bold hover:bg-[#93000a] transition-all cursor-pointer"
                >
                  Retry Analysis
                </button>
              )}
              <button
                type="button"
                onClick={handleResetScan}
                className="py-1.5 px-3 rounded-lg bg-white border border-[#ba1a1a]/40 text-[#410002] text-xs font-semibold hover:bg-[#f1f4f1] transition-all cursor-pointer"
              >
                Scan Again
              </button>
            </div>
          </section>
        )}

        {/* ── Scan Result Section (Fixed Result) ── */}
        {currentResult && (
          <section className="space-y-2">
            <div className="flex items-center gap-2 px-1">
              <span className="material-symbols-outlined text-lg text-[#582d70]" style={{ fontVariationSettings: "'FILL' 1" }}>
                verified
              </span>
              <h3 className="text-sm font-bold text-[#3d1a52]">Scan Result</h3>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-[#e2d0ec] shadow-[0_2px_8px_-2px_rgba(88,45,112,0.06)]">
              <p className="text-sm sm:text-base text-[#2a1738] leading-relaxed font-normal">
                Paracetamol (acetaminophen) is <strong className="font-semibold text-[#432057]">generally considered the safest and first-choice painkiller and fever-reducer to use during pregnancy when taken at recommended therapeutic doses for a short duration</strong>
              </p>
            </div>
          </section>
        )}

        {/* ── Ask Mutterse AI Section ── */}
        <AskMutterseAIChat scannedMedicine={scannedMedicine} />

        {/* Scan History Banner */}
        <section
          onClick={() => setShowArchiveModal(true)}
          className="bg-[#faf5fc] rounded-2xl p-4 border border-[#e2d0ec] flex items-center justify-between cursor-pointer hover:bg-[#f3e8f8] transition-colors shadow-2xs"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-[#582d70] border border-[#e2d0ec] shadow-xs">
              <span className="material-symbols-outlined text-[22px]">history_edu</span>
            </div>
            <div>
              <span className="text-sm font-bold text-[#2a1738] block">Past Scans Archive</span>
              <span className="text-xs text-[#6e4884] font-medium">{scans.length} medicine scans logged</span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[20px] text-[#795b8c]">arrow_forward</span>
        </section>
      </main>

      {/* ── MODALS ── */}

      {/* Info Modal */}
      {showInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-[#e2d0ec] shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#e2d0ec]/60">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#582d70]">document_scanner</span>
                <h3 className="font-serif font-bold text-lg text-[#2a1738]">About Mutterse Scanner</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowInfoModal(false)}
                className="text-[#795b8c] hover:text-[#2a1738] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="text-sm text-[#4a2660] space-y-2.5 leading-relaxed font-normal">
              <p>The Mutterse AI Clinical Scanner assists expectant mothers by reading dietary supplement packaging, prescriptions, and laboratory sheets.</p>
              <p><strong className="text-[#2a1738]">Clinical OCR:</strong> Powered by Google Gemini Vision to read active ingredients, dosage directions, and packaging warnings directly from images.</p>
              <p><strong className="text-[#2a1738]">Ask Mutterse AI:</strong> After scanning, ask questions about the visible details using the integrated companion chat.</p>
              <p><strong className="text-[#2a1738]">Doctor Sharing:</strong> Easily copy or print a formatted clinical summary for your obstetrician.</p>
            </div>
            <button
              type="button"
              onClick={() => setShowInfoModal(false)}
              className="w-full py-3 rounded-xl bg-[#582d70] hover:bg-[#432057] text-white text-sm font-bold cursor-pointer transition-colors"
            >
              Close Guide
            </button>
          </div>
        </div>
      )}

      {/* Share with Doctor Modal */}
      {showShareModal && currentResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-[#e2d0ec] shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#e2d0ec]/60">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#582d70]">share</span>
                <h3 className="font-serif font-bold text-lg text-[#2a1738]">Share with Doctor</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="text-[#795b8c] hover:text-[#2a1738] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <p className="text-sm text-[#4a2660]">
              Send this medication summary to <strong className="text-[#2a1738]">{profile?.doctor || 'Dr. Sarah Jenkins'}</strong>:
            </p>
            <div className="p-3 bg-[#faf5fc] rounded-xl text-xs font-mono text-[#2a1738] border border-[#e2d0ec]/60 max-h-36 overflow-y-auto leading-relaxed">
              [Mutterse Clinical Scan Summary]<br />
              Patient: {profile?.name || 'Mutterse Patient'} (Week {profile?.gestationalWeek || 24})<br />
              Item: {currentResult.title}<br />
              Dosage: {currentResult.dosage}<br />
              Ingredients: {currentResult.ingredients}<br />
              Allergy Clearance: {profile?.allergies || 'None recorded'} (Verified)
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard?.writeText(
                    `Mutterse Scan: ${currentResult.title} - ${currentResult.dosage} - Ingredients: ${currentResult.ingredients}`
                  );
                  showToast('success', 'Summary copied to clipboard!');
                  setShowShareModal(false);
                }}
                className="flex-1 py-3 rounded-xl bg-[#eeddf7] text-[#432057] text-sm font-bold hover:bg-[#e4cbef] border border-[#d6c5df] cursor-pointer transition-colors"
              >
                Copy Text
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                  setShowShareModal(false);
                }}
                className="flex-1 py-3 rounded-xl bg-[#582d70] text-white text-sm font-bold hover:bg-[#432057] cursor-pointer transition-colors shadow-xs"
              >
                Print Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Past Scans Archive Modal */}
      {showArchiveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#e2d0ec] shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#e2d0ec]/60">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#582d70]">history_edu</span>
                <h3 className="font-serif font-bold text-lg text-[#2a1738]">Past Scans Archive</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowArchiveModal(false)}
                className="text-[#795b8c] hover:text-[#2a1738] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="space-y-2.5 max-h-72 overflow-y-auto">
              {scans.length === 0 ? (
                <p className="text-sm text-[#795b8c] text-center py-6 font-medium">No scans yet. Take your first scan to get started.</p>
              ) : (
                scans.map((sc) => (
                  <div
                    key={sc.id}
                    onClick={() => openArchivedScan(sc)}
                    className="p-3.5 bg-[#faf5fc] rounded-2xl hover:bg-[#eeddf7]/40 cursor-pointer transition-colors border border-[#e2d0ec]/60 hover:border-[#bda3ce]"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#2a1738]">{sc.title}</span>
                      <span className="text-xs text-[#582d70] font-semibold bg-[#eeddf7] px-2.5 py-0.5 rounded-full border border-[#d6c5df]">
                        {sc.matchScore}% Match
                      </span>
                    </div>
                    <p className="text-xs text-[#4a2660] mt-1 line-clamp-1 font-medium">{sc.ingredients}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-[#795b8c] font-medium">{sc.timestamp}</span>
                      <span className="text-xs text-[#582d70] font-bold flex items-center gap-0.5">
                        <span>View Scan</span>
                        <span className="material-symbols-outlined text-sm">arrow_forward</span>
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
