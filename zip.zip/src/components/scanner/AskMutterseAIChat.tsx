import React, { useState, useRef, useEffect } from 'react';
import type { ScannedMedicineData, ChatMessage } from '../../services/geminiApi';
import { sendMedicineChatMessage } from '../../services/geminiApi';
import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

interface AskMutterseAIChatProps {
  scannedMedicine: ScannedMedicineData | null;
}

export const AskMutterseAIChat: React.FC<AskMutterseAIChatProps> = ({ scannedMedicine }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [attachedMime, setAttachedMime] = useState<string>('image/jpeg');

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (JPEG, PNG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      const dataUrl = loadEvt.target?.result as string;
      if (dataUrl) {
        setAttachedImage(dataUrl);
        setAttachedMime(file.type || 'image/jpeg');
        setError(null);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handlePickPhoto = async () => {
    if (Capacitor.isNativePlatform()) {
      try {
        const photo = await Camera.getPhoto({
          quality: 85,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Prompt,
        });
        if (photo.dataUrl) {
          setAttachedImage(photo.dataUrl);
          setAttachedMime(photo.format ? `image/${photo.format}` : 'image/jpeg');
          setError(null);
        }
      } catch (err: any) {
        if (!err.message?.toLowerCase().includes('cancel')) {
          fileInputRef.current?.click();
        }
      }
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    const imageToSend = attachedImage;
    const mimeToSend = attachedMime;

    if ((!query && !imageToSend) || isLoading) return;

    setError(null);
    setInput('');
    setAttachedImage(null);

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query || (imageToSend ? 'Please analyze this medicine/packaging image and explain its use, safety during pregnancy, precautions, and when to seek medical advice.' : ''),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      image: imageToSend || undefined,
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setIsLoading(true);

    try {
      const replyText = await sendMedicineChatMessage(
        userMessage.text,
        newHistory,
        scannedMedicine,
        imageToSend,
        mimeToSend
      );
      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: replyText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      console.error('[AskMutterseAI] Error:', err);
      setError(err.message || 'Unable to connect to Mutterse AI. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    if (messages.length === 0) return;
    setMessages([]);
    setError(null);
    setAttachedImage(null);
  };

  // Preset suggestion pills for quick queries
  const suggestions = scannedMedicine && scannedMedicine.title && scannedMedicine.title !== 'Unidentified Medicine'
    ? [
        `What are the visible ingredients in ${scannedMedicine.title}?`,
        'What directions are printed on this packaging?',
        'Does the label mention any specific storage precautions?',
      ]
    : [
        'How should I read medicine label directions safely?',
        'What questions should I ask my doctor about my vitamins?',
        'Where can I check ingredient safety with my pharmacist?',
      ];

  return (
    <section aria-label="Ask Mutterse AI" className="space-y-3 pt-2">
      {/* Header with Title and Clear Chat Button */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-[#eeddf7] flex items-center justify-center text-[#582d70] shadow-xs">
            <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
              auto_awesome
            </span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#2a1738] leading-none">Ask Mutterse AI</h3>
            <span className="text-xs text-[#6e4884] font-medium">Medicine &amp; Label Q&amp;A Companion</span>
          </div>
        </div>

        {messages.length > 0 && (
          <button
            type="button"
            onClick={handleClearChat}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6e4884] hover:text-[#3d1a52] hover:bg-[#eeddf7]/70 transition-colors cursor-pointer"
            title="Clear conversation history"
          >
            <span className="material-symbols-outlined text-base">delete_sweep</span>
            <span>Clear</span>
          </button>
        )}
      </div>

      {/* Main Glass Chat Container */}
      <div className="rounded-3xl bg-gradient-to-b from-[#faf5fc] via-[#f7eef9] to-[#f3e6f7] border border-[#e2d0ec] shadow-sm overflow-hidden flex flex-col">
        {/* Active Context Banner */}
        {scannedMedicine && scannedMedicine.title && (
          <div className="px-4 py-2.5 bg-[#eeddf7]/80 border-b border-[#e2d0ec]/70 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 truncate">
              <span className="material-symbols-outlined text-sm text-[#582d70]">medication</span>
              <span className="text-[#582d70] font-bold">Active Context:</span>
              <span className="text-[#2a1738] font-bold truncate">{scannedMedicine.title}</span>
            </div>
            {scannedMedicine.strength && (
              <span className="text-xs text-[#582d70] bg-white px-2.5 py-0.5 rounded-lg shrink-0 font-semibold border border-[#e2d0ec]">
                {scannedMedicine.strength}
              </span>
            )}
          </div>
        )}

        {/* Messages Stream */}
        <div
          ref={scrollRef}
          className="p-4 space-y-3.5 min-h-[220px] max-h-[360px] overflow-y-auto overscroll-contain"
        >
          {messages.length === 0 ? (
            /* Empty State */
            <div className="py-6 px-3 flex flex-col items-center justify-center text-center space-y-3 text-[#582d70]">
              <div className="w-12 h-12 rounded-3xl bg-white border border-[#e2d0ec] flex items-center justify-center text-[#582d70] shadow-xs">
                <span className="material-symbols-outlined text-2xl">chat_bubble_outline</span>
              </div>
              <p className="text-base font-bold text-[#2a1738]">
                {scannedMedicine ? 'Ask me about the medicine information shown above.' : 'Ready to help with your medicine questions.'}
              </p>
              <p className="text-sm text-[#582d70] max-w-sm leading-relaxed font-normal">
                Ask about visible ingredients, strength, or label instructions. You can tap a suggested prompt below or type your own question.
              </p>

              {/* Suggested Questions */}
              <div className="w-full pt-2 flex flex-col gap-2">
                {suggestions.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSend(s)}
                    className="w-full text-left p-3 px-4 rounded-2xl bg-white hover:bg-[#faf5fc] text-sm font-semibold text-[#3d1a52] border border-[#e2d0ec] hover:border-[#bda3ce] transition-all cursor-pointer shadow-2xs active:scale-[0.99]"
                  >
                    💬 {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Conversation Messages */
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#582d70] text-white rounded-tr-xs shadow-xs font-medium'
                      : 'bg-white text-[#2a1738] rounded-tl-xs border border-[#e2d0ec] shadow-xs font-normal'
                  }`}
                >
                  {/* Render image thumbnail if attached */}
                  {msg.image && (
                    <div className="mb-2 rounded-xl overflow-hidden border border-white/20 max-w-[200px]">
                      <img
                        src={msg.image}
                        alt="Attached medicine"
                        className="w-full max-h-36 object-cover"
                      />
                    </div>
                  )}
                  <p className="whitespace-pre-line">{msg.text}</p>
                </div>
                <span className="text-xs text-[#795b8c] mt-1 px-1 font-medium">{msg.time}</span>
              </div>
            ))
          )}

          {/* AI Responding Indicator */}
          {isLoading && (
            <div className="flex flex-col items-start space-y-1">
              <div className="p-3.5 rounded-2xl rounded-tl-xs bg-white border border-[#e2d0ec] flex items-center gap-2 text-sm text-[#582d70] shadow-xs">
                <span className="w-2 h-2 rounded-full bg-[#795b8c] animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-[#795b8c] animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-[#795b8c] animate-bounce [animation-delay:0.4s]" />
                <span className="font-semibold text-sm text-[#582d70] ml-1">Mutterse AI is reviewing label details…</span>
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-3.5 rounded-2xl bg-[#ffdad6] border border-[#ba1a1a]/30 text-[#93000a] text-xs sm:text-sm flex items-start gap-2">
              <span className="material-symbols-outlined text-lg shrink-0 mt-0.5">error</span>
              <p className="leading-snug font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Attached image preview banner */}
        {attachedImage && (
          <div className="px-3 py-2 bg-[#eeddf7]/90 border-t border-[#e2d0ec] flex items-center justify-between">
            <div className="flex items-center gap-2 truncate">
              <img
                src={attachedImage}
                alt="Preview"
                className="w-8 h-8 rounded-lg object-cover border border-[#bda3ce] shrink-0"
              />
              <span className="text-xs text-[#582d70] font-semibold truncate">
                Image attached — ready to analyze
              </span>
            </div>
            <button
              type="button"
              onClick={() => setAttachedImage(null)}
              className="text-[#795b8c] hover:text-[#93000a] p-1 cursor-pointer"
              title="Remove image"
            >
              <span className="material-symbols-outlined text-base">close</span>
            </button>
          </div>
        )}

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-white border-t border-[#e2d0ec] flex items-center gap-2"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />

          <button
            type="button"
            onClick={handlePickPhoto}
            className="w-11 h-11 rounded-2xl bg-white border border-[#d6c5df] text-[#582d70] hover:bg-[#eeddf7]/70 flex items-center justify-center cursor-pointer transition-colors shrink-0 shadow-2xs"
            title="Attach photo or medicine image"
            aria-label="Attach photo"
          >
            <span className="material-symbols-outlined text-[20px]">add_a_photo</span>
          </button>

          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            placeholder={
              attachedImage
                ? 'Add an optional question or send to analyze...'
                : scannedMedicine
                ? `Ask about ${scannedMedicine.title}...`
                : 'Ask a question about your medicine...'
            }
            className="flex-1 px-4 py-2.5 rounded-2xl bg-white border border-[#d6c5df] text-sm text-[#2a1738] placeholder:text-[#8e749c] focus:outline-none focus:border-[#795b8c] focus:ring-2 focus:ring-[#795b8c]/20 transition-all disabled:opacity-60"
          />

          <button
            type="submit"
            disabled={(!input.trim() && !attachedImage) || isLoading}
            aria-label="Send message"
            className="w-11 h-11 rounded-2xl bg-[#582d70] text-white flex items-center justify-center hover:bg-[#432057] active:scale-95 transition-all shadow-xs cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
          >
            <span className="material-symbols-outlined text-[20px]">send</span>
          </button>
        </form>

        {/* Informational Disclaimer Footer */}
        <div className="px-4 py-2.5 bg-[#f4ebf7] border-t border-[#e2d0ec]/60 flex items-start gap-2.5 text-[#6e4884]">
          <span className="material-symbols-outlined text-sm shrink-0 mt-0.5 text-[#582d70]" style={{ fontVariationSettings: "'FILL' 1" }}>
            shield
          </span>
          <p className="text-xs leading-relaxed">
            <strong className="text-[#3d1a52]">Informational Support Only:</strong> Mutterse AI answers are generated for label explanations and do not substitute for professional medical advice, diagnosis, or treatment. Always consult your obstetrician or pharmacist.
          </p>
        </div>
      </div>
    </section>
  );
};
