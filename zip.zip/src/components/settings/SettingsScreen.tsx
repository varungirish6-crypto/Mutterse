import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getApiBaseUrl, setApiBaseUrl } from '../../services/geminiApi';

export const SettingsScreen: React.FC = () => {
  const {
    profile,
    medicines,
    toggleMedicine,
    addMedicine,
    settings,
    updateSettings,
    setIsSetupMode,
    logout,
    showToast,
  } = useApp();

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showContactsModal, setShowContactsModal] = useState(false);
  const [showMedicinesModal, setShowMedicinesModal] = useState(false);
  const [showClinicModal, setShowClinicModal] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showFaqModal, setShowFaqModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [showDisclaimerModal, setShowDisclaimerModal] = useState(false);
  const [showServerModal, setShowServerModal] = useState(false);
  const [serverUrlInput, setServerUrlInput] = useState('');

  // New medicine form state in modal
  const [newMedName, setNewMedName] = useState('');
  const [newMedDosage, setNewMedDosage] = useState('');
  const [newMedTime, setNewMedTime] = useState('12:00 PM');

  // Change password form
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');

  const handleAddMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedName.trim()) return;
    addMedicine({
      name: newMedName.trim(),
      dosage: newMedDosage.trim() || '1 tablet daily',
      time: newMedTime,
      taken: false,
      category: 'Prescribed Medicine',
      safetyNote: 'Take with full glass of water',
    });
    setNewMedName('');
    setNewMedDosage('');
  };

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass.length < 6) {
      showToast('warning', 'New password must be at least 6 characters.');
      return;
    }
    showToast('success', 'Security password successfully updated!');
    setShowPasswordModal(false);
    setCurrentPass('');
    setNewPass('');
  };

  return (
    <div className="w-full min-h-[100dvh] flex flex-col bottom-nav-pad overflow-x-hidden">
      {/* TopAppBar */}
      <header className="sticky top-0 z-40 wallpaper-header border-b border-[#c1c8c1]/40 px-4 sm:px-5 pb-3 flex flex-col gap-3 backdrop-blur-md safe-header-pad">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full overflow-hidden border border-[#c1c8c1] bg-[#e6e9e6] flex items-center justify-center shrink-0">
              <img src={profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="font-serif font-bold text-lg text-[#062919] tracking-tight">Mutterse</h1>
              <p className="text-[11px] text-[#424843]">Settings &amp; Preferences</p>
            </div>
          </div>
          <button
            type="button"
            aria-label="Notifications"
            className="w-9 h-9 flex items-center justify-center rounded-full text-[#424843] hover:bg-[#f1f4f1] transition-colors duration-150 active:scale-95 cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">notifications</span>
          </button>
        </div>

        {/* Quick Search Form Control */}
        <div className="relative">
          <span className="material-symbols-outlined absolute left-3 top-2.5 text-[#727973] text-[20px]">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search settings, clinical logs, alerts..."
            className="w-full pl-10 pr-4 py-2.5 lg-input rounded-2xl text-xs text-[#181c1b] placeholder:text-[#727973] focus:outline-none transition-colors"
          />
        </div>
      </header>

      {/* Main Content Stream */}
      <main className="px-5 pt-4 flex flex-col gap-5">
        {/* User Profile Summary Module */}
        <section className="lg-card-elevated rounded-3xl p-5">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#c9ebd2]">
                <img src={profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" />
              </div>
              <span className="absolute bottom-0 right-0 w-4 h-4 bg-[#476551] rounded-full border-2 border-white flex items-center justify-center">
                <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-[#062919] truncate">{profile.name}</h2>
                <span className="px-2 py-0.5 bg-[#c6e8cf] text-[#062919] rounded-full text-[10px] font-bold">
                  Active Patient
                </span>
              </div>
              <p className="text-xs text-[#424843] mt-0.5">
                Week {profile.gestationalWeek} of pregnancy · EDD {profile.edd}
              </p>

              <div className="mt-2.5 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsSetupMode(true)}
                  className="px-3 py-1.5 bg-[#f1f4f1] hover:bg-[#ecefeb] text-[#062919] text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 active:opacity-80 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">edit</span>
                  <span>Edit Profile</span>
                </button>
                <div className="flex items-center text-[#476551] text-[11px] font-semibold">
                  <span className="material-symbols-outlined text-[16px] mr-1">verified_user</span>
                  <span>Verified Record</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Group 1: Care & Clinical Coordination */}
        <section className="space-y-1.5">
          <div className="px-1 flex items-center justify-between">
            <span className="text-xs font-bold text-[#476551] uppercase tracking-wider">
              Care &amp; Clinical Coordination
            </span>
            <span className="text-[11px] text-[#727973]">Clinical Tier 1</span>
          </div>

          <div className="lg-card rounded-3xl divide-y divide-white/50 overflow-hidden">
            {/* Item 1: Emergency Contacts */}
            <div
              onClick={() => setShowContactsModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">contact_emergency</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Manage Emergency Contacts</p>
                  <p className="text-xs text-[#424843] mt-0.5">
                    {profile.primaryContact?.name || 'Marcus Vance'} (Partner), {profile.doctor || 'Dr. Jenkins'}
                  </p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>

            {/* Item 2: Medicine Reminders */}
            <div
              onClick={() => setShowMedicinesModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">schedule</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-[#062919]">Medicine Reminders &amp; Schedule</p>
                    <span className="w-2 h-2 rounded-full bg-[#476551]"></span>
                  </div>
                  <p className="text-xs text-[#424843] mt-0.5">
                    {medicines.map((m) => m.name.split(' ')[0]).join(', ')} ({medicines.length} scheduled)
                  </p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>

            {/* Item 3: Doctor & Clinic */}
            <div
              onClick={() => setShowClinicModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">local_hospital</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Doctor &amp; Clinic Access</p>
                  <p className="text-xs text-[#424843] mt-0.5">
                    Syncing vitals &amp; lab results with {profile.deliveryHospital || 'St. Jude Clinic'}
                  </p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>
          </div>
        </section>

        {/* Group 2: Preferences & Alerts */}
        <section className="space-y-1.5">
          <div className="px-1 flex items-center justify-between">
            <span className="text-xs font-bold text-[#476551] uppercase tracking-wider">
              Preferences &amp; Alerts
            </span>
            <span className="text-[11px] text-[#727973]">Customization</span>
          </div>

          <div className="lg-card rounded-3xl divide-y divide-white/50 overflow-hidden">
            {/* Notifications Switch */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-start gap-3 pr-4">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">notifications_active</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Push Alerts &amp; Prompts</p>
                  <p className="text-xs text-[#424843] mt-0.5">
                    Daily kick count alerts, hydration check-ins, prenatal reminders
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={settings.notificationsEnabled}
                  onChange={(e) => updateSettings({ notificationsEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#e0e3e0] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#c1c8c1] after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1e3f2e]"></div>
              </label>
            </div>

            {/* Language Dropdown Item */}
            <div
              onClick={() => setShowLanguageModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">translate</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Language</p>
                  <p className="text-xs text-[#424843] mt-0.5">Regional obstetric terminology</p>
                </div>
              </div>
              <div className="flex items-center gap-1 text-[#181c1b] text-xs font-semibold">
                <span>
                  {settings.language === 'en-US'
                    ? 'English (US)'
                    : settings.language === 'es'
                    ? 'Español'
                    : settings.language === 'fr'
                    ? 'Français'
                    : 'Hindi (हिंदी)'}
                </span>
                <span className="material-symbols-outlined text-[#727973] text-[20px]">
                  arrow_drop_down
                </span>
              </div>
            </div>

            {/* Theme */}
            <div
              onClick={() => setShowThemeModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">palette</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Theme &amp; Display</p>
                  <p className="text-xs text-[#424843] mt-0.5">Calm tactile palette</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-[#181c1b] text-xs font-semibold">
                <span>
                  {settings.theme === 'cream'
                    ? 'Warm Maternal Cream'
                    : settings.theme === 'sage'
                    ? 'Pure Sage Green'
                    : 'Botanical Night'}
                </span>
                <span className="material-symbols-outlined text-[#727973] text-[18px]">
                  chevron_right
                </span>
              </div>
            </div>

            {/* Reduced Motion Accessibility Toggle */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-start gap-3 pr-4">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">motion_photos_off</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Reduced Motion</p>
                  <p className="text-xs text-[#424843] mt-0.5">
                    Disables floating and pulse animations for vestibular comfort
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={settings.reducedMotion}
                  onChange={(e) => updateSettings({ reducedMotion: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#e0e3e0] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#c1c8c1] after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1e3f2e]"></div>
              </label>
            </div>
          </div>
        </section>

        {/* Group 3: Privacy & Security */}
        <section className="space-y-1.5">
          <div className="px-1 flex items-center justify-between">
            <span className="text-xs font-bold text-[#476551] uppercase tracking-wider">
              Privacy &amp; Security
            </span>
            <span className="text-[11px] text-[#727973]">HIPAA Compliant</span>
          </div>

          <div className="lg-card rounded-3xl divide-y divide-white/50 overflow-hidden">
            {/* AI Server Connection */}
            <div
              onClick={() => {
                setServerUrlInput(getApiBaseUrl());
                setShowServerModal(true);
              }}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">dns</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">AI Server Endpoint</p>
                  <p className="text-xs text-[#424843] mt-0.5 truncate max-w-[210px]">
                    {getApiBaseUrl() || 'Default (Vite Dev Server Proxy)'}
                  </p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>

            {/* HIPAA and Data */}
            <div
              onClick={() => setShowPrivacyModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">encrypted</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Data Privacy &amp; HIPAA Standards</p>
                  <p className="text-xs text-[#424843] mt-0.5">
                    256-bit encryption for ultrasound &amp; lab uploads
                  </p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>

            {/* Biometric Lock */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-start gap-3 pr-4">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">fingerprint</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Biometric App Lock</p>
                  <p className="text-xs text-[#424843] mt-0.5">
                    Require fingerprint or Face ID before viewing clinical notes
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={settings.biometricLock}
                  onChange={(e) => {
                    updateSettings({ biometricLock: e.target.checked });
                    showToast(
                      'info',
                      e.target.checked
                        ? 'Biometric lock enabled (TouchID / FaceID)'
                        : 'Biometric lock disabled'
                    );
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#e0e3e0] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#c1c8c1] after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1e3f2e]"></div>
              </label>
            </div>

            {/* Security & Password */}
            <div
              onClick={() => setShowPasswordModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">lock_reset</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Security &amp; Password</p>
                  <p className="text-xs text-[#424843] mt-0.5">Two-factor auth and active clinical sessions</p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>
          </div>
        </section>

        {/* Group 4: Support & Account */}
        <section className="space-y-1.5">
          <div className="px-1 flex items-center justify-between">
            <span className="text-xs font-bold text-[#476551] uppercase tracking-wider">
              Support &amp; Account
            </span>
            <span className="text-[11px] text-[#727973]">Care Team</span>
          </div>

          <div className="lg-card rounded-3xl divide-y divide-white/50 overflow-hidden">
            <div
              onClick={() => setShowFaqModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">help_center</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Help Center &amp; FAQs</p>
                  <p className="text-xs text-[#424843] mt-0.5">Guides on trimester tracking and AI logs</p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>

            <div
              onClick={() => setShowSupportModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">support_agent</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Contact Maternal Care Support</p>
                  <p className="text-xs text-[#424843] mt-0.5">Direct line to maternal nurse coordinators</p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>

            <div
              onClick={() => setShowDisclaimerModal(true)}
              className="p-4 flex items-center justify-between hover:bg-white/60 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-2xl bg-[#c9ebd2]/50 text-[#476551] flex items-center justify-center shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-lg">description</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#062919]">Terms of Service &amp; Medical Disclaimers</p>
                  <p className="text-xs text-[#424843] mt-0.5">Legal notice: Not an emergency triage tool</p>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#727973]">chevron_right</span>
            </div>
          </div>
        </section>

        {/* Session Action & Sign Out */}
        <section className="pt-2 flex flex-col gap-3">
          <button
            type="button"
            onClick={() => setShowLogoutConfirm(true)}
            className="w-full py-3.5 px-4 bg-white border border-[#ba1a1a]/30 hover:bg-[#ffdad6]/20 text-[#ba1a1a] rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-colors active:scale-[0.99] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">logout</span>
            <span>Log Out</span>
          </button>
          <p className="text-center text-[11px] text-[#727973]">
            Mutterse v2.4.1 (Android Build) · Certified Maternal Digital Companion
          </p>
        </section>
      </main>

      {/* ── MODALS ── */}

      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-[#ffdad6] text-[#ba1a1a] flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-2xl">logout</span>
            </div>
            <h3 className="font-serif font-bold text-lg text-[#062919]">Sign out of Mutterse?</h3>
            <p className="text-xs text-[#424843]">
              Your maternal data remains securely encrypted on this device. You can sign back in anytime.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-3 rounded-2xl bg-[#f1f4f1] text-[#181c1b] text-xs font-semibold hover:bg-[#ecefeb] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirm(false);
                  logout();
                }}
                className="flex-1 py-3 rounded-2xl bg-[#ba1a1a] text-white text-xs font-bold hover:bg-[#ba1a1a]/90 cursor-pointer"
              >
                Confirm Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Emergency Contacts Modal */}
      {showContactsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">contact_emergency</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Emergency Contacts</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowContactsModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-[#f1f4f1] text-xs">
                <div className="flex justify-between font-bold text-[#062919]">
                  <span>Primary: {profile.primaryContact?.name}</span>
                  <span className="text-[#476551]">{profile.primaryContact?.relationship}</span>
                </div>
                <p className="text-[#424843] mt-0.5">{profile.primaryContact?.phone}</p>
              </div>
              <div className="p-3.5 rounded-2xl bg-[#f1f4f1] text-xs">
                <div className="flex justify-between font-bold text-[#062919]">
                  <span>Secondary: {profile.secondaryContact?.name}</span>
                  <span className="text-[#476551]">{profile.secondaryContact?.relationship}</span>
                </div>
                <p className="text-[#424843] mt-0.5">{profile.secondaryContact?.phone}</p>
              </div>
              <div className="p-3.5 rounded-2xl bg-[#c9ebd2]/30 text-xs">
                <div className="flex justify-between font-bold text-[#062919]">
                  <span>24/7 Triage: {profile.triageLine?.facility}</span>
                </div>
                <p className="text-[#476551] font-semibold mt-0.5">{profile.triageLine?.phone}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setShowContactsModal(false);
                setIsSetupMode(true);
              }}
              className="w-full py-3 rounded-2xl bg-[#1e3f2e] text-white text-xs font-semibold hover:bg-[#062919] cursor-pointer"
            >
              Edit Contacts in Profile
            </button>
          </div>
        </div>
      )}

      {/* Medicines Reminders Modal */}
      {showMedicinesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">schedule</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Medicine Reminders</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowMedicinesModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>

            <div className="space-y-2 max-h-52 overflow-y-auto">
              {medicines.map((m) => (
                <div
                  key={m.id}
                  className="p-3 bg-[#f1f4f1] rounded-xl flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-[#062919] block">{m.name}</span>
                    <span className="text-[#424843]">
                      {m.time} · {m.dosage}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => toggleMedicine(m.id)}
                    className={`px-3 py-1 rounded-full font-semibold text-xs cursor-pointer ${
                      m.taken ? 'bg-[#c6e8cf] text-[#062919]' : 'bg-[#1e3f2e] text-white'
                    }`}
                  >
                    {m.taken ? 'Taken' : 'Mark'}
                  </button>
                </div>
              ))}
            </div>

            {/* Add new medication */}
            <form onSubmit={handleAddMedicine} className="space-y-2 pt-2 border-t border-[#ecefeb]">
              <span className="text-xs font-bold text-[#062919] block">Add New Medication</span>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Medicine name"
                  value={newMedName}
                  onChange={(e) => setNewMedName(e.target.value)}
                  className="px-3.5 py-2.5 border border-[#c1c8c1] rounded-2xl text-xs"
                />
                <input
                  type="text"
                  placeholder="Time (e.g. 8:00 AM)"
                  value={newMedTime}
                  onChange={(e) => setNewMedTime(e.target.value)}
                  className="px-3.5 py-2.5 border border-[#c1c8c1] rounded-2xl text-xs"
                />
              </div>
              <input
                type="text"
                placeholder="Dosage instruction (e.g. 1 softgel with food)"
                value={newMedDosage}
                onChange={(e) => setNewMedDosage(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-[#c1c8c1] rounded-2xl text-xs"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-[#1e3f2e] text-white text-xs font-semibold rounded-2xl hover:bg-[#062919] cursor-pointer"
              >
                + Add Medication
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Clinic & Doctor Modal */}
      {showClinicModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">local_hospital</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Clinic &amp; Obstetrician</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowClinicModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="text-xs text-[#424843] space-y-2">
              <p>
                <strong>Attending Obstetrician:</strong> {profile.doctor}
              </p>
              <p>
                <strong>Delivery Hospital:</strong> {profile.deliveryHospital}
              </p>
              <p>
                <strong>Doula Support:</strong> {profile.doula?.name} ({profile.doula?.phone})
              </p>
              <p>
                <strong>Insurance Plan:</strong> {profile.insurance?.provider} (Group: {profile.insurance?.groupNumber})
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowClinicModal(false)}
              className="w-full py-3 rounded-2xl bg-[#c6e8cf] text-[#062919] text-xs font-bold cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Language Modal */}
      {showLanguageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-xs w-full border border-[#c1c8c1]/40 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <h3 className="font-serif font-semibold text-base text-[#062919]">Select Language</h3>
              <button
                type="button"
                onClick={() => setShowLanguageModal(false)}
                className="text-[#727973] hover:text-[#181c1b]"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>
            <div className="space-y-1.5">
              {[
                { code: 'en-US', name: 'English (US)' },
                { code: 'es', name: 'Español' },
                { code: 'fr', name: 'Français' },
                { code: 'hi', name: 'Hindi (हिंदी)' },
                { code: 'de', name: 'Deutsch' },
              ].map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => {
                    updateSettings({ language: lang.code });
                    setShowLanguageModal(false);
                    showToast('success', `Language changed to ${lang.name}`);
                  }}
                  className={`w-full py-2.5 px-3.5 rounded-2xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer ${
                    settings.language === lang.code
                      ? 'bg-[#c6e8cf] text-[#062919]'
                      : 'hover:bg-[#f1f4f1] text-[#181c1b]'
                  }`}
                >
                  <span>{lang.name}</span>
                  {settings.language === lang.code && (
                    <span className="material-symbols-outlined text-base">check</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Theme Modal */}
      {showThemeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-xs w-full border border-[#c1c8c1]/40 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <h3 className="font-serif font-semibold text-base text-[#062919]">Theme &amp; Display</h3>
              <button
                type="button"
                onClick={() => setShowThemeModal(false)}
                className="text-[#727973] hover:text-[#181c1b]"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>
            <div className="space-y-1.5">
              {[
                { id: 'cream', name: 'Warm Maternal Cream' },
                { id: 'sage', name: 'Pure Sage Green' },
                { id: 'dark', name: 'Botanical Night' },
              ].map((thm) => (
                <button
                  key={thm.id}
                  type="button"
                  onClick={() => {
                    updateSettings({ theme: thm.id });
                    setShowThemeModal(false);
                    showToast('success', `Theme switched to ${thm.name}`);
                  }}
                  className={`w-full py-2.5 px-3.5 rounded-2xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer ${
                    settings.theme === thm.id
                      ? 'bg-[#c6e8cf] text-[#062919]'
                      : 'hover:bg-[#f1f4f1] text-[#181c1b]'
                  }`}
                >
                  <span>{thm.name}</span>
                  {settings.theme === thm.id && (
                    <span className="material-symbols-outlined text-base">check</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Privacy & HIPAA Modal */}
      {showServerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">dns</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">AI Server Endpoint</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowServerModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="text-xs text-[#424843] space-y-2 leading-relaxed">
              <p>
                Configure the backend server URL that Mutterse AI connects to for medicine OCR scans and chat queries.
              </p>
              <div className="space-y-1 pt-1">
                <label className="text-[11px] font-bold text-[#062919]">Server Address (e.g. http://10.6.17.223:3001)</label>
                <input
                  type="text"
                  value={serverUrlInput}
                  onChange={(e) => setServerUrlInput(e.target.value)}
                  placeholder="http://10.6.17.223:3001"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#c1c8c1] text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-[#476551]/30"
                />
              </div>
              <p className="text-[10px] text-[#727973]">
                Leave blank to reset to the default build endpoint. On Android Emulator, use <code>http://10.0.2.2:3001</code>.
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setServerUrlInput('');
                  setApiBaseUrl('');
                  showToast('info', 'Reset AI Server to default build endpoint.');
                  setShowServerModal(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-[#ecefeb] text-[#2d312f] text-xs font-semibold hover:bg-[#e0e3df] cursor-pointer"
              >
                Reset Default
              </button>
              <button
                type="button"
                onClick={() => {
                  setApiBaseUrl(serverUrlInput);
                  showToast('success', 'AI Server Endpoint updated successfully!');
                  setShowServerModal(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-[#1e3f2e] text-white text-xs font-semibold hover:bg-[#062919] cursor-pointer"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">encrypted</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Data Privacy Standards</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="text-xs text-[#424843] space-y-2 leading-relaxed">
              <p>
                <strong>Zero Plaintext Storage:</strong> Passwords and sensitive health metrics are stored with
                cryptographic hashing in local browser storage.
              </p>
              <p>
                <strong>HIPAA-Compliant Isolation:</strong> No patient health information is shared with unauthorized
                advertising brokers.
              </p>
              <p>
                <strong>Biometric Protection:</strong> You can enable fingerprint or facial recognition to shield your
                antenatal notes.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowPrivacyModal(false)}
              className="w-full py-3 rounded-2xl bg-[#1e3f2e] text-white text-xs font-semibold hover:bg-[#062919] cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">lock_reset</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Security &amp; Password</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPasswordModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <form onSubmit={handleSavePassword} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#424843] mb-1">New Password</label>
                <input
                  type="password"
                  required
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#c1c8c1] text-xs text-[#181c1b]"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#1e3f2e] text-white text-xs font-semibold hover:bg-[#062919] cursor-pointer"
              >
                Update Password
              </button>
            </form>
          </div>
        </div>
      )}

      {/* FAQ Modal */}
      {showFaqModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">help_center</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Help &amp; FAQs</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowFaqModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <div className="text-xs text-[#424843] space-y-2.5 max-h-64 overflow-y-auto leading-relaxed">
              <div>
                <strong>How does the AI Scanner detect medicines?</strong>
                <p>
                  It captures images of bottle packaging or doctor slips and parses active compounds using OCR to check
                  against your gestational stage and allergies.
                </p>
              </div>
              <div>
                <strong>How are fetal kicks counted?</strong>
                <p>
                  Count 10 movements within a 2-hour window. If movement drops significantly, notify your clinic.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowFaqModal(false)}
              className="w-full py-3 rounded-2xl bg-[#c6e8cf] text-[#062919] text-xs font-bold cursor-pointer"
            >
              Got It
            </button>
          </div>
        </div>
      )}

      {/* Support Modal */}
      {showSupportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">support_agent</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Maternal Care Support</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSupportModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <p className="text-xs text-[#424843]">
              Need non-emergency guidance from our certified midwife care coordinators?
            </p>
            <div className="space-y-2">
              <a
                href="mailto:support@mutterse.health"
                className="w-full py-3 px-3.5 rounded-2xl bg-[#f1f4f1] text-[#062919] text-xs font-semibold flex items-center justify-between"
              >
                <span>support@mutterse.health</span>
                <span className="material-symbols-outlined text-base">email</span>
              </a>
              <a
                href={`tel:${profile.triageLine?.phone || '8005556262'}`}
                className="w-full py-3 px-3.5 rounded-2xl bg-[#c6e8cf] text-[#062919] text-xs font-semibold flex items-center justify-between"
              >
                <span>Call Care Coordinator Line</span>
                <span className="material-symbols-outlined text-base">call</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Disclaimers Modal */}
      {showDisclaimerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="lg-modal rounded-3xl p-6 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#ecefeb]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1e3f2e]">description</span>
                <h3 className="font-serif font-semibold text-lg text-[#062919]">Medical Disclaimers</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowDisclaimerModal(false)}
                className="text-[#727973] hover:text-[#181c1b] p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <p className="text-xs text-[#424843] leading-relaxed">
              Mutterse is an informative maternal companion tool and does not provide binding medical diagnoses.
              Always follow the explicit clinical directions of your licensed obstetrician, midwife, or certified
              medical doctor. In acute emergencies, dial emergency services immediately.
            </p>
            <button
              type="button"
              onClick={() => setShowDisclaimerModal(false)}
              className="w-full py-3 rounded-2xl bg-[#1e3f2e] text-white text-xs font-semibold cursor-pointer"
            >
              I Acknowledge
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
