import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { ReactNode } from 'react';
import type {
  MutterseProfile,
  MedicineItem,
  ScanItem,
  DailyRoutine,
  AppSettings,
  TabId,
  ToastMessage,
  Appointment,
  CareTask,
  ManualReminder,
} from '../types';
import {
  requestNotificationPermission,
  checkNotificationPermission,
  checkExactAlarmPermission,
  openExactAlarmSettings,
  scheduleReminderNotification,
  cancelReminderNotification,
  rescheduleAllReminders,
  checkDueRemindersNow,
  sendTestNotification,
} from '../services/notificationService';
import {
  supabase,
  supabaseAuth,
  supabaseDb,
} from '../services/supabaseClient';
import { App as CapApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import {
  DEFAULT_PROFILE,
  DEFAULT_MEDICINES,
  DEFAULT_ROUTINE,
  DEFAULT_SCANS,
  DEFAULT_SETTINGS,
  DEFAULT_APPOINTMENTS,
  DEFAULT_TASKS,
  DEFAULT_REMINDERS,
} from '../data/mockData';

// ── Local Storage Keys for offline cache ──────────────────────────────────────
const KEYS = {
  AUTH: 'mutterse_session_v3',
  PROFILE: 'mutterse_profile_v3',
  MEDICINES: 'mutterse_medicines_v3',
  ROUTINE: 'mutterse_routine_v3',
  SCANS: 'mutterse_scans_v3',
  SETTINGS: 'mutterse_settings_v3',
  APPOINTMENTS: 'mutterse_appointments_v3',
  TASKS: 'mutterse_tasks_v3',
  REMINDERS: 'mutterse_reminders_v1',
  DEMO_MODE: 'mutterse_demo_mode',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export interface AppUser {
  id?: string;
  name: string;
  identifier: string;
}

interface AppContextType {
  // Navigation & View Mode
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  isSetupMode: boolean;
  setIsSetupMode: (isSetup: boolean) => void;

  // Session & Authentication
  isAuthenticated: boolean;
  currentUser: AppUser | null;
  login: (identifier: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  signup: (name: string, identifier: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  resetPassword: (email: string) => Promise<{ success: boolean; message?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; message?: string }>;
  loginAsDemo: () => void;
  logout: () => void;

  // Maternal Profile
  profile: MutterseProfile;
  updateProfile: (updates: Partial<MutterseProfile>) => void;

  // Medicines
  medicines: MedicineItem[];
  toggleMedicine: (id: string) => void;
  addMedicine: (item: Omit<MedicineItem, 'id'>) => void;
  deleteMedicine: (id: string) => void;

  // Daily Vitals & Routine
  routine: DailyRoutine;
  logWater: () => void;
  resetWater: () => void;
  logPelvicFloor: (minutes: number) => void;
  logBloodPressure: (bp: string, pulse: number) => void;
  logKickSession: (count: number, duration: string, notes?: string) => void;
  logContraction: (durationSec: number, intervalMin: number, intensity: 'Mild' | 'Moderate' | 'Strong' | 'Braxton Hicks') => void;

  // AI Scanner Scans
  scans: ScanItem[];
  addScan: (scan: Omit<ScanItem, 'id'>) => void;
  deleteScan: (id: string) => void;

  // Clinical Appointments & Care Tasks
  appointments: Appointment[];
  addAppointment: (apt: Omit<Appointment, 'id'>) => void;
  toggleAppointment: (id: string) => void;
  tasks: CareTask[];
  toggleTask: (id: string) => void;
  addTask: (task: Omit<CareTask, 'id'>) => void;

  // Manual Reminders with Notification Scheduling
  reminders: ManualReminder[];
  addReminder: (reminder: Omit<ManualReminder, 'id' | 'createdAt' | 'notificationId'>) => Promise<void>;
  updateReminder: (id: string, updates: Partial<Omit<ManualReminder, 'id' | 'createdAt'>>) => Promise<void>;
  deleteReminder: (id: string) => Promise<void>;
  toggleReminderComplete: (id: string) => Promise<void>;

  // Settings
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;

  // Demo Reset
  resetDemoData: () => void;

  // Toast feedback
  toasts: ToastMessage[];
  showToast: (type: ToastMessage['type'], message: string) => void;
  removeToast: (id: string) => void;

  // Notification permission & system state
  notificationPermissionGranted: boolean;
  exactAlarmGranted: boolean;
  remindersLoading: boolean;
  remindersInitError: string | null;
  requestNotifPermission: () => Promise<void>;
  requestExactAlarmPermission: () => Promise<void>;
  testNotification: () => Promise<void>;
  retryRemindersInit: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [isSetupMode, setIsSetupMode] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem(KEYS.AUTH) === 'true';
  });

  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    const raw = localStorage.getItem('mutterse_current_user');
    return raw ? JSON.parse(raw) : null;
  });

  // Core Data States
  const [profile, setProfile] = useState<MutterseProfile>(() =>
    loadFromStorage(KEYS.PROFILE, DEFAULT_PROFILE)
  );
  const [medicines, setMedicines] = useState<MedicineItem[]>(() =>
    loadFromStorage(KEYS.MEDICINES, DEFAULT_MEDICINES)
  );
  const [routine, setRoutine] = useState<DailyRoutine>(() =>
    loadFromStorage(KEYS.ROUTINE, DEFAULT_ROUTINE)
  );
  const [scans, setScans] = useState<ScanItem[]>(() =>
    loadFromStorage(KEYS.SCANS, DEFAULT_SCANS)
  );
  const [settings, setSettings] = useState<AppSettings>(() =>
    loadFromStorage(KEYS.SETTINGS, DEFAULT_SETTINGS)
  );
  const [appointments, setAppointments] = useState<Appointment[]>(() =>
    loadFromStorage(KEYS.APPOINTMENTS, DEFAULT_APPOINTMENTS)
  );
  const [tasks, setTasks] = useState<CareTask[]>(() =>
    loadFromStorage(KEYS.TASKS, DEFAULT_TASKS)
  );
  const [reminders, setReminders] = useState<ManualReminder[]>(() =>
    loadFromStorage(KEYS.REMINDERS, DEFAULT_REMINDERS)
  );
  const [notificationPermissionGranted, setNotificationPermissionGranted] = useState(false);
  const [exactAlarmGranted, setExactAlarmGranted] = useState(true);
  const [remindersLoading, setRemindersLoading] = useState(false);
  const [remindersInitError, setRemindersInitError] = useState<string | null>(null);

  // Sync to Local Storage for offline caching
  useEffect(() => {
    localStorage.setItem(KEYS.AUTH, isAuthenticated ? 'true' : 'false');
  }, [isAuthenticated]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('mutterse_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('mutterse_current_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(KEYS.PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(KEYS.MEDICINES, JSON.stringify(medicines));
  }, [medicines]);

  useEffect(() => {
    localStorage.setItem(KEYS.ROUTINE, JSON.stringify(routine));
  }, [routine]);

  useEffect(() => {
    localStorage.setItem(KEYS.SCANS, JSON.stringify(scans));
  }, [scans]);

  useEffect(() => {
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem(KEYS.TASKS, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
    if (settings.reducedMotion) {
      document.documentElement.classList.add('reduced-motion');
    } else {
      document.documentElement.classList.remove('reduced-motion');
    }
  }, [settings]);

  // Toast Helpers
  const showToast = useCallback((type: ToastMessage['type'], message: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Load user data from Supabase backend
  const loadUserDataFromSupabase = useCallback(async (userId: string) => {
    try {
      // 1. Profile
      const remoteProfile = await supabaseDb.getProfile(userId);
      if (remoteProfile) {
        setProfile(remoteProfile);
      }

      // 2. Appointments
      const remoteApts = await supabaseDb.getAppointments(userId);
      if (remoteApts && remoteApts.length > 0) {
        setAppointments(remoteApts);
      }

      // 3. Care tasks
      const remoteTasks = await supabaseDb.getCareTasks(userId);
      if (remoteTasks && remoteTasks.length > 0) {
        setTasks(remoteTasks);
      }

      // 4. Medicines
      const remoteMeds = await supabaseDb.getMedicines(userId);
      if (remoteMeds && remoteMeds.length > 0) {
        setMedicines(remoteMeds);
      }
    } catch (err) {
      console.warn('[Mutterse] Supabase data sync warning:', err);
    }
  }, []);

  // Handle authenticated user session (Google OAuth, Email/Password, or restored session)
  const handleAuthUserSession = useCallback(
    async (user: any) => {
      const rawMeta = user.user_metadata || {};
      const name = rawMeta.full_name || rawMeta.name || user.email?.split('@')[0] || 'Mama';
      const email = user.email || '';
      const avatarUrl =
        rawMeta.avatar_url || rawMeta.picture || DEFAULT_PROFILE.avatarUrl;

      const userObj: AppUser = {
        id: user.id,
        name,
        identifier: email,
      };

      setCurrentUser(userObj);
      setIsAuthenticated(true);
      localStorage.removeItem(KEYS.DEMO_MODE);

      // Retrieve or initialize user profile in Supabase database using authenticated user ID
      try {
        const remoteProfile = await supabaseDb.getProfile(user.id);
        if (remoteProfile) {
          setProfile(remoteProfile);
        } else {
          // Initialize maternal profile for new user without duplicate
          const initialProfile: MutterseProfile = {
            ...DEFAULT_PROFILE,
            id: user.id,
            name,
            avatarUrl,
            profileSetupComplete: false,
          };
          setProfile(initialProfile);
          try {
            await supabaseDb.upsertProfile(user.id, initialProfile);
          } catch (upsertErr: any) {
            console.warn('[Supabase] Initial profile creation note:', upsertErr?.message);
          }
        }

        // Hydrate associated appointments, tasks, medicines
        await loadUserDataFromSupabase(user.id);
      } catch (err: any) {
        console.warn('[Supabase Profile Sync Warning]:', err?.message || err);
      }
    },
    [loadUserDataFromSupabase]
  );

  // Supabase Auth Listener & Session Hydration
  useEffect(() => {
    // Check URL parameters for OAuth errors or redirect params
    if (typeof window !== 'undefined') {
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const searchParams = new URLSearchParams(window.location.search);
      const oauthError =
        searchParams.get('error_description') ||
        hashParams.get('error_description') ||
        searchParams.get('error');

      if (oauthError) {
        showToast('error', decodeURIComponent(oauthError.replace(/\+/g, ' ')));
        // Clean up URL without reload
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    }

    // Initial session check
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        console.warn('[Supabase] Initial session retrieval note:', error.message);
        return;
      }
      if (session?.user) {
        handleAuthUserSession(session.user);
      }
    });

    // Real-time auth state subscription
    const {
      data: { subscription },
    } = supabaseAuth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED') {
        if (session?.user) {
          await handleAuthUserSession(session.user);
        }
      } else if (event === 'SIGNED_OUT') {
        const isDemo = localStorage.getItem(KEYS.DEMO_MODE) === 'true';
        if (!isDemo) {
          setIsAuthenticated(false);
          setCurrentUser(null);
        }
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [handleAuthUserSession, showToast]);

  // ── Reminders System Initialization ─────────────────────────────────────────
  const refreshPermissionStates = useCallback(async () => {
    try {
      const notifGranted = await checkNotificationPermission();
      setNotificationPermissionGranted(notifGranted);
      const exactGranted = await checkExactAlarmPermission();
      setExactAlarmGranted(exactGranted);
    } catch {
      setNotificationPermissionGranted(false);
      setExactAlarmGranted(true);
    }
  }, []);

  const initRemindersSystem = useCallback(async () => {
    setRemindersLoading(true);
    setRemindersInitError(null);
    try {
      await refreshPermissionStates();
      await rescheduleAllReminders(reminders);
    } catch (err: any) {
      console.warn('[Mutterse Reminders] Init note:', err);
      setRemindersInitError(err?.message || 'Notification service initializing in background');
    } finally {
      setRemindersLoading(false);
    }
  }, [refreshPermissionStates, reminders]);

  useEffect(() => {
    initRemindersSystem();
  }, [initRemindersSystem]);

  // App resume check for due alarms
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const resumeListener = CapApp.addListener('appStateChange', (state) => {
      if (state.isActive) {
        checkDueRemindersNow(reminders);
        refreshPermissionStates();
      }
    });
    return () => {
      resumeListener.then((h) => h.remove()).catch(() => {});
    };
  }, [reminders, refreshPermissionStates]);

  // ── Google OAuth deep-link handler (Capacitor native only) ──────────────────
  // After signing in with Google, the system browser redirects to the Supabase
  // callback URL. The OS then re-opens the app with the URL in appUrlOpen.
  // Supabase's PKCE flow exchanges the code for a session automatically when
  // detectSessionInUrl is true, but we need to pass the URL to the client on
  // native so it can detect and exchange the session.
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    let listenerHandle: any = null;

    CapApp.addListener('appUrlOpen', async ({ url }) => {
      console.log('[OAuth] appUrlOpen received:', url);
      if (
        url.includes('access_token') ||
        url.includes('code=') ||
        url.includes('error_description') ||
        url.includes('error=')
      ) {
        try {
          // Let Supabase exchange the PKCE code for a session
          const { data, error } = await (supabase.auth as any).getSessionFromUrl({ url });
          if (error) {
            console.warn('[OAuth] getSessionFromUrl error:', error.message);
            // Try exchangeCodeForSession as fallback (older SDK)
            const codeMatch = url.match(/[?&]code=([^&]+)/);
            if (codeMatch) {
              const { error: e2 } = await supabase.auth.exchangeCodeForSession(codeMatch[1]);
              if (e2) console.warn('[OAuth] exchangeCodeForSession error:', e2.message);
            }
          } else if (data?.session?.user) {
            await handleAuthUserSession(data.session.user);
          }
        } catch (err) {
          console.warn('[OAuth] appUrlOpen handler error:', err);
        }
      }
    }).then((h) => { listenerHandle = h; }).catch(() => {});

    return () => {
      if (listenerHandle) listenerHandle.remove().catch(() => {});
    };
  }, [handleAuthUserSession]);

  // ── Authentication Actions ──────────────────────────────────────────────────
  const login = async (
    identifier: string,
    pass: string
  ): Promise<{ success: boolean; message?: string }> => {
    const trimmedId = identifier.trim().toLowerCase();
    const cleanPass = pass.trim();

    if (!trimmedId || !cleanPass) {
      return { success: false, message: 'Please enter your email and password.' };
    }

    try {
      const data = await supabaseAuth.signIn(trimmedId, cleanPass);
      const user = data.user;

      if (user) {
        const name = user.user_metadata?.name || trimmedId.split('@')[0];
        const userObj: AppUser = {
          id: user.id,
          name,
          identifier: trimmedId,
        };
        setCurrentUser(userObj);
        setIsAuthenticated(true);
        localStorage.removeItem(KEYS.DEMO_MODE);

        await loadUserDataFromSupabase(user.id);
        showToast('success', `Welcome back, ${name}!`);
        return { success: true };
      }

      return { success: true };
    } catch (err: any) {
      console.error('[Supabase Login Error]', err);
      return { success: false, message: err.message || 'Invalid email or password.' };
    }
  };

  const signup = async (
    name: string,
    identifier: string,
    pass: string
  ): Promise<{ success: boolean; message?: string }> => {
    const trimmedName = name.trim();
    const trimmedId = identifier.trim().toLowerCase();
    const cleanPass = pass.trim();

    if (!trimmedName || !trimmedId || !cleanPass) {
      return { success: false, message: 'All fields are required to create an account.' };
    }

    if (cleanPass.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters.' };
    }

    try {
      const data = await supabaseAuth.signUp(trimmedName, trimmedId, cleanPass);
      const user = data.user;

      if (user) {
        const userObj: AppUser = {
          id: user.id,
          name: trimmedName,
          identifier: trimmedId,
        };
        setCurrentUser(userObj);
        setIsAuthenticated(true);
        localStorage.removeItem(KEYS.DEMO_MODE);

        const initialProfile: MutterseProfile = {
          ...DEFAULT_PROFILE,
          id: user.id,
          name: trimmedName,
          profileSetupComplete: false,
        };
        setProfile(initialProfile);

        try {
          await supabaseDb.upsertProfile(user.id, initialProfile);
        } catch (dbErr: any) {
          console.warn('[Supabase] Initial profile creation note:', dbErr.message);
        }

        setIsSetupMode(true);
        showToast('success', `Sanctuary created! Let's personalize your care profile, ${trimmedName.split(' ')[0]}.`);
        return { success: true };
      }

      return { success: true };
    } catch (err: any) {
      console.error('[Supabase Signup Error]', err);
      return { success: false, message: err.message || 'Signup failed. Please try again.' };
    }
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; message?: string }> => {
    try {
      await supabaseAuth.resetPassword(email);
      showToast('success', `Password recovery link dispatched to ${email}`);
      return { success: true };
    } catch (err: any) {
      console.error('[Supabase Reset Password Error]', err);
      return { success: false, message: err.message || 'Failed to dispatch recovery link.' };
    }
  };

  const loginWithGoogle = async (): Promise<{ success: boolean; message?: string }> => {
    try {
      const data = await supabaseAuth.signInWithGoogle();
      // On native Capacitor, Supabase opens the system browser automatically via
      // the OAuth URL. On web, we redirect the page to the OAuth URL.
      if (data?.url) {
        if (Capacitor.isNativePlatform()) {
          // On native: open OAuth URL in the in-app browser / system browser.
          // The Browser plugin opens it; on return, appUrlOpen fires.
          // If @capacitor/browser is not installed, fall back to window.open.
          try {
            // @ts-ignore - optional native in-app browser plugin
            const { Browser } = await import(/* @vite-ignore */ '@capacitor/browser');
            await Browser.open({ url: data.url, windowName: '_self' });
          } catch {
            // Fallback: open in system browser via window.open
            window.open(data.url, '_system');
          }
        } else {
          // Web: navigate the current tab to Google OAuth
          window.location.href = data.url;
        }
      }
      return { success: true };
    } catch (err: any) {
      console.error('[Supabase Google Auth Error]', err);
      const msg = err.message || 'Unable to connect to Google Sign-In.';
      showToast('error', msg);
      return { success: false, message: msg };
    }
  };

  const loginAsDemo = () => {
    localStorage.setItem(KEYS.DEMO_MODE, 'true');
    setProfile(DEFAULT_PROFILE);
    setCurrentUser({ id: 'demo-elena-vance', name: 'Elena Vance', identifier: 'elena.vance@mutterse.health' });
    setIsAuthenticated(true);
    setIsSetupMode(false);
    setActiveTab('home');
    showToast('success', 'Logged into Elena Vance’s maternal sanctuary (Demo Mode)');
  };

  const logout = async () => {
    try {
      await supabaseAuth.signOut();
    } catch (err) {
      console.warn('[Supabase Logout Note]', err);
    }
    localStorage.removeItem(KEYS.DEMO_MODE);
    setIsAuthenticated(false);
    setCurrentUser(null);
    setIsSetupMode(false);
    showToast('info', 'You have been safely signed out.');
  };

  // ── Profile Updates ─────────────────────────────────────────────────────────
  const updateProfile = (updates: Partial<MutterseProfile>) => {
    setProfile((prev) => {
      const updated = {
        ...prev,
        ...updates,
        updatedAt: new Date().toISOString().split('T')[0],
      };
      if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
        supabaseDb.upsertProfile(currentUser.id, updated).catch((e) => {
          console.warn('[Supabase] Profile update sync warning:', e.message);
        });
      }
      return updated;
    });
    showToast('success', 'Maternal profile saved successfully 🌿');
  };

  // ── Medicines ───────────────────────────────────────────────────────────────
  const toggleMedicine = (id: string) => {
    setMedicines((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const nextState = !m.taken;
          if (nextState) {
            showToast('success', `Marked ${m.name} as taken! ✨`);
          }
          if (currentUser?.id && currentUser.id !== 'demo-elena-vance' && !id.startsWith('med-')) {
            supabaseDb.updateMedicine(id, { taken: nextState }).catch((e) => {
              console.warn('[Supabase] Medicine update sync warning:', e.message);
            });
          }
          return { ...m, taken: nextState };
        }
        return m;
      })
    );
  };

  const addMedicine = (item: Omit<MedicineItem, 'id'>) => {
    const newMed: MedicineItem = {
      ...item,
      id: `med-${Date.now()}`,
    };
    setMedicines((prev) => [newMed, ...prev]);
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.insertMedicine(currentUser.id, item).catch((e) => {
        console.warn('[Supabase] Medicine insert sync warning:', e.message);
      });
    }
    showToast('success', `Added ${item.name} to daily reminders!`);
  };

  const deleteMedicine = (id: string) => {
    setMedicines((prev) => prev.filter((m) => m.id !== id));
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance' && !id.startsWith('med-')) {
      supabaseDb.deleteMedicine(id).catch((e) => {
        console.warn('[Supabase] Medicine delete sync warning:', e.message);
      });
    }
    showToast('info', 'Medication removed from schedule');
  };

  // ── Routine & Vitals ────────────────────────────────────────────────────────
  const logWater = () => {
    setRoutine((prev) => {
      const nextCount = prev.hydrationCount + 1;
      if (nextCount === prev.hydrationTarget) {
        showToast('success', '🎉 Hydration target reached for today (8/8 glasses)! Great job, mama.');
      } else if (nextCount > prev.hydrationTarget) {
        showToast('info', `Extra glass logged (${nextCount}/${prev.hydrationTarget})! Stay refreshed.`);
      } else {
        showToast('success', `Logged glass of water (${nextCount}/${prev.hydrationTarget}) 💧`);
      }
      if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
        supabaseDb.syncVitalsLog(currentUser.id, { hydration_count: nextCount });
      }
      return { ...prev, hydrationCount: nextCount };
    });
  };

  const resetWater = () => {
    setRoutine((prev) => ({ ...prev, hydrationCount: 0 }));
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.syncVitalsLog(currentUser.id, { hydration_count: 0 });
    }
    showToast('info', 'Daily hydration counter reset for a new day.');
  };

  const logPelvicFloor = (minutes: number) => {
    setRoutine((prev) => {
      const newMinutes = prev.pelvicFloorMinutes + minutes;
      showToast('success', `Logged ${minutes} mins of pelvic floor exercises! Total: ${newMinutes} mins.`);
      if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
        supabaseDb.syncVitalsLog(currentUser.id, { pelvic_floor_minutes: newMinutes });
      }
      return { ...prev, pelvicFloorMinutes: newMinutes };
    });
  };

  const logBloodPressure = (bp: string, pulse: number) => {
    const newRecord = {
      id: `bp-${Date.now()}`,
      date: 'Today',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      bp,
      pulse,
      status: 'Normal BP',
    };
    setRoutine((prev) => ({
      ...prev,
      bloodPressure: bp,
      bpHistory: [newRecord, ...prev.bpHistory],
    }));
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.syncVitalsLog(currentUser.id, { blood_pressure: bp, pulse });
    }
    showToast('success', `Recorded BP ${bp} (Pulse: ${pulse} bpm). All normal!`);
  };

  const logKickSession = (count: number, duration: string, notes?: string) => {
    const newKick = {
      id: `k-${Date.now()}`,
      date: 'Today',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      count,
      duration,
      notes: notes || 'Fetal movement logged',
    };
    setRoutine((prev) => ({
      ...prev,
      kicks: [newKick, ...prev.kicks],
    }));
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.syncVitalsLog(currentUser.id, { kicks_count: count });
    }
    showToast('success', `Logged ${count} kicks in ${duration}! Little one is active. 💕`);
  };

  const logContraction = (
    durationSec: number,
    intervalMin: number,
    intensity: 'Mild' | 'Moderate' | 'Strong' | 'Braxton Hicks'
  ) => {
    const newContraction = {
      id: `c-${Date.now()}`,
      date: 'Today',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      durationSec,
      intervalMin,
      intensity,
    };
    setRoutine((prev) => ({
      ...prev,
      contractions: [newContraction, ...prev.contractions],
    }));
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.syncVitalsLog(currentUser.id, { contractions_count: 1 });
    }
    showToast('info', `Recorded ${durationSec}s contraction (${intensity}). Keep breathing calmly.`);
  };

  // ── Scans ───────────────────────────────────────────────────────────────────
  const addScan = (scan: Omit<ScanItem, 'id'>) => {
    const newScan: ScanItem = {
      ...scan,
      id: `scan-${Date.now()}`,
    };
    setScans((prev) => [newScan, ...prev]);
    showToast('success', `AI Clinical Scan saved to your records.`);
  };

  const deleteScan = (id: string) => {
    setScans((prev) => prev.filter((s) => s.id !== id));
    showToast('info', 'Scan record removed.');
  };

  // ── Appointments & Tasks ────────────────────────────────────────────────────
  const addAppointment = (apt: Omit<Appointment, 'id'>) => {
    const newApt: Appointment = { ...apt, id: `apt-${Date.now()}` };
    setAppointments((prev) => [newApt, ...prev]);
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.insertAppointment(currentUser.id, apt).catch((e) => {
        console.warn('[Supabase] Appointment insert sync warning:', e.message);
      });
    }
    showToast('success', `Appointment added: ${newApt.title}`);
  };

  const toggleAppointment = (id: string) => {
    setAppointments((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const newStatus = a.status === 'Completed' ? 'Upcoming' : 'Completed';
          const completedAt = newStatus === 'Completed' ? new Date().toISOString() : undefined;
          if (currentUser?.id && currentUser.id !== 'demo-elena-vance' && !id.startsWith('apt-')) {
            supabaseDb.updateAppointment(id, { status: newStatus, completedAt }).catch((e) => {
              console.warn('[Supabase] Appointment update sync warning:', e.message);
            });
          }
          return {
            ...a,
            status: newStatus,
            completedAt,
          };
        }
        return a;
      })
    );
  };

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const next = !t.completed;
          if (next) showToast('success', `Completed task: ${t.title}`);
          if (currentUser?.id && currentUser.id !== 'demo-elena-vance' && !id.startsWith('task-')) {
            supabaseDb.updateCareTask(id, {
              completed: next,
              completedAt: next ? new Date().toISOString() : undefined,
            }).catch((e) => {
              console.warn('[Supabase] CareTask update sync warning:', e.message);
            });
          }
          return { ...t, completed: next, completedAt: next ? 'Today' : undefined };
        }
        return t;
      })
    );
  };

  const addTask = (task: Omit<CareTask, 'id'>) => {
    const newTask: CareTask = { ...task, id: `task-${Date.now()}` };
    setTasks((prev) => [newTask, ...prev]);
    if (currentUser?.id && currentUser.id !== 'demo-elena-vance') {
      supabaseDb.insertCareTask(currentUser.id, task).catch((e) => {
        console.warn('[Supabase] CareTask insert sync warning:', e.message);
      });
    }
    showToast('success', `Added care task: ${newTask.title}`);
  };

  // ── Manual Reminders ─────────────────────────────────────────────────────────
  const addReminder = async (
    reminder: Omit<ManualReminder, 'id' | 'createdAt' | 'notificationId'>
  ): Promise<void> => {
    const id = `rem-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newReminder: ManualReminder = {
      ...reminder,
      id,
      createdAt: new Date().toISOString(),
    };
    setReminders((prev) => [newReminder, ...prev]);
    showToast('success', `Reminder set: ${reminder.title} 🔔`);

    try {
      const notificationId = await scheduleReminderNotification(newReminder);
      if (notificationId) {
        setReminders((prev) =>
          prev.map((r) => (r.id === id ? { ...r, notificationId } : r))
        );
      }
    } catch (err) {
      console.warn('[Mutterse] Notification scheduling error:', err);
    }
  };

  const updateReminder = async (
    id: string,
    updates: Partial<Omit<ManualReminder, 'id' | 'createdAt'>>
  ): Promise<void> => {
    let updatedReminder: ManualReminder | undefined;
    setReminders((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          updatedReminder = { ...r, ...updates };
          return updatedReminder;
        }
        return r;
      })
    );
    showToast('success', 'Reminder updated ✏️');

    if (updatedReminder) {
      try {
        const notificationId = await scheduleReminderNotification(updatedReminder);
        setReminders((prev) =>
          prev.map((r) => (r.id === id ? { ...r, notificationId: notificationId ?? undefined } : r))
        );
      } catch (err) {
        console.warn('[Mutterse] Update notification error:', err);
      }
    }
  };

  const deleteReminder = async (id: string): Promise<void> => {
    setReminders((prev) => prev.filter((r) => r.id !== id));
    showToast('info', 'Reminder deleted');
    try {
      await cancelReminderNotification(id);
    } catch (err) {
      console.warn('[Mutterse] Cancel notification error:', err);
    }
  };

  const toggleReminderComplete = async (id: string): Promise<void> => {
    let updated: ManualReminder | undefined;
    setReminders((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          updated = {
            ...r,
            completed: !r.completed,
            completedAt: !r.completed ? new Date().toISOString() : undefined,
          };
          return updated;
        }
        return r;
      })
    );
    if (updated) {
      if (updated.completed) {
        showToast('success', `Reminder completed: ${updated.title} ✅`);
        try {
          await cancelReminderNotification(id);
        } catch {}
      } else {
        showToast('info', `Reminder reactivated: ${updated.title}`);
        try {
          const notificationId = await scheduleReminderNotification(updated);
          setReminders((prev) =>
            prev.map((r) => (r.id === id ? { ...r, notificationId: notificationId ?? undefined } : r))
          );
        } catch {}
      }
    }
  };

  const requestNotifPermission = async (): Promise<void> => {
    try {
      const granted = await requestNotificationPermission();
      setNotificationPermissionGranted(granted);
      await refreshPermissionStates();
      if (granted) {
        showToast('success', 'Notification permission granted! Reminders will alert you on time. 🔔');
      } else {
        showToast('warning', 'Notification permission not granted. You can still receive in-app alerts.');
      }
    } catch (err) {
      console.warn('[Mutterse] Request permission error:', err);
      showToast('warning', 'Could not complete notification request.');
    }
  };

  const requestExactAlarmPermission = async (): Promise<void> => {
    await openExactAlarmSettings();
    showToast('info', 'Redirecting to Android Alarms & Reminders settings...');
  };

  const retryRemindersInit = async (): Promise<void> => {
    await initRemindersSystem();
    showToast('info', 'Notification service refreshed.');
  };

  const testNotification = async (): Promise<void> => {
    await sendTestNotification();
    showToast('success', '🔔 Test notification fired! Sound, vibration & alert working.');
  };

  // ── Settings ────────────────────────────────────────────────────────────────
  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
    showToast('info', 'Preferences updated');
  };

  const resetDemoData = () => {
    setProfile(DEFAULT_PROFILE);
    setMedicines(DEFAULT_MEDICINES);
    setRoutine(DEFAULT_ROUTINE);
    setScans(DEFAULT_SCANS);
    setSettings(DEFAULT_SETTINGS);
    setAppointments(DEFAULT_APPOINTMENTS);
    setTasks(DEFAULT_TASKS);
    setReminders(DEFAULT_REMINDERS);
    showToast('info', 'Reset to pristine Mutterse clinical demonstration data.');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        isSetupMode,
        setIsSetupMode,
        isAuthenticated,
        currentUser,
        login,
        signup,
        resetPassword,
        loginWithGoogle,
        loginAsDemo,
        logout,
        profile,
        updateProfile,
        medicines,
        toggleMedicine,
        addMedicine,
        deleteMedicine,
        routine,
        logWater,
        resetWater,
        logPelvicFloor,
        logBloodPressure,
        logKickSession,
        logContraction,
        scans,
        addScan,
        deleteScan,
        appointments,
        addAppointment,
        toggleAppointment,
        tasks,
        toggleTask,
        addTask,
        settings,
        updateSettings,
        resetDemoData,
        toasts,
        showToast,
        removeToast,
        reminders,
        addReminder,
        updateReminder,
        deleteReminder,
        toggleReminderComplete,
        notificationPermissionGranted,
        exactAlarmGranted,
        remindersLoading,
        remindersInitError,
        requestNotifPermission,
        requestExactAlarmPermission,
        testNotification,
        retryRemindersInit,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
