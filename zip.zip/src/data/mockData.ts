// Mutterse Maternal Healthcare — Default Data & Mock Records
import type {
  MutterseProfile,
  MedicineItem,
  ScanItem,
  DailyRoutine,
  AppSettings,
  Appointment,
  CareTask,
  ManualReminder,
} from '../types';

export const DEFAULT_AVATAR =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuDME_bnLYhvHwLuV6C81uqSH7XK6hGWJdIeyYVUmqtpojZA780Y3USmMWPgERyz5PaUkRHwEORIp2e1HTB-iE5EP5cJMtGKOeutnXfLunKWGrguQOzMSr3wwJJSeOxzoAuDlqKBYX5NEWHIf2QqZQZDOWTTAezIGC_iFfCk8gBvAX0b9jJFAyC7H-sCp92TXL4RMdTLCnVsnHFTJFfOQFcaH0Vpq7JoEQtnJVe8toEciVuvS64RKRV9';

export const DEFAULT_PROFILE: MutterseProfile = {
  id: 'usr-elena-vance-001',
  name: 'Elena Vance',
  dob: '1993-10-14',
  bloodGroup: 'O+',
  gestationalWeek: 24,
  gestationalDay: 3,
  lmp: '2023-11-12',
  edd: '2024-08-18',
  deliveryHospital: "St. Jude Women's Hospital - Labor & Delivery Ward",
  birthPlan: 'Natural Vaginal',
  allergies: 'Penicillin, seasonal pollen',
  avatarUrl: DEFAULT_AVATAR,
  primaryContact: {
    name: 'Marcus Vance',
    relationship: 'Partner',
    phone: '+1 (555) 382-9104',
    sosAlert: true,
  },
  secondaryContact: {
    name: 'Clara Vance',
    relationship: 'Mother',
    phone: '+1 (555) 491-2209',
    sosAlert: false,
  },
  triageLine: {
    facility: 'St. Jude Labor & Delivery 24/7 Triage Desk',
    phone: '+1 (800) 555-MAMA (6262)',
  },
  doctor: 'Dr. Sarah Jenkins, MD - St. Jude Maternal Clinic',
  doula: {
    name: 'Maya Lin, CD(DONA) - Holistic Birth Care',
    phone: '+1 (555) 720-4491',
  },
  insurance: {
    provider: 'BlueCross Anthem',
    groupNumber: 'MTR-88219',
    policyId: 'BC-99401827-01',
  },
  profileSetupComplete: true,
  updatedAt: '2024-03-24',
};

export const DEFAULT_MEDICINES: MedicineItem[] = [
  {
    id: 'med-1',
    name: 'Prenatal Multivitamin & Iron',
    dosage: '1 tablet with lunch & full glass of water',
    time: '1:00 PM',
    taken: false,
    category: 'Daily Prenatal',
    safetyNote: 'Take with vitamin C / water, separate from dairy by 2 hours',
  },
  {
    id: 'med-2',
    name: 'Prenatal Ultra DHA & Choline',
    dosage: '1 softgel after morning meal',
    time: '8:00 AM',
    taken: true,
    category: 'Brain Development',
    safetyNote: 'Bioavailable micro-algae DHA for fetal neurogenesis',
  },
  {
    id: 'med-3',
    name: 'Calcium & Vitamin D3',
    dosage: '1 tablet before bed',
    time: '8:00 PM',
    taken: false,
    category: 'Bone Density',
    safetyNote: 'Do not take at the same hour as elemental iron',
  },
];

export const DEFAULT_ROUTINE: DailyRoutine = {
  hydrationCount: 5,
  hydrationTarget: 8,
  pelvicFloorMinutes: 10,
  bloodPressure: '118/76',
  bpHistory: [
    { id: 'bp-1', date: 'Today', time: '8:30 AM', bp: '118/76', pulse: 72, status: 'Normal BP' },
    { id: 'bp-2', date: 'Yesterday', time: '9:00 AM', bp: '116/74', pulse: 70, status: 'Normal BP' },
    { id: 'bp-3', date: '2 days ago', time: '8:45 AM', bp: '120/78', pulse: 74, status: 'Normal BP' },
  ],
  kicks: [
    { id: 'k-1', date: 'Today', time: '09:15 AM', count: 12, duration: '25m', notes: 'Active after cold orange juice' },
    { id: 'k-2', date: 'Yesterday', time: '08:30 PM', count: 10, duration: '20m', notes: 'Calm evening movement' },
  ],
  contractions: [
    { id: 'c-1', date: 'Today', time: '6:15 PM', durationSec: 35, intervalMin: 22, intensity: 'Braxton Hicks' },
  ],
};

export const DEFAULT_SCANS: ScanItem[] = [
  {
    id: 'scan-001',
    title: 'Prenatal Ultra DHA & Choline',
    category: 'packaging',
    timestamp: 'Today, 2.4s instant scan',
    matchScore: 99,
    ingredients: 'DHA 300mg, EPA 100mg, Folic Acid 800mcg, Elemental Iron 27mg',
    dosage: '1 softgel daily after morning meal',
    safetyStatus: 'Safe for 2nd & 3rd Trimester',
    clinicalNotes: 'Contains Iron: Take at least 2 hours apart from dairy or calcium supplements.',
    allergyClearance: 'No contraindications detected with recorded allergy (Penicillin).',
  },
  {
    id: 'scan-002',
    title: 'Gestational Anomaly Lab Summary',
    category: 'reports',
    timestamp: '2 weeks ago',
    matchScore: 97,
    ingredients: 'Hemoglobin 12.4 g/dL, Platelets 220k, Glucose Tolerance 92 mg/dL',
    dosage: 'Lab record reference',
    safetyStatus: 'All biomarkers within expected gestational range',
    clinicalNotes: 'Routine 24-week glucose screening confirmed negative.',
    allergyClearance: 'Verified by St. Jude Lab Information System.',
  },
];

export const DEFAULT_SETTINGS: AppSettings = {
  notificationsEnabled: true,
  language: 'en-US',
  theme: 'cream',
  reducedMotion: false,
  biometricLock: false,
  dataSharingConsent: true,
};

export const DEFAULT_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-001',
    title: 'Dr. Sarah Jenkins - Anatomy Ultrasound',
    type: 'Ultrasound Scan',
    date: '2024-04-25',
    time: 'Tomorrow, 10:30 AM',
    location: "St. Jude Women's Wing · Room 304",
    clinicianName: 'Dr. Sarah Jenkins, MD (OB-GYN)',
    status: 'Upcoming',
    notes: '24-week detailed anatomy ultrasound and placental Doppler scan.',
    reminderEnabled: true,
    phase: 'pregnancy',
  },
  {
    id: 'apt-002',
    title: 'Midwife Check-in & Birth Plan Review',
    type: 'Antenatal Checkup',
    date: '2024-05-15',
    time: '02:00 PM',
    location: 'St. Jude Natural Birthing Suite',
    clinicianName: 'Maya Lin, CD(DONA)',
    status: 'Upcoming',
    notes: 'Review birth preference options and relaxation techniques.',
    reminderEnabled: true,
    phase: 'pregnancy',
  },
  {
    id: 'apt-003',
    title: 'First Trimester Nuchal Translucency Scan',
    type: 'Ultrasound Scan',
    date: '2024-01-18',
    time: '11:00 AM',
    location: 'St. Jude Diagnostic Imaging',
    clinicianName: 'Dr. Sarah Jenkins',
    status: 'Completed',
    notes: 'NT measurement 1.3mm, nasal bone present, low risk.',
    completedAt: '2024-01-18',
    reminderEnabled: false,
    phase: 'pregnancy',
  },
];

export const DEFAULT_TASKS: CareTask[] = [
  {
    id: 'task-1',
    title: 'Drink 8 glasses of water',
    description: 'Maintain healthy amniotic fluid volume and hydration.',
    category: 'Nutrition',
    completed: false,
    dueDate: 'Today',
  },
  {
    id: 'task-2',
    title: 'Pelvic floor & Kegel exercises (10 mins)',
    description: 'Perineal strengthening routine for labor preparation.',
    category: 'Physical Care',
    completed: true,
    completedAt: 'Today, 8:45 AM',
    dueDate: 'Today',
  },
  {
    id: 'task-3',
    title: 'Take Prenatal Multivitamin & Iron',
    description: 'Supports maternal iron stores and fetal blood volume.',
    category: 'Medical',
    completed: false,
    dueDate: '1:00 PM',
  },
  {
    id: 'task-4',
    title: 'Gentle 20-min evening prenatal walk',
    description: 'Eases lower back tension and boosts circulation.',
    category: 'Wellness',
    completed: false,
    dueDate: '6:30 PM',
  },
];

// ── Default Manual Reminders (demo / first-run data) ─────────────────────────
export const DEFAULT_REMINDERS: ManualReminder[] = [
  {
    id: 'rem-demo-1',
    title: 'Take Iron Tablet',
    description: 'Take with a glass of orange juice for better absorption',
    category: 'Medication',
    date: new Date().toISOString().split('T')[0],
    time: '13:00',
    repeat: 'Daily',
    completed: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'rem-demo-2',
    title: 'Drink 2 more glasses of water',
    description: 'Staying hydrated supports amniotic fluid levels',
    category: 'Hydration',
    date: new Date().toISOString().split('T')[0],
    time: '16:00',
    repeat: 'Daily',
    completed: false,
    createdAt: new Date().toISOString(),
  },
];
