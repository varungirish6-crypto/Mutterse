/**
 * Mutterse Gemini API Client Service
 * Communicates with the secure server-side proxy layer.
 * Never exposes the Google Gemini API key in client code or mobile bundles.
 */

export interface ScannedMedicineData {
  title: string;
  strength?: string;
  ingredients?: string;
  dosage?: string;
  warnings?: string;
  isLegible?: boolean;
  confidenceNotes?: string;
  disclaimer?: string;
}

export interface ScanApiResponse {
  success: boolean;
  data?: ScannedMedicineData;
  error?: string;
  modelUsed?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai' | 'midwife';
  text: string;
  time: string;
  image?: string;
}

export interface ChatApiResponse {
  success: boolean;
  reply?: string;
  error?: string;
  modelUsed?: string;
}

// In development with Vite, /api/gemini routes are handled by the Vite plugin middleware.
// For Android APK / Capacitor builds, set VITE_API_BASE_URL in .env to point at the
// running Node proxy server (e.g. http://10.0.2.2:3001 for the Android emulator, or
// your machine's LAN IP for a physical device: http://192.168.x.x:3001).
const BUILD_API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

export function getApiBaseUrl(): string {
  if (typeof window !== 'undefined' && window.localStorage) {
    const custom = window.localStorage.getItem('mutterse_api_base_url');
    if (custom && custom.trim()) {
      return custom.trim().replace(/\/$/, '');
    }
  }
  return BUILD_API_BASE;
}

export function setApiBaseUrl(url: string): void {
  if (typeof window !== 'undefined' && window.localStorage) {
    if (!url || !url.trim()) {
      window.localStorage.removeItem('mutterse_api_base_url');
    } else {
      window.localStorage.setItem('mutterse_api_base_url', url.trim().replace(/\/$/, ''));
    }
  }
}

/**
 * Safely parse a JSON response, guarding against HTML error pages and empty bodies.
 * Returns parsed JSON or throws a descriptive Error.
 */
async function safeParseJson<T>(response: Response, context: string): Promise<T> {
  let text = '';
  try {
    text = await response.text();
  } catch (readErr: any) {
    throw new Error(`${context}: Failed to read response stream: ${readErr.message}`);
  }

  if (!text || !text.trim()) {
    throw new Error(`${context}: Empty response received from server (HTTP ${response.status}).`);
  }

  const trimmed = text.trim();
  if (
    trimmed.startsWith('<') ||
    trimmed.toLowerCase().startsWith('<!doctype') ||
    trimmed.toLowerCase().includes('<html')
  ) {
    throw new Error(
      `${context}: The backend server returned an HTML page instead of JSON (HTTP ${response.status}). ` +
      `Ensure the Mutterse backend is running and reachable.`
    );
  }

  try {
    return JSON.parse(text) as T;
  } catch (err: any) {
    throw new Error(`${context}: Invalid JSON received (HTTP ${response.status}): ${err.message}`);
  }
}

/**
 * Scan and extract medicine information from an image using the Gemini API
 */
export async function scanMedicineImage(
  imageDataUriOrBase64: string,
  mimeType: string = 'image/jpeg'
): Promise<ScannedMedicineData> {
  const url = `${getApiBaseUrl()}/api/gemini/scan`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        image: imageDataUriOrBase64,
        mimeType,
      }),
    });

    const result = await safeParseJson<ScanApiResponse>(response, 'Scan');

    if (!response.ok || !result.success) {
      const errDetail = result.error || `HTTP ${response.status}: Failed to analyze medicine image`;
      throw new Error(errDetail);
    }

    if (!result.data) {
      throw new Error('No medicine details could be extracted.');
    }

    return result.data;
  } catch (err: any) {
    console.error('[GeminiApi] Scan request failed:', err);
    throw err;
  }
}

/**
 * Send a chat message with the scanned medicine context and optional image to the Gemini AI proxy
 */
export async function sendMedicineChatMessage(
  message: string,
  history: ChatMessage[] = [],
  medicineContext?: ScannedMedicineData | null,
  image?: string | null,
  mimeType: string = 'image/jpeg'
): Promise<string> {
  const url = `${getApiBaseUrl()}/api/gemini/chat`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        history,
        medicineContext,
        image,
        mimeType,
      }),
    });

    const result = await safeParseJson<ChatApiResponse>(response, 'Chat');

    if (!response.ok || !result.success) {
      const errDetail = result.error || `HTTP ${response.status}: Failed to get answer from Mutterse AI`;
      throw new Error(errDetail);
    }

    if (!result.reply) {
      throw new Error('No response received from Mutterse AI.');
    }

    return result.reply;
  } catch (err: any) {
    console.error('[GeminiApi] Chat request failed:', err);
    throw err;
  }
}

/**
 * Check if the Gemini API service is available and configured
 */
export async function checkGeminiHealth(): Promise<boolean> {
  const url = `${getApiBaseUrl()}/api/gemini/health`;
  try {
    const res = await fetch(url);
    if (!res.ok) return false;
    const json = await safeParseJson<{ configured: boolean }>(res, 'Health');
    return json.configured === true;
  } catch {
    return false;
  }
}
