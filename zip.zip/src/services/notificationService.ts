/**
 * Mutterse Notification & Alarm Service
 * ──────────────────────────────────────
 * Robust cross-platform notification engine supporting:
 * • Android Native (@capacitor/local-notifications) with exact alarms, Doze-mode survival & channels
 * • Web / PWA / Desktop (HTML5 Notification API, Web Audio synthesizer chime, and in-app banners)
 * • Strict timeout guards on all native plugin calls so the UI never hangs on loading
 */

import { Capacitor } from '@capacitor/core';
import type { ManualReminder } from '../types';

// Lazy-loaded plugin reference
let _LN: typeof import('@capacitor/local-notifications').LocalNotifications | null = null;
let _pluginImportFailed = false;

/**
 * Safe helper to retrieve Capacitor LocalNotifications with timeout & error handling.
 */
async function getLN(): Promise<typeof import('@capacitor/local-notifications').LocalNotifications | null> {
  if (!Capacitor.isNativePlatform()) return null;
  if (_LN) return _LN;
  if (_pluginImportFailed) return null;

  try {
    const mod = await withTimeout(
      import('@capacitor/local-notifications'),
      4000,
      null as any // eslint-disable-line @typescript-eslint/no-explicit-any
    );
    if (mod && mod.LocalNotifications) {
      _LN = mod.LocalNotifications;
      return _LN;
    }
  } catch (err) {
    console.warn('[Mutterse Notifications] Failed to import @capacitor/local-notifications:', err);
    _pluginImportFailed = true;
  }
  return null;
}

// ── Generic Promise Timeout Guard ─────────────────────────────────────────────
/**
 * Wraps any promise with a strict millisecond timeout.
 * Guarantees that asynchronous operations (especially native bridge calls)
 * never hang the UI indefinitely.
 */
export async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs = 5000,
  fallbackValue: T
): Promise<T> {
  let timeoutId: number | null = null;

  const timeoutPromise = new Promise<T>((resolve) => {
    timeoutId = window.setTimeout(() => {
      console.warn(`[Mutterse] Async operation timed out after ${timeoutMs}ms. Using fallback.`);
      resolve(fallbackValue);
    }, timeoutMs);
  });

  try {
    return await Promise.race([promise, timeoutPromise]);
  } catch (err) {
    console.warn('[Mutterse] Async operation rejected. Using fallback:', err);
    return fallbackValue;
  } finally {
    if (timeoutId !== null) {
      window.clearTimeout(timeoutId);
    }
  }
}

// ── Constants & Channels ───────────────────────────────────────────────────────
export const CHANNEL_ID = 'mutterse_reminders';
export const CHANNEL_NAME = 'Mutterse Reminders & Alarms';

const CATEGORY_EMOJI: Record<string, string> = {
  Medication: '💊',
  'Doctor Appointment': '🏥',
  'Health Check-up': '🩺',
  Hydration: '💧',
  'Personal Care': '🌿',
  Other: '🔔',
};

// ── Service State & Synchronization ───────────────────────────────────────────
let _channelCreated = false;
let _isInitializing = false;
let _isInitialized = false;

let _onNavigateToCare: ((reminderId?: string) => void) | null = null;
let _onInAppAlarm: ((title: string, body: string) => void) | null = null;

// Track fired reminders per minute slot to prevent duplicate alarms
const _firedSlots = new Set<string>();

// Active web timeouts by reminder ID
const _webTimers = new Map<string, number>();

// ── Audio Alarm Synthesizer (Web Audio API) ───────────────────────────────────
let _audioCtx: AudioContext | null = null;

export function playInAppAlarmSound(): void {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    if (!_audioCtx || _audioCtx.state === 'closed') {
      _audioCtx = new AudioCtx();
    }
    if (_audioCtx.state === 'suspended') {
      _audioCtx.resume().catch(() => {});
    }

    const ctx = _audioCtx;
    // Pleasant 4-tone maternal chime sequence: C5 (523Hz), E5 (659Hz), G5 (784Hz), C6 (1046Hz)
    const notes = [523.25, 659.25, 783.99, 1046.5];
    const startTime = ctx.currentTime;

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const noteStart = startTime + i * 0.16;
      const noteEnd = noteStart + 0.35;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteStart);

      gain.gain.setValueAtTime(0, noteStart);
      gain.gain.linearRampToValueAtTime(0.35, noteStart + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, noteEnd);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(noteStart);
      osc.stop(noteEnd + 0.05);
    });

    // Tactile feedback on devices that support vibration
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate([250, 100, 250, 100, 350]);
    }
  } catch (err) {
    console.warn('[Mutterse] Audio chime warning:', err);
  }
}

// ── Android Notification Channel Setup ────────────────────────────────────────
/**
 * Ensures the Android 8+ notification channel is properly created with
 * high importance, default system notification sound, and vibration.
 */
export async function ensureNotificationChannel(): Promise<void> {
  if (!Capacitor.isNativePlatform() || _channelCreated) return;

  const LN = await getLN();
  if (!LN) return;

  try {
    await withTimeout(
      LN.createChannel({
        id: CHANNEL_ID,
        name: CHANNEL_NAME,
        description: 'Maternal health reminders and medical alarms',
        importance: 5, // IMPORTANCE_HIGH (Heads-up alert + audible tone)
        vibration: true,
        visibility: 1, // VISIBILITY_PUBLIC
      }),
      3000,
      undefined
    );
    _channelCreated = true;
  } catch (err) {
    console.warn('[Mutterse] Channel setup error (non-fatal):', err);
  }
}

// ── Permission Management ─────────────────────────────────────────────────────
export interface NotificationPermissionStatus {
  display: boolean;
  exactAlarm: boolean;
  canRequest: boolean;
}

/**
 * Check current notification permissions without prompting the user.
 * Always resolves within 3000ms.
 */
export async function checkNotificationPermission(): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (!LN) return false;
    try {
      const result = await withTimeout(
        LN.checkPermissions(),
        3000,
        { display: 'denied' as const }
      );
      return result.display === 'granted';
    } catch {
      return false;
    }
  }

  // Web Browser / PWA platform
  if (typeof window !== 'undefined' && 'Notification' in window) {
    return Notification.permission === 'granted';
  }
  return true;
}

/**
 * Check whether exact alarm permission is granted on Android 12+ (API 31+).
 */
export async function checkExactAlarmPermission(): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (!LN) return true;
    try {
      const result = await withTimeout(
        LN.checkExactNotificationSetting(),
        3000,
        { exact_alarm: 'granted' as const }
      );
      return result.exact_alarm === 'granted';
    } catch {
      return true; // Default true on older SDKs or non-Android
    }
  }
  return true;
}

/**
 * Launch the Android system settings screen for exact alarms.
 */
export async function openExactAlarmSettings(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (LN) {
      try {
        await withTimeout(LN.changeExactNotificationSetting(), 4000, undefined);
      } catch (err) {
        console.warn('[Mutterse] Could not open exact alarm settings:', err);
      }
    }
  }
}

/**
 * Prompt the user for notification permissions.
 * Guaranteed to resolve within 8000ms so the UI never hangs.
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (!LN) return false;

    // Ensure channel exists before requesting permissions
    await ensureNotificationChannel();

    try {
      const result = await withTimeout(
        LN.requestPermissions(),
        8000,
        { display: 'denied' as const }
      );
      return result.display === 'granted';
    } catch (err) {
      console.warn('[Mutterse] Request permission error:', err);
      return false;
    }
  }

  // Web browser fallback
  if (typeof window !== 'undefined' && 'Notification' in window) {
    try {
      const status = await Notification.requestPermission();
      return status === 'granted';
    } catch {
      return false;
    }
  }

  return true;
}

// ── Stable Notification ID Generator ─────────────────────────────────────────
export function reminderToNotifId(reminderId: string): number {
  let hash = 5381;
  for (let i = 0; i < reminderId.length; i++) {
    hash = (hash * 33) ^ reminderId.charCodeAt(i);
  }
  return Math.abs(hash % (2 ** 30 - 1)) + 1;
}

// ── Scheduling Helper ─────────────────────────────────────────────────────────
/**
 * Compute the next target Date object for a reminder.
 * If set for the current minute (e.g. testing right now), schedules 3 seconds ahead.
 */
export function computeTargetDate(reminder: ManualReminder): Date | null {
  const [year, month, day] = reminder.date.split('-').map(Number);
  const [hour, minute] = reminder.time.split(':').map(Number);
  const now = new Date();

  // Create date at reminder time
  const target = new Date(year, month - 1, day, hour, minute, 0, 0);

  // If time is within the current minute: fire in 3 seconds for quick testing
  if (Math.abs(target.getTime() - now.getTime()) < 60000 && target.getTime() <= now.getTime()) {
    return new Date(now.getTime() + 3000);
  }

  // If in future today / specified date
  if (target.getTime() > now.getTime()) {
    return target;
  }

  // If in the past but repeats daily
  if (reminder.repeat === 'Daily') {
    const nextDaily = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute, 0, 0);
    if (nextDaily.getTime() <= now.getTime()) {
      nextDaily.setDate(nextDaily.getDate() + 1);
    }
    return nextDaily;
  }

  // If in the past but repeats weekly
  if (reminder.repeat === 'Weekly') {
    const orig = new Date(year, month - 1, day, hour, minute, 0, 0);
    const dayOfWeek = orig.getDay();
    const nextWeekly = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute, 0, 0);
    const diff = (dayOfWeek - nextWeekly.getDay() + 7) % 7;
    nextWeekly.setDate(nextWeekly.getDate() + diff);
    if (nextWeekly.getTime() <= now.getTime()) {
      nextWeekly.setDate(nextWeekly.getDate() + 7);
    }
    return nextWeekly;
  }

  // Non-repeating reminder that is already in the past
  return null;
}

// ── Dispatch Alert (Web & In-App) ─────────────────────────────────────────────
export function dispatchReminderAlert(
  title: string,
  body: string,
  reminderId?: string
): void {
  // 1. Play in-app audible chime & vibration
  playInAppAlarmSound();

  // 2. Show HTML5 Web Notification if in browser and permitted
  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'granted') {
      try {
        const notif = new Notification(title, {
          body,
          icon: '/favicon.ico',
          tag: reminderId || 'mutterse-alarm',
        });
        notif.onclick = () => {
          window.focus();
          if (_onNavigateToCare) {
            _onNavigateToCare(reminderId);
          }
        };
      } catch (err) {
        console.warn('[Mutterse] Web Notification trigger warning:', err);
      }
    }
  }

  // 3. Trigger in-app banner toast callback
  if (_onInAppAlarm) {
    _onInAppAlarm(title, body);
  }
}

// ── Schedule a Notification ───────────────────────────────────────────────────
/**
 * Schedules a local reminder notification.
 * Guaranteed to return within 5000ms. Never throws or halts caller execution.
 */
export async function scheduleReminderNotification(
  reminder: ManualReminder
): Promise<number | null> {
  const notifId = reminderToNotifId(reminder.id);

  // Clear existing web timer
  const existingTimer = _webTimers.get(reminder.id);
  if (existingTimer) {
    window.clearTimeout(existingTimer);
    _webTimers.delete(reminder.id);
  }

  if (reminder.completed) {
    await cancelReminderNotification(reminder.id);
    return null;
  }

  const targetDate = computeTargetDate(reminder);
  if (!targetDate) return null;

  const emoji = CATEGORY_EMOJI[reminder.category] ?? '🔔';
  const title = `${emoji} ${reminder.title}`;
  const body = reminder.description
    ? reminder.description
    : `Time for your ${reminder.category.toLowerCase()} reminder`;

  // ── Web / In-App fallback timer ──
  const msUntilTrigger = targetDate.getTime() - Date.now();
  if (msUntilTrigger > 0 && msUntilTrigger < 24 * 60 * 60 * 1000) {
    const timer = window.setTimeout(() => {
      dispatchReminderAlert(title, body, reminder.id);
      _webTimers.delete(reminder.id);
    }, msUntilTrigger);
    _webTimers.set(reminder.id, timer);
  }

  // ── Native Android scheduling via Capacitor ──
  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (!LN) return notifId;

    try {
      await ensureNotificationChannel();
      await cancelReminderNotification(reminder.id);

      const schedSpec: Record<string, unknown> = {
        at: targetDate,
        allowWhileIdle: true,
      };

      if (reminder.repeat === 'Daily') {
        schedSpec.every = 'day';
      } else if (reminder.repeat === 'Weekly') {
        schedSpec.every = 'week';
      }

      await withTimeout(
        LN.schedule({
          notifications: [
            {
              id: notifId,
              channelId: CHANNEL_ID,
              title,
              body,
              iconColor: '#1e3f2e',
              extra: {
                reminderId: reminder.id,
                screen: 'care',
              },
              schedule: schedSpec as any, // eslint-disable-line @typescript-eslint/no-explicit-any
            },
          ],
        }),
        4000,
        null
      );

      return notifId;
    } catch (err) {
      console.warn('[Mutterse] Native schedule error (non-fatal):', err);
      return notifId;
    }
  }

  return notifId;
}

// ── Cancel Reminder Notification ──────────────────────────────────────────────
export async function cancelReminderNotification(reminderId: string): Promise<void> {
  const existingTimer = _webTimers.get(reminderId);
  if (existingTimer) {
    window.clearTimeout(existingTimer);
    _webTimers.delete(reminderId);
  }

  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (!LN) return;
    try {
      const notifId = reminderToNotifId(reminderId);
      await withTimeout(
        LN.cancel({ notifications: [{ id: notifId }] }),
        3000,
        undefined
      );
    } catch {
      // Ignored
    }
  }
}

// ── Reschedule All Reminders (App Start / Storage Refresh) ─────────────────────
export async function rescheduleAllReminders(reminders: ManualReminder[]): Promise<void> {
  if (_isInitializing) return;
  _isInitializing = true;

  try {
    await ensureNotificationChannel();
    for (const r of reminders) {
      if (!r.completed) {
        await scheduleReminderNotification(r);
      }
    }
    _isInitialized = true;
  } catch (err) {
    console.warn('[Mutterse] Reschedule all reminders warning:', err);
  } finally {
    _isInitializing = false;
  }
}

export function isNotificationServiceInitialized(): boolean {
  return _isInitialized;
}

// ── Ticker for Due Reminders (Runs every 10s in foreground) ───────────────────
export function checkDueRemindersNow(reminders: ManualReminder[]): void {
  const now = new Date();
  const currentSlot = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}_${now.getHours()}:${now.getMinutes()}`;

  for (const r of reminders) {
    if (r.completed) continue;

    const [rYear, rMonth, rDay] = r.date.split('-').map(Number);
    const [rHour, rMinute] = r.time.split(':').map(Number);

    let isDue = false;
    if (r.repeat === 'Daily') {
      isDue = now.getHours() === rHour && now.getMinutes() === rMinute;
    } else if (r.repeat === 'Weekly') {
      const rOrigDate = new Date(rYear, rMonth - 1, rDay);
      isDue =
        now.getDay() === rOrigDate.getDay() &&
        now.getHours() === rHour &&
        now.getMinutes() === rMinute;
    } else {
      isDue =
        now.getFullYear() === rYear &&
        now.getMonth() === rMonth - 1 &&
        now.getDate() === rDay &&
        now.getHours() === rHour &&
        now.getMinutes() === rMinute;
    }

    if (isDue) {
      const slotKey = `${r.id}_${currentSlot}`;
      if (!_firedSlots.has(slotKey)) {
        _firedSlots.add(slotKey);
        const emoji = CATEGORY_EMOJI[r.category] ?? '🔔';
        dispatchReminderAlert(
          `${emoji} ${r.title}`,
          r.description || `Time for your ${r.category.toLowerCase()} reminder`,
          r.id
        );
      }
    }
  }
}

// ── Test Notification Trigger (Instant 1-Click Verification) ──────────────────
export async function sendTestNotification(): Promise<boolean> {
  const title = '🔔 Mutterse Reminder Test';
  const body = 'Your notification system and alarm sound are working perfectly!';

  // Play audio chime immediately
  playInAppAlarmSound();

  // On Native: schedule an immediate local notification (1 second ahead)
  if (Capacitor.isNativePlatform()) {
    const LN = await getLN();
    if (LN) {
      try {
        await ensureNotificationChannel();
        await withTimeout(
          LN.schedule({
            notifications: [
              {
                id: 999999,
                channelId: CHANNEL_ID,
                title,
                body,
                iconColor: '#1e3f2e',
                schedule: { at: new Date(Date.now() + 1000) },
              },
            ],
          }),
          3000,
          null
        );
      } catch (err) {
        console.warn('[Mutterse] Test notification schedule error:', err);
      }
    }
  }

  // On Web: request permission if default, then fire Web Notification
  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'default') {
      try {
        await Notification.requestPermission();
      } catch {}
    }
    if (Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
        });
      } catch (e) {
        console.warn('[Mutterse] Test web notification warning:', e);
      }
    }
  }

  // Trigger in-app toast
  if (_onInAppAlarm) {
    _onInAppAlarm(title, body);
  }

  return true;
}

// ── Notification Action & Received Listeners ──────────────────────────────────
export function initNotificationListeners(
  onNavigateToCare: (reminderId?: string) => void,
  onInAppAlarm: (title: string, body: string) => void
): () => void {
  _onNavigateToCare = onNavigateToCare;
  _onInAppAlarm = onInAppAlarm;

  let removeActions: (() => void) | null = null;
  let removeReceived: (() => void) | null = null;

  if (Capacitor.isNativePlatform()) {
    getLN().then((LN) => {
      if (!LN) return;

      LN.addListener('localNotificationActionPerformed', (notificationAction) => {
        const extra = notificationAction.notification.extra;
        onNavigateToCare(extra?.reminderId);
      })
        .then((handle) => {
          removeActions = () => handle.remove();
        })
        .catch(() => {});

      LN.addListener('localNotificationReceived', (notification) => {
        playInAppAlarmSound();
        onInAppAlarm(notification.title, notification.body);
      })
        .then((handle) => {
          removeReceived = () => handle.remove();
        })
        .catch(() => {});
    });
  }

  return () => {
    _onNavigateToCare = null;
    _onInAppAlarm = null;
    if (removeActions) removeActions();
    if (removeReceived) removeReceived();
  };
}
