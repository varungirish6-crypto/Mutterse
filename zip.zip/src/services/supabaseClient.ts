import { createClient } from '@supabase/supabase-js';
import { Capacitor } from '@capacitor/core';
import type {
  MutterseProfile,
  MedicineItem,
  Appointment,
  CareTask,
} from '../types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-supabase-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
});

// ── Supabase Authentication Service ──────────────────────────────────────────

export const supabaseAuth = {
  async signUp(name: string, email: string, pass: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password: pass,
      options: {
        data: {
          name,
        },
      },
    });
    if (error) throw error;
    return data;
  },

  async signIn(email: string, pass: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password: pass,
    });
    if (error) throw error;
    return data;
  },

  async signInWithGoogle() {
    // On Capacitor native (Android/iOS), window.location.origin is 'https://localhost'
    // which the OS WebView cannot receive redirects to. Instead we use the Supabase
    // auth callback URL — Supabase stores the session and the app picks it up via
    // onAuthStateChange when the external browser returns to the app via appUrlOpen.
    const isNative = Capacitor.isNativePlatform();

    const currentSupabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
    // Supabase's own callback endpoint — always valid as a redirect URI in Google Console
    const nativeRedirectTo = `${currentSupabaseUrl}/auth/v1/callback`;
    // For web browser dev / production web, use the current page origin
    const webRedirectTo = typeof window !== 'undefined' ? window.location.origin : undefined;

    const redirectTo = isNative ? nativeRedirectTo : webRedirectTo;

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo,
        queryParams: {
          access_type: 'offline',
          prompt: 'select_account',
        },
        // On native, open in system browser so the OS can handle the redirect back
        skipBrowserRedirect: false,
      },
    });
    if (error) throw error;
    return data;
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  async resetPassword(email: string) {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: typeof window !== 'undefined' ? `${window.location.origin}/reset-password` : undefined,
    });
    if (error) throw error;
    return data;
  },

  async getSession() {
    const { data, error } = await supabase.auth.getSession();
    if (error) throw error;
    return data.session;
  },

  async getUser() {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    return data.user;
  },

  onAuthStateChange(callback: (event: string, session: any) => void) {
    return supabase.auth.onAuthStateChange(callback);
  },
};

// ── Supabase Database Operations ──────────────────────────────────────────────

export const supabaseDb = {
  // Profiles
  async getProfile(userId: string): Promise<MutterseProfile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      console.warn('[Supabase] Failed to fetch profile:', error.message);
      return null;
    }

    if (!data) return null;

    return {
      id: data.id,
      name: data.name || '',
      dob: data.dob || '',
      bloodGroup: data.blood_group || 'O+',
      gestationalWeek: data.gestational_week ?? 24,
      gestationalDay: data.gestational_day ?? 0,
      lmp: data.lmp || '',
      edd: data.edd || '',
      deliveryHospital: data.delivery_hospital || '',
      birthPlan: data.birth_plan || 'Natural Vaginal',
      allergies: data.allergies || '',
      avatarUrl: data.avatar_url || '',
      doctor: data.doctor || '',
      primaryContact: data.primary_contact || { name: '', relationship: 'Partner', phone: '', sosAlert: true },
      secondaryContact: data.secondary_contact || { name: '', relationship: 'Mother', phone: '', sosAlert: false },
      triageLine: data.triage_line || { facility: 'St. Jude Labor & Delivery 24/7', phone: '+1 (800) 555-MAMA' },
      doula: data.doula || { name: '', phone: '' },
      insurance: data.insurance || { provider: '', groupNumber: '', policyId: '' },
      profileSetupComplete: Boolean(data.profile_setup_complete),
      updatedAt: data.updated_at,
    };
  },

  async upsertProfile(userId: string, updates: Partial<MutterseProfile>) {
    const payload: any = {
      id: userId,
      updated_at: new Date().toISOString(),
    };

    if (updates.name !== undefined) payload.name = updates.name;
    if (updates.dob !== undefined) payload.dob = updates.dob;
    if (updates.bloodGroup !== undefined) payload.blood_group = updates.bloodGroup;
    if (updates.gestationalWeek !== undefined) payload.gestational_week = updates.gestationalWeek;
    if (updates.gestationalDay !== undefined) payload.gestational_day = updates.gestationalDay;
    if (updates.lmp !== undefined) payload.lmp = updates.lmp;
    if (updates.edd !== undefined) payload.edd = updates.edd;
    if (updates.deliveryHospital !== undefined) payload.delivery_hospital = updates.deliveryHospital;
    if (updates.birthPlan !== undefined) payload.birth_plan = updates.birthPlan;
    if (updates.allergies !== undefined) payload.allergies = updates.allergies;
    if (updates.avatarUrl !== undefined) payload.avatar_url = updates.avatarUrl;
    if (updates.doctor !== undefined) payload.doctor = updates.doctor;
    if (updates.primaryContact !== undefined) payload.primary_contact = updates.primaryContact;
    if (updates.secondaryContact !== undefined) payload.secondary_contact = updates.secondaryContact;
    if (updates.triageLine !== undefined) payload.triage_line = updates.triageLine;
    if (updates.doula !== undefined) payload.doula = updates.doula;
    if (updates.insurance !== undefined) payload.insurance = updates.insurance;
    if (updates.profileSetupComplete !== undefined) payload.profile_setup_complete = updates.profileSetupComplete;

    const { data, error } = await supabase
      .from('profiles')
      .upsert(payload)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Appointments
  async getAppointments(userId: string): Promise<Appointment[]> {
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: true });

    if (error) {
      console.warn('[Supabase] Failed to fetch appointments:', error.message);
      return [];
    }

    return (data || []).map((row) => ({
      id: row.id,
      title: row.title,
      type: row.type,
      date: row.date,
      time: row.time,
      location: row.location || undefined,
      clinicianName: row.clinician_name || undefined,
      status: row.status,
      notes: row.notes || undefined,
      completedAt: row.completed_at || undefined,
      reminderEnabled: Boolean(row.reminder_enabled),
      phase: row.phase || 'pregnancy',
    }));
  },

  async insertAppointment(userId: string, apt: Omit<Appointment, 'id'>) {
    const { data, error } = await supabase
      .from('appointments')
      .insert({
        user_id: userId,
        title: apt.title,
        type: apt.type,
        date: apt.date,
        time: apt.time,
        location: apt.location || null,
        clinician_name: apt.clinicianName || null,
        status: apt.status || 'Upcoming',
        notes: apt.notes || null,
        reminder_enabled: apt.reminderEnabled ?? true,
        phase: apt.phase || 'pregnancy',
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateAppointment(id: string, updates: Partial<Appointment>) {
    const payload: any = { updated_at: new Date().toISOString() };
    if (updates.title !== undefined) payload.title = updates.title;
    if (updates.type !== undefined) payload.type = updates.type;
    if (updates.date !== undefined) payload.date = updates.date;
    if (updates.time !== undefined) payload.time = updates.time;
    if (updates.location !== undefined) payload.location = updates.location;
    if (updates.clinicianName !== undefined) payload.clinician_name = updates.clinicianName;
    if (updates.status !== undefined) payload.status = updates.status;
    if (updates.notes !== undefined) payload.notes = updates.notes;
    if (updates.completedAt !== undefined) payload.completed_at = updates.completedAt;
    if (updates.reminderEnabled !== undefined) payload.reminder_enabled = updates.reminderEnabled;

    const { error } = await supabase.from('appointments').update(payload).eq('id', id);
    if (error) throw error;
  },

  async deleteAppointment(id: string) {
    const { error } = await supabase.from('appointments').delete().eq('id', id);
    if (error) throw error;
  },

  // Care Tasks
  async getCareTasks(userId: string): Promise<CareTask[]> {
    const { data, error } = await supabase
      .from('care_tasks')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[Supabase] Failed to fetch care tasks:', error.message);
      return [];
    }

    return (data || []).map((row) => ({
      id: row.id,
      title: row.title,
      description: row.description || undefined,
      category: row.category,
      completed: Boolean(row.completed),
      completedAt: row.completed_at || undefined,
      dueDate: row.due_date || undefined,
    }));
  },

  async insertCareTask(userId: string, task: Omit<CareTask, 'id'>) {
    const { data, error } = await supabase
      .from('care_tasks')
      .insert({
        user_id: userId,
        title: task.title,
        description: task.description || null,
        category: task.category || 'General',
        completed: Boolean(task.completed),
        due_date: task.dueDate || null,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateCareTask(id: string, updates: Partial<CareTask>) {
    const payload: any = { updated_at: new Date().toISOString() };
    if (updates.title !== undefined) payload.title = updates.title;
    if (updates.description !== undefined) payload.description = updates.description;
    if (updates.category !== undefined) payload.category = updates.category;
    if (updates.completed !== undefined) payload.completed = updates.completed;
    if (updates.completedAt !== undefined) payload.completed_at = updates.completedAt;
    if (updates.dueDate !== undefined) payload.due_date = updates.dueDate;

    const { error } = await supabase.from('care_tasks').update(payload).eq('id', id);
    if (error) throw error;
  },

  async deleteCareTask(id: string) {
    const { error } = await supabase.from('care_tasks').delete().eq('id', id);
    if (error) throw error;
  },

  // Medicines
  async getMedicines(userId: string): Promise<MedicineItem[]> {
    const { data, error } = await supabase
      .from('medicine_logs')
      .select('*')
      .eq('user_id', userId)
      .order('scheduled_time', { ascending: true });

    if (error) {
      console.warn('[Supabase] Failed to fetch medicines:', error.message);
      return [];
    }

    return (data || []).map((row) => ({
      id: row.id,
      name: row.medicine_name,
      dosage: row.dosage,
      time: row.scheduled_time,
      taken: Boolean(row.taken),
      category: row.category || 'Daily Prenatal',
      safetyNote: row.safety_note || '',
    }));
  },

  async insertMedicine(userId: string, item: Omit<MedicineItem, 'id'>) {
    const { data, error } = await supabase
      .from('medicine_logs')
      .insert({
        user_id: userId,
        medicine_name: item.name,
        dosage: item.dosage,
        scheduled_time: item.time,
        taken: Boolean(item.taken),
        category: item.category,
        safety_note: item.safetyNote,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateMedicine(id: string, updates: Partial<MedicineItem>) {
    const payload: any = { updated_at: new Date().toISOString() };
    if (updates.name !== undefined) payload.medicine_name = updates.name;
    if (updates.dosage !== undefined) payload.dosage = updates.dosage;
    if (updates.time !== undefined) payload.scheduled_time = updates.time;
    if (updates.taken !== undefined) payload.taken = updates.taken;
    if (updates.category !== undefined) payload.category = updates.category;
    if (updates.safetyNote !== undefined) payload.safety_note = updates.safetyNote;

    const { error } = await supabase.from('medicine_logs').update(payload).eq('id', id);
    if (error) throw error;
  },

  async deleteMedicine(id: string) {
    const { error } = await supabase.from('medicine_logs').delete().eq('id', id);
    if (error) throw error;
  },

  // Nutrition Logs
  async getNutritionLogs(userId: string) {
    const { data, error } = await supabase
      .from('nutrition_logs')
      .select('*')
      .eq('user_id', userId)
      .order('log_date', { ascending: false });

    if (error) {
      console.warn('[Supabase] Failed to fetch nutrition logs:', error.message);
      return [];
    }
    return data || [];
  },

  async insertNutritionLog(userId: string, entry: {
    meal_type: string;
    food_item: string;
    calories?: number;
    iron_mg?: number;
    water_ml?: number;
    safety_status?: string;
    notes?: string;
  }) {
    const { data, error } = await supabase
      .from('nutrition_logs')
      .insert({
        user_id: userId,
        meal_type: entry.meal_type,
        food_item: entry.food_item,
        calories: entry.calories || null,
        iron_mg: entry.iron_mg || null,
        water_ml: entry.water_ml || null,
        safety_status: entry.safety_status || 'Safe',
        notes: entry.notes || null,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Lab Results
  async getLabResults(userId: string) {
    const { data, error } = await supabase
      .from('lab_results')
      .select('*')
      .eq('user_id', userId)
      .order('test_date', { ascending: false });

    if (error) {
      console.warn('[Supabase] Failed to fetch lab results:', error.message);
      return [];
    }
    return data || [];
  },

  async insertLabResult(userId: string, item: {
    test_name: string;
    category?: string;
    result_value?: string;
    reference_range?: string;
    unit?: string;
    status?: string;
    test_date?: string;
    provider?: string;
    notes?: string;
  }) {
    const { data, error } = await supabase
      .from('lab_results')
      .insert({
        user_id: userId,
        test_name: item.test_name,
        category: item.category || 'Obstetric',
        result_value: item.result_value || null,
        reference_range: item.reference_range || null,
        unit: item.unit || null,
        status: item.status || 'Normal',
        test_date: item.test_date || new Date().toISOString().split('T')[0],
        provider: item.provider || null,
        notes: item.notes || null,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Birth Ready Plans
  async getBirthReadyPlan(userId: string) {
    const { data, error } = await supabase
      .from('birth_ready_plans')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) {
      console.warn('[Supabase] Failed to fetch birth ready plan:', error.message);
      return null;
    }
    return data;
  },

  async upsertBirthReadyPlan(userId: string, plan: {
    delivery_type?: string;
    hospital_name?: string;
    hospital_bag_packed?: boolean;
    pediatrician_chosen?: boolean;
    car_seat_installed?: boolean;
    pain_management?: string;
    cord_blood_banking?: string;
    special_wishes?: string;
    birth_partner_name?: string;
    birth_partner_phone?: string;
  }) {
    const { data, error } = await supabase
      .from('birth_ready_plans')
      .upsert({
        user_id: userId,
        ...plan,
        updated_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Referrals
  async getReferrals(userId: string) {
    const { data, error } = await supabase
      .from('referrals')
      .select('*')
      .eq('user_id', userId)
      .order('issued_date', { ascending: false });

    if (error) {
      console.warn('[Supabase] Failed to fetch referrals:', error.message);
      return [];
    }
    return data || [];
  },

  async insertReferral(userId: string, item: {
    specialty: string;
    specialist_name?: string;
    facility?: string;
    contact_phone?: string;
    reason?: string;
    status?: string;
    urgency?: string;
  }) {
    const { data, error } = await supabase
      .from('referrals')
      .insert({
        user_id: userId,
        specialty: item.specialty,
        specialist_name: item.specialist_name || null,
        facility: item.facility || null,
        contact_phone: item.contact_phone || null,
        reason: item.reason || null,
        status: item.status || 'Active',
        urgency: item.urgency || 'Routine',
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Vitals Logs (Daily routine sync)
  async syncVitalsLog(userId: string, routine: {
    blood_pressure?: string;
    pulse?: number;
    hydration_count?: number;
    hydration_target?: number;
    pelvic_floor_minutes?: number;
    kicks_count?: number;
    contractions_count?: number;
  }) {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('vitals_logs')
      .upsert({
        user_id: userId,
        log_date: today,
        ...routine,
        updated_at: new Date().toISOString(),
      })
      .select()
      .maybeSingle();

    if (error) {
      console.warn('[Supabase] Vitals sync note:', error.message);
    }
    return data;
  },
};
