// Mutterse Maternal Healthcare Suite — Core Type Definitions

export type BloodGroup = 'O+' | 'A+' | 'B+' | 'AB+' | 'O-' | 'A-' | 'B-' | 'AB-';

export type BirthPlanType = 'Natural Vaginal' | 'Water Birth' | 'Planned Cesarean' | 'Undecided / Flexible';

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
  sosAlert?: boolean;
}

export interface SupportContact {
  name: string;
  phone: string;
}

export interface TriageLineInfo {
  facility: string;
  phone: string;
}

export interface InsuranceInfo {
  provider: string;
  groupNumber: string;
  policyId: string;
}

export interface MutterseProfile {
  id: string;
  name: string;
  dob: string;
  bloodGroup: BloodGroup;
  gestationalWeek: number;
  gestationalDay: number;
  lmp: string;
  edd: string;
  deliveryHospital: string;
  birthPlan: BirthPlanType;
  allergies: string;
  avatarUrl: string;
  primaryContact: EmergencyContact;
  secondaryContact: EmergencyContact;
  triageLine: TriageLineInfo;
  doctor: string;
  doula: SupportContact;
  insurance: InsuranceInfo;
  profileSetupComplete: boolean;
  updatedAt?: string;
}

// Backwards-compatible alias for previous UserProfile usages
export type UserProfile = MutterseProfile;

export interface MedicineItem {
  id: string;
  name: string;
  dosage: string;
  time: string;
  taken: boolean;
  category: string;
  safetyNote: string;
}

export interface ScanItem {
  id: string;
  title: string;
  category: 'packaging' | 'prescriptions' | 'reports';
  timestamp: string;
  matchScore: number;
  ingredients: string;
  dosage: string;
  safetyStatus: string;
  clinicalNotes: string;
  allergyClearance: string;
  imageUrl?: string;
}

export interface BpRecord {
  id: string;
  date: string;
  time: string;
  bp: string;
  pulse: number;
  status: string;
}

export interface KickRecord {
  id: string;
  date: string;
  time: string;
  count: number;
  duration: string;
  notes?: string;
}

export interface ContractionRecord {
  id: string;
  date: string;
  time: string;
  durationSec: number;
  intervalMin: number;
  intensity: 'Mild' | 'Moderate' | 'Strong' | 'Braxton Hicks';
}

export interface DailyRoutine {
  hydrationCount: number;
  hydrationTarget: number;
  pelvicFloorMinutes: number;
  bloodPressure: string;
  bpHistory: BpRecord[];
  kicks: KickRecord[];
  contractions: ContractionRecord[];
}

export interface AppSettings {
  notificationsEnabled: boolean;
  language: string; // 'en-US' | 'es' | 'fr' | 'hi' | 'de'
  theme: string; // 'cream' | 'sage' | 'dark'
  reducedMotion: boolean;
  biometricLock: boolean;
  dataSharingConsent: boolean;
}

export type TabId = 'home' | 'scan' | 'care' | 'settings';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
}

// Care Task & Appointment types for comprehensive clinical support
export type AppointmentStatus = 'Upcoming' | 'Completed' | 'Overdue' | 'Cancelled';

// ── Manual Reminder System ────────────────────────────────────────────────────
export type ReminderCategory =
  | 'Medication'
  | 'Doctor Appointment'
  | 'Health Check-up'
  | 'Hydration'
  | 'Personal Care'
  | 'Other';

export type ReminderRepeat =
  | 'Does not repeat'
  | 'Daily'
  | 'Weekly'
  | 'Custom';

export interface ManualReminder {
  id: string;
  title: string;
  description?: string;
  category: ReminderCategory;
  date: string;       // YYYY-MM-DD
  time: string;       // HH:MM (24-hour)
  repeat: ReminderRepeat;
  customDays?: number[]; // 0=Sunday … 6=Saturday, used when repeat === 'Custom'
  completed: boolean;
  completedAt?: string;
  notificationId?: number; // unique Android notification ID
  createdAt: string;
}

export interface Appointment {
  id: string;
  title: string;
  type: string;
  date: string; // YYYY-MM-DD
  time: string; // e.g. "10:30 AM"
  location?: string;
  clinicianName?: string;
  status: AppointmentStatus;
  notes?: string;
  completedAt?: string;
  reminderEnabled: boolean;
  phase?: 'pregnancy' | 'postpartum';
}

export interface CareTask {
  id: string;
  title: string;
  description?: string;
  category: string;
  completed: boolean;
  completedAt?: string;
  dueDate?: string;
}
