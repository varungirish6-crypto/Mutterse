-- =============================================================================
-- MUTTERSE MATERNAL HEALTHCARE — PRODUCTION SUPABASE DATABASE SCHEMA
-- =============================================================================
-- Tables:
-- 1. profiles — user information & gestational details
-- 2. appointments — doctor visits and schedules
-- 3. care_tasks — daily maternal care activities
-- 4. lab_results — medical lab tests and biomarkers
-- 5. birth_ready_plans — birth preparation and hospital readiness
-- 6. referrals — healthcare referrals and specialist consultations
-- 7. nutrition_logs — daily nutrition tracking and dietary safety
-- 8. medicine_logs — medication schedules and adherence
-- 9. vitals_logs — daily maternal vitals (BP, hydration, pelvic floor)
-- =============================================================================

-- Enable pgcrypto / gen_random_uuid
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- -----------------------------------------------------------------------------
-- 1. PROFILES TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL DEFAULT '',
    dob DATE,
    blood_group TEXT NOT NULL DEFAULT 'O+',
    gestational_week INTEGER NOT NULL DEFAULT 24,
    gestational_day INTEGER NOT NULL DEFAULT 0,
    lmp DATE,
    edd DATE,
    delivery_hospital TEXT DEFAULT '',
    birth_plan TEXT DEFAULT 'Natural Vaginal',
    allergies TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    doctor TEXT DEFAULT '',
    primary_contact JSONB DEFAULT '{"name": "", "relationship": "Partner", "phone": "", "sosAlert": true}'::jsonb,
    secondary_contact JSONB DEFAULT '{"name": "", "relationship": "Mother", "phone": "", "sosAlert": false}'::jsonb,
    triage_line JSONB DEFAULT '{"facility": "St. Jude Labor & Delivery 24/7", "phone": "+1 (800) 555-MAMA"}'::jsonb,
    doula JSONB DEFAULT '{"name": "", "phone": ""}'::jsonb,
    insurance JSONB DEFAULT '{"provider": "", "groupNumber": "", "policyId": ""}'::jsonb,
    profile_setup_complete BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 2. APPOINTMENTS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'Checkup',
    date DATE NOT NULL,
    time TEXT NOT NULL,
    location TEXT,
    clinician_name TEXT,
    status TEXT NOT NULL DEFAULT 'Upcoming',
    notes TEXT,
    completed_at TIMESTAMPTZ,
    reminder_enabled BOOLEAN NOT NULL DEFAULT true,
    phase TEXT DEFAULT 'pregnancy',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 3. CARE_TASKS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.care_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL DEFAULT 'General',
    completed BOOLEAN NOT NULL DEFAULT false,
    completed_at TEXT,
    due_date TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 4. LAB_RESULTS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.lab_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    test_name TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Obstetric',
    result_value TEXT,
    reference_range TEXT,
    unit TEXT,
    status TEXT NOT NULL DEFAULT 'Normal',
    test_date DATE NOT NULL DEFAULT CURRENT_DATE,
    provider TEXT,
    notes TEXT,
    attachment_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 5. BIRTH_READY_PLANS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.birth_ready_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    delivery_type TEXT DEFAULT 'Natural Vaginal',
    hospital_name TEXT,
    hospital_bag_packed BOOLEAN NOT NULL DEFAULT false,
    pediatrician_chosen BOOLEAN NOT NULL DEFAULT false,
    car_seat_installed BOOLEAN NOT NULL DEFAULT false,
    pain_management TEXT DEFAULT 'Breathing & Hydrotherapy',
    cord_blood_banking TEXT DEFAULT 'Delayed Cord Clamping',
    special_wishes TEXT,
    birth_partner_name TEXT,
    birth_partner_phone TEXT,
    emergency_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    CONSTRAINT uq_birth_ready_user UNIQUE (user_id)
);

-- -----------------------------------------------------------------------------
-- 6. REFERRALS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.referrals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    specialty TEXT NOT NULL,
    specialist_name TEXT,
    facility TEXT,
    contact_phone TEXT,
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'Active',
    urgency TEXT NOT NULL DEFAULT 'Routine',
    issued_date DATE DEFAULT CURRENT_DATE,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 7. NUTRITION_LOGS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.nutrition_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    log_date DATE NOT NULL DEFAULT CURRENT_DATE,
    meal_type TEXT NOT NULL DEFAULT 'Snack',
    food_item TEXT NOT NULL,
    calories INTEGER,
    iron_mg NUMERIC(5,2),
    folate_mcg NUMERIC(6,2),
    calcium_mg NUMERIC(6,2),
    water_ml INTEGER,
    safety_status TEXT NOT NULL DEFAULT 'Safe',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 8. MEDICINE_LOGS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.medicine_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    medicine_name TEXT NOT NULL,
    dosage TEXT NOT NULL,
    scheduled_time TEXT NOT NULL,
    taken BOOLEAN NOT NULL DEFAULT false,
    category TEXT DEFAULT 'Daily Prenatal',
    safety_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- -----------------------------------------------------------------------------
-- 9. VITALS_LOGS TABLE (Blood Pressure, Hydration, Kicks)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.vitals_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    log_date DATE NOT NULL DEFAULT CURRENT_DATE,
    blood_pressure TEXT,
    pulse INTEGER,
    hydration_count INTEGER NOT NULL DEFAULT 0,
    hydration_target INTEGER NOT NULL DEFAULT 8,
    pelvic_floor_minutes INTEGER NOT NULL DEFAULT 0,
    kicks_count INTEGER DEFAULT 0,
    contractions_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- =============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =============================================================================
-- Ensure RLS is enabled on all tables so users can only access their own data.

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.care_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lab_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.birth_ready_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nutrition_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicine_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vitals_logs ENABLE ROW LEVEL SECURITY;

-- Profiles Policies
DROP POLICY IF EXISTS "profiles_select_own" ON public.profiles;
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Appointments Policies
DROP POLICY IF EXISTS "appointments_all_own" ON public.appointments;
CREATE POLICY "appointments_all_own" ON public.appointments FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Care Tasks Policies
DROP POLICY IF EXISTS "care_tasks_all_own" ON public.care_tasks;
CREATE POLICY "care_tasks_all_own" ON public.care_tasks FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Lab Results Policies
DROP POLICY IF EXISTS "lab_results_all_own" ON public.lab_results;
CREATE POLICY "lab_results_all_own" ON public.lab_results FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Birth Ready Plans Policies
DROP POLICY IF EXISTS "birth_ready_plans_all_own" ON public.birth_ready_plans;
CREATE POLICY "birth_ready_plans_all_own" ON public.birth_ready_plans FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Referrals Policies
DROP POLICY IF EXISTS "referrals_all_own" ON public.referrals;
CREATE POLICY "referrals_all_own" ON public.referrals FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Nutrition Logs Policies
DROP POLICY IF EXISTS "nutrition_logs_all_own" ON public.nutrition_logs;
CREATE POLICY "nutrition_logs_all_own" ON public.nutrition_logs FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Medicine Logs Policies
DROP POLICY IF EXISTS "medicine_logs_all_own" ON public.medicine_logs;
CREATE POLICY "medicine_logs_all_own" ON public.medicine_logs FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Vitals Logs Policies
DROP POLICY IF EXISTS "vitals_logs_all_own" ON public.vitals_logs;
CREATE POLICY "vitals_logs_all_own" ON public.vitals_logs FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- =============================================================================
-- AUTOMATIC PROFILE CREATION TRIGGER ON SIGNUP
-- =============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (
        id,
        name,
        avatar_url,
        gestational_week,
        blood_group,
        profile_setup_complete
    ) VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDME_bnLYhvHwLuV6C81uqSH7XK6hGWJdIeyYVUmqtpojZA780Y3USmMWPgERyz5PaUkRHwEORIp2e1HTB-iE5EP5cJMtGKOeutnXfLunKWGrguQOzMSr3wwJJSeOxzoAuDlqKBYX5NEWHIf2QqZQZDOWTTAezIGC_iFfCk8gBvAX0b9jJFAyC7H-sCp92TXL4RMdTLCnVsnHFTJFfOQFcaH0Vpq7JoEQtnJVe8toEciVuvS64RKRV9',
        24,
        'O+',
        false
    )
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =============================================================================
-- PERFORMANCE INDEXES
-- =============================================================================
CREATE INDEX IF NOT EXISTS idx_appointments_user_date ON public.appointments(user_id, date);
CREATE INDEX IF NOT EXISTS idx_care_tasks_user ON public.care_tasks(user_id, completed);
CREATE INDEX IF NOT EXISTS idx_medicine_logs_user ON public.medicine_logs(user_id, scheduled_time);
CREATE INDEX IF NOT EXISTS idx_nutrition_logs_user_date ON public.nutrition_logs(user_id, log_date);
CREATE INDEX IF NOT EXISTS idx_lab_results_user ON public.lab_results(user_id, test_date);
CREATE INDEX IF NOT EXISTS idx_referrals_user ON public.referrals(user_id, status);
CREATE INDEX IF NOT EXISTS idx_vitals_logs_user ON public.vitals_logs(user_id, log_date);
