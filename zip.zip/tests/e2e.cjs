const { chromium } = require('playwright');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

(async () => {
  console.log('Using browser executable:', exe);
  const browser = await chromium.launch({ executablePath: exe, headless: true });
  const context = await browser.newContext({
    viewport: { width: 412, height: 915 }, // Responsive Android/Mobile viewport
    permissions: ['camera'],
  });
  const page = await context.newPage();

  const errors = [];
  page.on('pageerror', (err) => {
    console.error('Browser Page Error:', err);
    errors.push(err.toString());
  });

  console.log('1. Navigating to Mutterse at http://127.0.0.1:5173...');
  await page.goto('http://127.0.0.1:5173', { waitUntil: 'networkidle' });

  // 1. Verify Login Screen
  const title = await page.title();
  console.log('Document Title:', title);
  if (!title.includes('Mutterse')) {
    throw new Error('Expected title to include Mutterse');
  }

  const loginHeader = await page.textContent('h1');
  console.log('Brand Header:', loginHeader);

  // 2. Test 1-Click Demo Login as Elena Vance
  console.log('2. Testing 1-Click Demo Login as Elena Vance...');
  await page.click('button:has-text("1-Click Demo Login as Elena Vance")');
  await page.waitForTimeout(600);

  // 3. Verify Dashboard components
  console.log('3. Verifying Dashboard greeting and gestational progress...');
  const greeting = await page.textContent('h1:has-text("Good morning")');
  console.log('Greeting found:', greeting);

  const countdownText = await page.textContent('h2:has-text("112 Days")');
  console.log('Countdown card found:', countdownText);

  // 4. Test Interactive Medicine Reminder on Dashboard
  console.log('4. Testing Medicine "Mark Taken" button...');
  const markTakenBtn = page.locator('button:has-text("Mark Taken")').first();
  if ((await markTakenBtn.count()) > 0) {
    await markTakenBtn.click();
    await page.waitForTimeout(400);
    const takenLabel = await page.locator('button:has-text("Taken")').first().textContent();
    console.log('Medicine state changed to:', takenLabel);
  }

  // 5. Test Hydration Tracker Increment
  console.log('5. Testing Hydration tracker increment (+ button)...');
  const addWaterBtn = page.locator('button[aria-label="Add glass of water"]');
  if ((await addWaterBtn.count()) > 0) {
    await addWaterBtn.click();
    await page.waitForTimeout(300);
    console.log('Hydration increment clicked successfully');
  }

  // 6. Test Quick Maternal Action: Log Kicks Modal
  console.log('6. Opening Log Kicks modal and recording a kick...');
  await page.click('button:has-text("Log Kicks")');
  await page.waitForTimeout(400);
  await page.click('button:has-text("Tap Kick")');
  await page.waitForTimeout(300);
  await page.click('button:has-text("Save & Finish Session")');
  await page.waitForTimeout(400);
  console.log('Kick session recorded and modal closed');

  // 7. Test Quick Maternal Action: Ask Midwife AI Modal
  console.log('7. Opening Ask Midwife 24/7 AI Guidance modal...');
  await page.click('button:has-text("Ask Midwife")');
  await page.waitForTimeout(400);
  await page.fill('input[placeholder*="Ask about kicks"]', 'Are mild cramps normal at week 24?');
  await page.click('form button[type="submit"]');
  await page.waitForTimeout(1500); // Allow AI response simulation
  const midwifeResponseCount = await page.locator('text=Braxton Hicks').count();
  console.log('Midwife AI response received:', midwifeResponseCount > 0);
  await page.click('button:has-text("close")');
  await page.waitForTimeout(300);

  // 8. Test Navigation to AI Scan Tab
  console.log('8. Navigating to AI Scan tab via bottom navigation...');
  await page.click('button[aria-label="AI Scan"]');
  await page.waitForTimeout(500);

  const scannerHeader = await page.textContent('span:has-text("AI Clinical Scanner")');
  console.log('AI Scanner header verified:', scannerHeader);

  // Verify Demo Mode Banner
  const demoBanner = await page.locator('text=Client Simulation Mode').count();
  console.log('AI Scanner Demo Mode banner verified:', demoBanner > 0);

  // Test Category Switcher: Prescriptions
  console.log('9. Switching scanner mode to Prescriptions...');
  await page.click('button:has-text("Prescriptions")');
  await page.waitForTimeout(2500); // Wait for simulation OCR
  const prescriptionTitle = await page.locator('text=Prescription: Prenatal Ferrous Ascorbate').count();
  console.log('Prescription scan extracted:', prescriptionTitle > 0);

  // Test "Save to Medicine Schedule"
  console.log('10. Saving scanned prescription to Medicine Schedule...');
  await page.click('button:has-text("Save to Medicine Schedule")');
  await page.waitForTimeout(400);

  // 11. Test Navigation to Care Tab
  console.log('11. Navigating to Care tab...');
  await page.click('button[aria-label="Care"]');
  await page.waitForTimeout(500);
  const careHeader = await page.textContent('h1');
  console.log('Care header:', careHeader);

  // 12. Test Navigation to Settings Tab
  console.log('12. Navigating to Settings tab...');
  await page.click('button[aria-label="Settings"]');
  await page.waitForTimeout(500);

  const profileName = await page.textContent('h2:has-text("Elena Vance")');
  console.log('Settings Profile verified for:', profileName);

  // 13. Test "Edit Profile" -> Navigates to Mother Profile Setup
  console.log('13. Tapping Edit Profile to test Mother Profile Setup screen...');
  await page.click('button:has-text("Edit Profile")');
  await page.waitForTimeout(500);

  const setupHeader = await page.textContent('h1:has-text("Profile Setup")');
  console.log('Profile Setup screen active:', setupHeader);

  // Edit Mother's Name and test blood group chip
  console.log('14. Updating gestational details & blood group...');
  await page.fill('input#fullName', 'Elena Vance-Montgomery');
  await page.click('button:has-text("AB+")');
  await page.waitForTimeout(300);

  // Save & Continue back to dashboard
  console.log('15. Clicking Save & Continue to Care Plan...');
  await page.click('button:has-text("Save & Continue to Care Plan")');
  await page.waitForTimeout(600);

  // 16. Verify Local Storage Persistence on Page Reload
  console.log('16. Reloading browser page to verify persistent authentication & profile changes...');
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  const reloadedGreeting = await page.textContent('h1:has-text("Good morning")');
  console.log('Persistent session verified on reload:', reloadedGreeting);

  // 17. Test Log Out Flow
  console.log('17. Navigating to Settings and performing Sign Out...');
  await page.click('button[aria-label="Settings"]');
  await page.waitForTimeout(500);
  await page.click('button:has-text("Log Out")');
  await page.waitForTimeout(400);
  await page.click('button:has-text("Confirm Log Out")');
  await page.waitForTimeout(600);

  const loggedOutHeader = await page.locator('text=Welcome back, mama').count();
  console.log('Logged out successfully, returned to Login screen:', loggedOutHeader > 0);

  console.log('Page error count:', errors.length);

  await browser.close();

  if (errors.length > 0 || !loggedOutHeader) {
    console.error('Validation test failed with errors:', errors);
    process.exit(1);
  } else {
    console.log('>>> ALL MUTTERSE MATERNAL HEALTHCARE VERIFICATION TESTS PASSED! <<<');
    process.exit(0);
  }
})();
