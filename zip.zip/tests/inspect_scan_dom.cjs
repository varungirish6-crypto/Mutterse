const { chromium } = require('playwright');
const fs = require('fs');

(async () => {
  const browser = await chromium.launch({
    executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    headless: true
  });
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 }
  });
  await page.goto('http://localhost:5173');
  await page.click('text=Continue as Demo');
  await page.waitForTimeout(500);
  await page.locator('button[aria-label="AI Scan"]').click();
  await page.waitForTimeout(1000);

  // Upload sample image
  const fileInput = await page.$('input[type="file"]');
  await fileInput.setInputFiles('tests/sample_medicine.png');
  console.log('Uploaded! Waiting 12s for scan...');
  await page.waitForTimeout(12000);

  // Get all text and headings
  const texts = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, article')).map(el => ({
      tag: el.tagName,
      text: el.innerText.trim()
    })).filter(x => x.text.length > 0);
  });
  console.log('Headings & Articles:', JSON.stringify(texts, null, 2));

  // Check scroll position and viewport
  const metrics = await page.evaluate(() => ({
    scrollY: window.scrollY,
    innerHeight: window.innerHeight,
    scrollHeight: document.body.scrollHeight,
  }));
  console.log('Scroll metrics:', metrics);

  await browser.close();
})();
