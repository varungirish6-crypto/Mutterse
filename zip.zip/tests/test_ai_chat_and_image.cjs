const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const browserExecutable = edgePaths.find((p) => fs.existsSync(p));

// Generate a 1x1 png base64 for test
const samplePixelBase64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

// Create a synthetic medicine-like image using node-canvas or pure SVG rendered if possible, or use a sample base64
// We also have artifact media: C:\Users\NITRO\.gemini\antigravity\brain\baf82ada-d008-4679-b597-73770e4fc294\.user_uploaded\media_1793454475735_b05f802d.jpg
const uploadedPicPath = 'C:\\Users\\NITRO\\.gemini\\antigravity\\brain\\baf82ada-d008-4679-b597-73770e4fc294\\.user_uploaded\\media_1793454475735_b05f802d.jpg';
let realImageBase64 = null;
if (fs.existsSync(uploadedPicPath)) {
  const buf = fs.readFileSync(uploadedPicPath);
  realImageBase64 = `data:image/jpeg;base64,${buf.toString('base64')}`;
}

async function runTestSuite() {
  console.log('====================================================');
  console.log('MUTTERSE AI CHAT & IMAGE ANALYSIS TEST SUITE');
  console.log('====================================================\n');

  const API_BASE = 'http://localhost:3001';

  // 1. Backend /api/gemini/health
  console.log('1. Testing Gemini Health...');
  const healthRes = await fetch(`${API_BASE}/api/gemini/health`);
  const healthJson = await healthRes.json();
  console.log('   Health status:', healthJson);
  if (!healthJson.configured) throw new Error('Gemini API is not configured on proxy server!');

  // 2. Clinical Paracetamol Query
  console.log('\n2. Testing Clinical Query: "Paracetamol use in pregnancy"...');
  const chatRes1 = await fetch(`${API_BASE}/api/gemini/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: 'Paracetamol use in pregnancy',
      history: [],
    }),
  });
  const chatJson1 = await chatRes1.json();
  console.log('   Status:', chatRes1.status);
  console.log('   Model:', chatJson1.modelUsed);
  console.log('   AI Response:\n', chatJson1.reply);
  
  if (!chatJson1.success || !chatJson1.reply) {
    throw new Error('Chat query failed!');
  }
  const replyLower = chatJson1.reply.toLowerCase();
  const hasParacetamol = replyLower.includes('paracetamol') || replyLower.includes('acetaminophen');
  const hasDoseDuration = replyLower.includes('dose') || replyLower.includes('duration');
  const hasConsult = replyLower.includes('doctor') || replyLower.includes('obstetrician') || replyLower.includes('midwife') || replyLower.includes('healthcare');
  console.log('   Clinical checks:', { hasParacetamol, hasDoseDuration, hasConsult });

  // 3. Multimodal Image Analysis via Chat (with uploaded image if available)
  if (realImageBase64) {
    console.log('\n3. Testing Multimodal Image Analysis via /api/gemini/chat...');
    const chatRes2 = await fetch(`${API_BASE}/api/gemini/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'Please analyze this medicine/packaging image and explain its use, safety during pregnancy, precautions, and when to seek medical advice.',
        image: realImageBase64,
        mimeType: 'image/jpeg',
      }),
    });
    const chatJson2 = await chatRes2.json();
    console.log('   Status:', chatRes2.status);
    console.log('   Model:', chatJson2.modelUsed);
    console.log('   AI Multimodal Response:\n', chatJson2.reply?.slice(0, 300) + '...');
    if (!chatJson2.success || !chatJson2.reply) {
      throw new Error('Multimodal chat failed!');
    }
  }

  // 4. Non-medicine image evidence test
  console.log('\n4. Testing Non-Medicine / Ambiguous Image Identification Boundaries...');
  const chatRes3 = await fetch(`${API_BASE}/api/gemini/scan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      image: samplePixelBase64,
      mimeType: 'image/png',
    }),
  });
  const scanJson3 = await chatRes3.json();
  console.log('   Scan Result for single pixel (non-medicine):');
  console.log('   Title:', scanJson3.data?.title);
  console.log('   isLegible:', scanJson3.data?.isLegible);
  console.log('   Confidence Notes:', scanJson3.data?.confidenceNotes);

  // 5. Playwright Browser End-to-End UI Test
  console.log('\n5. Launching Browser UI Test with Playwright...');
  const browser = await chromium.launch({
    headless: true,
    executablePath: browserExecutable,
  });
  const page = await browser.newPage();
  const consoleErrors = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      consoleErrors.push(msg.text());
    }
  });

  await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });
  console.log('   Loaded app URL.');

  // Find "Ask Midwife" button on Dashboard
  const askMidwifeBtn = page.locator('button:has-text("Ask Midwife")');
  await askMidwifeBtn.waitFor({ state: 'visible', timeout: 6000 });
  await askMidwifeBtn.click();
  console.log('   Clicked "Ask Midwife".');

  // Verify modal is open
  const modalTitle = page.locator('h3:has-text("24/7 Maternal AI Guide")');
  await modalTitle.waitFor({ state: 'visible', timeout: 5000 });
  console.log('   24/7 Maternal AI Guide modal is visible.');

  // Type question in the input
  const chatInput = page.locator('form input[type="text"]').last();
  await chatInput.fill('Paracetamol use in pregnancy');
  console.log('   Typed query into chat input.');

  // Submit form
  const sendBtn = page.locator('form button[aria-label="Send message"], form button:has-text("send")').last();
  await sendBtn.click();
  console.log('   Sent question.');

  // Wait for AI response to appear
  await page.waitForFunction(() => {
    const bubbles = document.querySelectorAll('.lg-modal p');
    for (const b of bubbles) {
      const t = b.textContent?.toLowerCase() || '';
      if (t.includes('paracetamol') || t.includes('fever') || t.includes('pain') || t.includes('analgesic')) {
        return true;
      }
    }
    return false;
  }, { timeout: 20000 });
  console.log('   AI response appeared in chat modal successfully!');

  // Close modal
  const closeBtn = page.locator('div.lg-modal button:has-text("close")').first();
  await closeBtn.click();
  console.log('   Closed chat modal.');

  // Test Scan screen navigation
  console.log('\n6. Testing Scan screen navigation...');
  const scanNav = page.locator('nav button').nth(2); // Scan tab
  await scanNav.click();
  await page.waitForTimeout(1000);

  // Verify Scan Screen renders without white screen
  const scanHeading = page.locator('text=Instant Maternal Safety Scan, text=Active Ingredients, text=Camera, text=Upload').first();
  await scanHeading.waitFor({ state: 'visible', timeout: 5000 });
  console.log('   Scan screen rendered correctly (no white screen)!');

  await browser.close();

  if (consoleErrors.length > 0) {
    console.log('   Console errors captured during test:', consoleErrors);
  } else {
    console.log('   Zero console errors during browser navigation.');
  }

  console.log('\n====================================================');
  console.log('ALL AI CHAT & IMAGE ANALYSIS TESTS PASSED!');
  console.log('====================================================');
}

runTestSuite().catch((err) => {
  console.error('\n❌ Test Suite Failed:', err);
  process.exit(1);
});
