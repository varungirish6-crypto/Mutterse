const { chromium } = require('playwright');
const { spawn } = require('child_process');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

async function runAllScenarios() {
  console.log('====================================================');
  console.log('MUTTERSE AI CHAT SCENARIO VERIFICATION SUITE');
  console.log('====================================================\n');

  // Start Vite dev server on port 5174 to avoid any port conflicts
  console.log('[Step 1] Starting Vite Dev Server on port 5174...');
  const vite = spawn('npx.cmd', ['vite', '--port', '5174'], { shell: true, stdio: 'pipe' });

  let serverStarted = false;
  vite.stdout.on('data', (d) => {
    const text = d.toString();
    if (text.includes('5174')) serverStarted = true;
  });

  // Wait up to 5s for Vite
  for (let i = 0; i < 25; i++) {
    if (serverStarted) break;
    await new Promise((r) => setTimeout(r, 200));
  }
  console.log('✅ Vite Dev Server is ready.\n');

  try {
    // Scenario 1: Normal chat message "Hi" via API
    console.log('[Scenario 1] Testing normal message "Hi" to POST /api/gemini/chat...');
    const res1 = await fetch('http://localhost:5174/api/gemini/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: 'Hi' }),
    });
    console.log('  Status:', res1.status);
    console.log('  Content-Type:', res1.headers.get('content-type'));
    const data1 = await res1.json();
    console.log('  Success:', data1.success);
    console.log('  Model Used:', data1.modelUsed);
    console.log('  AI Reply Snippet:', data1.reply?.slice(0, 120) + '...\n');
    if (!data1.success || !data1.reply) throw new Error('Scenario 1 failed');

    // Scenario 2: Question about medicine label
    console.log('[Scenario 2] Testing medicine question to POST /api/gemini/chat...');
    const res2 = await fetch('http://localhost:5174/api/gemini/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'What is the dosage on this label?',
        medicineContext: {
          title: 'Prenatal Ferrous Fumarate',
          strength: '210mg (68mg elemental iron)',
          dosage: 'One tablet daily before breakfast',
          warnings: 'Keep out of reach of children.',
        },
      }),
    });
    const data2 = await res2.json();
    console.log('  Status:', res2.status);
    console.log('  Content-Type:', res2.headers.get('content-type'));
    console.log('  Success:', data2.success);
    console.log('  AI Reply Snippet:', data2.reply?.slice(0, 120) + '...\n');
    if (!data2.success || !data2.reply.includes('tablet')) throw new Error('Scenario 2 failed');

    // Scenario 3: Missing / invalid route -> must return JSON 404, never HTML
    console.log('[Scenario 3] Testing non-existent route POST /api/gemini/invalid-route...');
    const res3 = await fetch('http://localhost:5174/api/gemini/invalid-route', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    const ct3 = res3.headers.get('content-type') || '';
    const text3 = await res3.text();
    console.log('  Status:', res3.status);
    console.log('  Content-Type:', ct3);
    console.log('  Body:', text3);
    if (!ct3.includes('application/json') || text3.includes('<!doctype')) {
      throw new Error('Scenario 3 failed: Unhandled route returned HTML instead of JSON!');
    }
    console.log('  ✅ Non-existent endpoint returned valid JSON error, not HTML.\n');

    // Scenario 4: Method not allowed -> must return JSON 405, never HTML
    console.log('[Scenario 4] Testing GET /api/gemini/chat (wrong HTTP method)...');
    const res4 = await fetch('http://localhost:5174/api/gemini/chat');
    const ct4 = res4.headers.get('content-type') || '';
    const text4 = await res4.text();
    console.log('  Status:', res4.status);
    console.log('  Content-Type:', ct4);
    console.log('  Body:', text4);
    if (!ct4.includes('application/json') || text4.includes('<!doctype')) {
      throw new Error('Scenario 4 failed: GET request returned HTML instead of JSON!');
    }
    console.log('  ✅ Method not allowed returned valid JSON error, not HTML.\n');

    // Scenario 5: Full Browser UI Test using Playwright
    console.log('[Scenario 5] Testing End-to-End Chat in real Chromium browser on port 5174...');
    const browser = await chromium.launch({ executablePath: exe, headless: true });
    const context = await browser.newContext({ viewport: { width: 412, height: 915 } });
    const page = await context.newPage();

    let interceptedRequest = false;
    let interceptedResponseJson = false;

    page.on('request', (req) => {
      if (req.url().includes('/api/gemini/chat')) {
        interceptedRequest = true;
        console.log('  [Browser Net] --> POST', req.url());
      }
    });

    page.on('response', async (res) => {
      if (res.url().includes('/api/gemini/chat')) {
        const ct = res.headers()['content-type'] || '';
        interceptedResponseJson = ct.includes('application/json');
        console.log('  [Browser Net] <-- Status:', res.status(), 'Content-Type:', ct);
      }
    });

    await page.goto('http://localhost:5174', { waitUntil: 'networkidle' });
    await page.click('button:has-text("Continue as Demo")');
    await page.waitForTimeout(1000);

    // Switch to AI Scan tab
    await page.click('button[aria-label="AI Scan"]');
    await page.waitForTimeout(1000);

    // Type "Hi" and Send
    const input = page.locator('input[placeholder*="medicine"]').first();
    await input.scrollIntoViewIfNeeded();
    await input.fill('Hi');
    await page.waitForTimeout(300);
    await page.click('button[aria-label="Send message"]');

    // Wait for AI response to appear in chat
    console.log('  Waiting for AI message bubble to render...');
    await page.waitForSelector('.whitespace-pre-line', { timeout: 10000 });
    await page.waitForTimeout(2000);

    // Verify error banner is absent
    const errorCount = await page.locator('.bg-\\[\\#ffdad6\\]:has-text("not valid JSON")').count();
    const chatTexts = await page.locator('.whitespace-pre-line').allInnerTexts();
    console.log('  Rendered Chat Messages in UI:', chatTexts);

    if (errorCount > 0) {
      throw new Error('Scenario 5 failed: Error banner with "not valid JSON" was found in UI!');
    }
    if (!interceptedRequest || !interceptedResponseJson || chatTexts.length < 2) {
      throw new Error('Scenario 5 failed: Chat response was not received or not rendered in UI!');
    }

    console.log('  ✅ Browser Chat successfully completed turn-by-turn with Gemini AI!\n');
    await browser.close();

    console.log('====================================================');
    console.log('🎉 ALL 5 CHAT SCENARIOS PASSED WITH 100% SUCCESS!');
    console.log('====================================================');
  } finally {
    vite.kill();
  }
}

runAllScenarios().catch((err) => {
  console.error('❌ Verification failed:', err);
  process.exit(1);
});
