const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

async function runEndToEndScanTest() {
  console.log('====================================================');
  console.log('MUTTERSE AI IMAGE SCANNER: UPLOAD-TO-RESULT E2E TEST');
  console.log('====================================================\n');

  const browser = await chromium.launch({
    executablePath: exe,
    headless: true,
  });

  const page = await browser.newPage({
    viewport: { width: 390, height: 844 }, // Mobile viewport (iPhone 14 / Pixel)
  });

  const consoleErrors = [];
  const pageErrors = [];

  page.on('console', (msg) => {
    console.log(`  [Browser ${msg.type()}]`, msg.text());
    if (msg.type() === 'error') {
      consoleErrors.push(msg.text());
    }
  });

  page.on('request', (req) => {
    if (req.url().includes('/api/gemini')) {
      console.log(`  ➡️ [Net Req] ${req.method()} ${req.url()}`);
    }
  });

  page.on('response', async (res) => {
    if (res.url().includes('/api/gemini')) {
      console.log(`  ⬅️ [Net Res] ${res.status()} ${res.url()}`);
      try {
        const text = await res.text();
        console.log(`  ⬅️ [Net Res Body]:`, text.substring(0, 250));
      } catch (e) {}
    }
  });

  page.on('pageerror', (err) => {
    pageErrors.push(err.message);
    console.log('  💥 Page Error:', err.message);
  });

  // Step 1: Open app
  console.log('[Step 1] Loading application at http://localhost:5173...');
  await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });

  const demoButton = page.locator('text=Continue as Demo').first();
  if (await demoButton.isVisible({ timeout: 2000 }).catch(() => false)) {
    console.log('  Clicking "Continue as Demo"...');
    await demoButton.click();
    await page.waitForTimeout(1000);
  }

  // Step 2: Navigate to AI Scan tab
  console.log('[Step 2] Navigating to AI Scan tab...');
  const scanTab = page.locator('button[aria-label="AI Scan"]').first();
  await scanTab.click();
  await page.waitForTimeout(1000);

  // Verify Scanner View elements
  console.log('[Step 3] Verifying initial Scanner View...');
  const hasModeButtons = await page.isVisible('text=Medicine Packaging');
  const hasUploadButton = await page.isVisible('text=Gallery / Upload');
  const hasCameraButton = await page.isVisible('text=Open Camera');
  console.log('  Scanner controls visible:', { hasModeButtons, hasUploadButton, hasCameraButton });
  if (!hasModeButtons || !hasUploadButton || !hasCameraButton) {
    throw new Error('Scanner View is missing expected controls.');
  }

  // Step 4: Upload test medicine image
  console.log('[Step 4] Attaching medicine packaging image...');
  const testImagePath = path.resolve('tests/sample_medicine.png');
  // Use a sample image
  const sampleBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  fs.writeFileSync(testImagePath, Buffer.from(sampleBase64, 'base64'));

  const fileInput = await page.$('input[type="file"]');
  await fileInput.setInputFiles(testImagePath);
  console.log('  Image uploaded! Checking Analyzing Loading State...');

  // Step 5: Check Analyzing / Loading State
  await page.waitForTimeout(500);
  const isAnalyzingVisible = await page.isVisible('text=Reading Medicine Packaging…');
  console.log('  Analyzing loading state displayed:', isAnalyzingVisible);

  // Step 6: Wait for Gemini response and Result Page transition
  console.log('[Step 6] Waiting for Gemini AI analysis and Result Page navigation...');
  const resultHeader = page.getByText('Clinical Scan Result').first();
  await resultHeader.waitFor({ timeout: 25000 });
  console.log('  ✅ Result Page successfully navigated and rendered!');

  await page.waitForTimeout(1000);

  // Step 7: Verify all clinical result components are visible and NOT BLANK
  console.log('[Step 7] Checking Result Page fields...');
  const hasMedicineTitle = await page.isVisible('h3');
  const hasActiveIngredients = await page.isVisible('text=Active Ingredients');
  const hasDosage = await page.isVisible('text=Visible Label Directions');
  const hasStrength = await page.isVisible('text=Strength / Potency');
  const hasWarnings = await page.isVisible('text=Visible Warnings & Label Details');
  const hasDisclaimer = await page.isVisible('text=Required Medical Confirmation Notice');
  const hasAIChat = await page.isVisible('text=Ask Mutterse AI');
  const hasScanAnother = await page.isVisible('text=Scan Another');

  console.log('  Result Page fields verification:', {
    hasMedicineTitle,
    hasActiveIngredients,
    hasDosage,
    hasStrength,
    hasWarnings,
    hasDisclaimer,
    hasAIChat,
    hasScanAnother,
  });

  if (!hasActiveIngredients || !hasDosage || !hasStrength || !hasAIChat) {
    throw new Error('Result Page is missing one or more required clinical fields!');
  }

  // Take screenshot of the complete working Result Page
  await page.screenshot({ path: 'tests/result_page_screenshot.png', fullPage: true });
  console.log('  📸 Full Result Page screenshot saved: tests/result_page_screenshot.png');

  // Step 8: Test "Scan Another" navigation back to Scanner View
  console.log('[Step 8] Testing navigation back to Scanner View ("Scan Another")...');
  const scanAnotherButton = page.locator('button:has-text("Scan Another")').first();
  await scanAnotherButton.click();
  await page.waitForTimeout(1000);

  const backOnScanner = await page.isVisible('text=Gallery / Upload');
  console.log('  Successfully navigated back to Scanner View:', backOnScanner);
  if (!backOnScanner) {
    throw new Error('Failed to return to Scanner View.');
  }

  // Step 9: Verify console health (no @fluentui/react-motion invalid child errors)
  console.log('[Step 9] Checking runtime errors...');
  const motionErrors = consoleErrors.filter((e) => e.includes('react-motion'));
  console.log('  FluentUI Motion errors count:', motionErrors.length);
  console.log('  Total Page Uncaught Errors:', pageErrors.length);

  if (pageErrors.length > 0) {
    throw new Error(`Uncaught page errors detected: ${pageErrors.join(', ')}`);
  }

  console.log('\n====================================================');
  console.log('🎉 UPLOAD-TO-RESULT COMPLETE FLOW PASSED WITH 100% SUCCESS!');
  console.log('====================================================');

  await browser.close();
}

runEndToEndScanTest().catch((err) => {
  console.error('\n❌ Test failed:', err);
  process.exit(1);
});
