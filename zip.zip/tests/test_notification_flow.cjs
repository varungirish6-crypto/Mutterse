const { chromium } = require('playwright');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

(async () => {
  console.log('Testing Mutterse Notification & Test Alert flow...');
  const browser = await chromium.launch({ executablePath: exe, headless: true });
  const context = await browser.newContext({
    viewport: { width: 412, height: 915 },
    permissions: ['notifications'],
  });
  const page = await context.newPage();

  const errors = [];
  page.on('pageerror', (err) => {
    console.error('Page error:', err);
    errors.push(err.toString());
  });

  await page.goto('http://127.0.0.1:4173', { waitUntil: 'networkidle' });

  // 1. Login as Demo
  console.log('1. Logging in as Demo user...');
  await page.click('button:has-text("Continue as Demo")');
  await page.waitForTimeout(600);

  // 2. Navigate to Care tab
  console.log('2. Navigating to Care tab...');
  await page.click('button[aria-label="Care"]');
  await page.waitForTimeout(500);

  // 3. Switch to Reminders sub-tab
  console.log('3. Switching to Reminders section...');
  await page.click('button:has-text("Reminders")');
  await page.waitForTimeout(500);

  // 4. Verify "Test Alert" button is present and click it
  console.log('4. Clicking "Test Alert" button to trigger instant notification...');
  const testAlertBtn = page.locator('button:has-text("Test Alert")').first();
  if (!(await testAlertBtn.isVisible())) {
    throw new Error('"Test Alert" button is not visible');
  }
  await testAlertBtn.click();
  await page.waitForTimeout(600);

  // 5. Verify Toast message appears
  const toast = page.locator('text=Test notification fired');
  if (!(await toast.isVisible())) {
    throw new Error('Toast confirmation for test notification did not appear');
  }
  console.log('Toast notification alert verified successfully!');

  console.log('Total page errors:', errors.length);
  if (errors.length > 0) {
    throw new Error(`Errors during notification test: ${errors.join(', ')}`);
  }

  console.log('🎉 TEST ALERT & NOTIFICATION SYSTEM FULLY FUNCTIONAL! 🎉');
  await browser.close();
  process.exit(0);
})().catch((err) => {
  console.error('Test notification flow failed:', err);
  process.exit(1);
});
