const { chromium } = require('playwright');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

(async () => {
  console.log('Testing Mutterse Reminders & In-App Camera...');
  console.log('Browser executable:', exe);

  const browser = await chromium.launch({ executablePath: exe, headless: true });
  const context = await browser.newContext({
    viewport: { width: 412, height: 915 },
    permissions: ['camera', 'notifications'],
  });
  const page = await context.newPage();

  const errors = [];
  page.on('pageerror', (err) => {
    console.error('Page error:', err);
    errors.push(err.toString());
  });

  await page.goto('http://127.0.0.1:4173', { waitUntil: 'networkidle' });

  // 1. Login as Demo
  console.log('1. Logging in as Demo user...');
  await page.click('button:has-text("Continue as Demo")');
  await page.waitForTimeout(600);

  // 2. Navigate to Care tab
  console.log('2. Navigating to Care tab...');
  await page.click('button[aria-label="Care"]');
  await page.waitForTimeout(500);

  // 3. Switch to Reminders sub-tab
  console.log('3. Switching to Reminders section...');
  await page.click('button:has-text("Reminders")');
  await page.waitForTimeout(500);

  // 4. Verify "+ Add Reminder" button is visible
  console.log('4. Checking "+ Add Reminder" button...');
  const addReminderBtn = page.locator('button:has-text("Add Reminder")');
  if (!(await addReminderBtn.isVisible())) {
    throw new Error('Add Reminder button is not visible');
  }
  console.log('Add Reminder button verified!');

  // 5. Click Add Reminder and verify modal contents
  console.log('5. Opening Add Reminder modal...');
  await addReminderBtn.click();
  await page.waitForTimeout(400);

  const modalTitle = await page.locator('h2:has-text("New Reminder")').textContent();
  console.log('Modal opened with title:', modalTitle);

  // Check form fields
  await page.fill('input[placeholder*="Take iron tablet"]', 'Take Calcium Tablet');
  await page.fill('textarea[placeholder*="Additional instructions"]', 'Take after dinner with milk');

  // Select category "Medication" inside form
  await page.click('form button:has-text("Medication")');

  // Select repeat option "Daily" inside form
  await page.click('form button:has-text("Daily")');

  // Save Reminder
  console.log('6. Saving new reminder...');
  await page.click('form button[type="submit"]');
  await page.waitForTimeout(600);

  // Verify it appears in upcoming
  const reminderCard = page.locator('h3:has-text("Take Calcium Tablet")').first();
  if (!(await reminderCard.isVisible())) {
    throw new Error('Created reminder not found in list');
  }
  console.log('New reminder successfully added and displayed!');

  // 7. Verify Next Reminder card is visible
  const nextBanner = await page.locator('text=Next Reminder').count();
  console.log('Next Reminder banner active:', nextBanner > 0);

  // 8. Edit reminder
  console.log('8. Testing edit reminder...');
  const editBtn = page.locator('button[aria-label="Edit reminder"]').first();
  await editBtn.click();
  await page.waitForTimeout(400);

  await page.fill('input[value*="Take Calcium Tablet"]', 'Take Calcium Tablet 500mg');
  await page.click('button:has-text("Save Changes")');
  await page.waitForTimeout(600);

  const updatedCard = page.locator('h3:has-text("Take Calcium Tablet 500mg")').first();
  if (!(await updatedCard.isVisible())) {
    throw new Error('Edited reminder title not updated');
  }
  console.log('Reminder successfully edited!');

  // 9. Mark as complete
  console.log('9. Marking reminder as completed...');
  const completeBtn = page.locator('button[aria-label="Mark reminder completed"]').first();
  await completeBtn.click();
  await page.waitForTimeout(500);

  // Switch to Completed tab
  await page.click('button:has-text("Completed")');
  await page.waitForTimeout(400);
  const completedCard = page.locator('h3:has-text("Take Calcium Tablet 500mg")').first();
  if (!(await completedCard.isVisible())) {
    throw new Error('Completed reminder not found in Completed tab');
  }
  console.log('Completed reminder verified in Completed tab!');

  // 10. Test persistence across reload
  console.log('10. Testing persistence across page reload...');
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  // Navigate back to Care -> Reminders -> Completed
  await page.click('button[aria-label="Care"]');
  await page.waitForTimeout(400);
  await page.click('button:has-text("Reminders")');
  await page.waitForTimeout(400);
  await page.click('button:has-text("Completed")');
  await page.waitForTimeout(400);

  const persistedCard = page.locator('h3:has-text("Take Calcium Tablet 500mg")').first();
  if (!(await persistedCard.isVisible())) {
    throw new Error('Reminder failed to persist in localStorage across reload');
  }
  console.log('Reminder persistence verified across reload!');

  // 11. Test AI Scan In-App Camera
  console.log('11. Testing AI Scan in-app camera capture flow...');
  await page.click('button[aria-label="AI Scan"]');
  await page.waitForTimeout(500);

  // Verify "Open Camera" button
  const openCameraBtn = page.locator('button:has-text("Open Camera")');
  if (!(await openCameraBtn.isVisible())) {
    throw new Error('Open Camera button not found on AI Scanner screen');
  }
  console.log('Open Camera button verified on AI Scanner!');

  // Click Open Camera -> opens InAppCameraModal
  await openCameraBtn.click();
  await page.waitForTimeout(800);

  // Verify InAppCameraModal is visible
  const videoElem = page.locator('video');
  const shutterBtn = page.locator('button[aria-label="Take Photo"]');
  const closeBtn = page.locator('button[aria-label="Close camera"]');

  if (!(await shutterBtn.isVisible())) {
    throw new Error('In-App Camera shutter button not visible in modal');
  }
  console.log('In-App Camera opened full-screen directly inside Mutterse!');

  // Capture photo via in-app shutter
  console.log('12. Simulating photo capture via in-app shutter...');
  await shutterBtn.click();
  await page.waitForTimeout(500);

  // Verify Review state with Retake and Continue buttons
  const retakeBtn = page.locator('button:has-text("Retake")');
  const continueBtn = page.locator('button:has-text("Continue Scan")');

  if (!(await retakeBtn.isVisible()) || !(await continueBtn.isVisible())) {
    throw new Error('Retake and Continue buttons not visible after capturing photo');
  }
  console.log('Photo preview review screen verified with Retake & Continue!');

  // Test Continue Scan
  console.log('13. Tapping Continue Scan to send to AI detection...');
  await continueBtn.click();
  await page.waitForTimeout(2800); // Allow simulation OCR

  // Verify OCR results appeared
  const extractedHeader = page.locator('text=Extracted Clinical Scan');
  if (!(await extractedHeader.isVisible())) {
    throw new Error('Extracted Clinical Scan result not visible after camera scan');
  }
  console.log('AI Scan workflow successfully analyzed captured photo!');

  // Verify Active Ingredients and match score
  const matchScore = await page.locator('text=% Match').first().textContent();
  console.log('Scan match score:', matchScore);

  console.log('Total errors:', errors.length);
  if (errors.length > 0) {
    throw new Error(`Errors during test: ${errors.join(', ')}`);
  }

  console.log('🎉 ALL MUTTERSE REMINDERS AND IN-APP CAMERA TESTS PASSED SUCCESSFULLY! 🎉');
  await browser.close();
  process.exit(0);
})().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
