const { chromium } = require('playwright');
const path = require('path');

const exe = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

(async () => {
  console.log('--- Testing Ask Mutterse AI on Result Page ---');
  const browser = await chromium.launch({ executablePath: exe, headless: true });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });

  await page.goto('http://localhost:5173');
  await page.click('text=Continue as Demo');
  await page.waitForTimeout(500);

  await page.click('button[aria-label="AI Scan"]');
  await page.waitForTimeout(500);

  // Upload sample image
  const fileInput = await page.$('input[type="file"]');
  await fileInput.setInputFiles(path.resolve('tests/sample_medicine.png'));

  // Wait for Result page
  await page.getByText('Clinical Scan Result').first().waitFor({ timeout: 25000 });
  console.log('✅ Result Page loaded');

  // Find Ask Mutterse AI input
  const chatInput = page.locator('input[placeholder*="Ask"]');
  await chatInput.fill('What is this medicine used for?');
  await page.locator('button[aria-label="Send message"]').click();
  console.log('Sent question to Mutterse AI on result page...');

  // Wait for AI reply
  await page.waitForSelector('text=Mutterse AI is reviewing label details…', { timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(10000);

  // Check chat messages rendered
  const chatMessages = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('section[aria-label="Ask Mutterse AI"] p')).map(p => p.innerText.trim());
  });
  console.log('Chat messages on Result Page:', chatMessages);

  if (chatMessages.length < 2) {
    throw new Error('Chat message reply not rendered!');
  }

  console.log('✅ Ask Mutterse AI on Result Page works end-to-end!');
  await browser.close();
})();
