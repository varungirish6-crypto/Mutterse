const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

async function runScanTest() {
  console.log('--- Testing Scan Flow in Playwright ---');
  const browser = await chromium.launch({
    executablePath: exe,
    headless: true,
  });

  const page = await browser.newPage();

  const consoleLogs = [];
  const pageErrors = [];

  page.on('console', (msg) => {
    const text = msg.text();
    consoleLogs.push(`[${msg.type()}] ${text}`);
    if (msg.type() === 'error') {
      console.log('🔴 Browser console.error:', text);
    }
  });

  page.on('pageerror', (err) => {
    pageErrors.push(err.message + '\n' + err.stack);
    console.log('💥 Uncaught Page Error:', err.message);
  });

  page.on('request', (req) => {
    if (req.url().includes('/api/gemini')) {
      console.log(`➡️ [Net Req] ${req.method()} ${req.url()}`);
    }
  });

  page.on('response', async (res) => {
    if (res.url().includes('/api/gemini')) {
      console.log(`⬅️ [Net Res] Status: ${res.status()} Content-Type: ${res.headers()['content-type']}`);
      try {
        const text = await res.text();
        console.log(`⬅️ [Net Res Body]:`, text.substring(0, 300));
      } catch (e) {}
    }
  });

  // Navigate to app
  console.log('Navigating to http://localhost:5173 ...');
  await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });

  // Check if login page or main app
  const demoButton = page.locator('text=Continue as Demo').first();
  if (await demoButton.isVisible({ timeout: 2000 }).catch(() => false)) {
    console.log('Logging in via Continue as Demo...');
    await demoButton.click();
    await page.waitForTimeout(1000);
  }

  // Click on Scan tab
  console.log('Clicking on Scan tab...');
  const scanButton = page.locator('button[aria-label="AI Scan"], button:has-text("AI Scan")').first();
  await scanButton.click();
  await page.waitForTimeout(1500);

  // Take screenshot before upload
  await page.screenshot({ path: 'tests/screenshot_before_upload.png' });
  console.log('Saved tests/screenshot_before_upload.png');

  // Create a sample medicine packaging test image
  const testImagePath = path.resolve('tests/sample_medicine.png');
  // 1x1 transparent png or a base64 sample
  const sampleBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  fs.writeFileSync(testImagePath, Buffer.from(sampleBase64, 'base64'));

  // Upload image through hidden file input
  console.log('Uploading sample medicine image...');
  const fileInput = await page.$('input[type="file"]');
  if (!fileInput) {
    console.error('File input not found!');
  } else {
    await fileInput.setInputFiles(testImagePath);
    console.log('File attached! Waiting for analysis to finish...');
  }

  // Wait 15 seconds to let Gemini analyze
  await page.waitForTimeout(15000);

  // Take screenshot after upload
  await page.screenshot({ path: 'tests/screenshot_after_upload.png' });
  console.log('Saved tests/screenshot_after_upload.png');

  // Check page content
  const bodyText = await page.innerText('body');
  console.log('Body text length:', bodyText.length);
  console.log('Body text snippet (first 500 chars):\n', bodyText.substring(0, 500));

  // Check if "Extracted Clinical Scan" is present
  const hasResult = bodyText.includes('Extracted Clinical Scan') || bodyText.includes('Google Gemini AI OCR');
  console.log('Has Extracted Clinical Scan:', hasResult);

  // Check for any errors
  console.log('Page errors count:', pageErrors.length);
  if (pageErrors.length > 0) {
    console.log('Page errors:', pageErrors);
  }

  await browser.close();
}

runScanTest().catch(console.error);
