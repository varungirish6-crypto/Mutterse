const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const exe = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

async function verifyScanNavigationFlow() {
  console.log('====================================================');
  console.log('MUTTERSE ANDROID SCAN NAVIGATION & SCANNING FLOW TEST');
  console.log('====================================================\n');

  const browser = await chromium.launch({
    executablePath: exe,
    headless: true,
  });

  const page = await browser.newPage({
    viewport: { width: 390, height: 844 }, // Mobile phone viewport
  });

  const consoleErrors = [];
  const pageErrors = [];

  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      consoleErrors.push(msg.text());
      console.log('  🔴 Console Error:', msg.text());
    }
  });

  page.on('pageerror', (err) => {
    pageErrors.push(err.message);
    console.log('  💥 Page Error:', err.message);
  });

  // Step 1: Open app
  console.log('[Step 1] Loading app at http://localhost:5173...');
  await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });

  // Handle Login if shown
  const demoBtn = page.locator('text=Continue as Demo').first();
  if (await demoBtn.isVisible({ timeout: 2000 }).catch(() => false)) {
    console.log('  Tapping "Continue as Demo"...');
    await demoBtn.click();
    await page.waitForTimeout(1000);
  }

  // Step 2: Confirm we are on the Dashboard
  console.log('[Step 2] Checking Dashboard view...');
  const isDashboardGreeting = await page.isVisible('text=Good morning');
  console.log('  Dashboard active:', isDashboardGreeting);
  if (!isDashboardGreeting) {
    throw new Error('Expected to be on Dashboard screen initially.');
  }

  // Step 3: Check Bottom Navigation items: Dashboard, Scan, Care, Settings
  console.log('[Step 3] Checking Bottom Navigation buttons...');
  const dashboardBtn = page.locator('button[aria-label="Dashboard"]').first();
  const scanBtn = page.locator('button[aria-label="Scan"]').first();
  const careBtn = page.locator('button[aria-label="Care"]').first();
  const settingsBtn = page.locator('button[aria-label="Settings"]').first();

  const bottomNavButtonsExist = {
    dashboard: await dashboardBtn.isVisible(),
    scan: await scanBtn.isVisible(),
    care: await careBtn.isVisible(),
    settings: await settingsBtn.isVisible(),
  };
  console.log('  Bottom navigation items found:', bottomNavButtonsExist);

  if (!bottomNavButtonsExist.scan) {
    throw new Error('Scan button not found in bottom navigation!');
  }

  // Step 4: Tap the Scan button
  console.log('[Step 4] Tapping the "Scan" option in Bottom Navigation...');
  await scanBtn.click();
  await page.waitForTimeout(500);

  // Step 5: Verify that the Scan screen is registered and rendered!
  console.log('[Step 5] Verifying that the Scan screen is rendered...');
  const isScanHeaderVisible = await page.isVisible('text=AI Clinical Scanner');
  const isPackagingTabVisible = await page.isVisible('text=Medicine Packaging');
  const isGalleryUploadVisible = await page.isVisible('text=Gallery / Upload');
  const isOpenCameraVisible = await page.isVisible('text=Open Camera');

  console.log('  Scan screen elements verified:', {
    isScanHeaderVisible,
    isPackagingTabVisible,
    isGalleryUploadVisible,
    isOpenCameraVisible,
  });

  if (!isScanHeaderVisible || !isGalleryUploadVisible || !isOpenCameraVisible) {
    throw new Error('Scan screen failed to render after tapping Scan!');
  }
  console.log('  ✅ Scan button onClick successfully navigated to Scan screen!');

  // Step 6: Test Tab Switching back and forth (Dashboard -> Care -> Scan)
  console.log('[Step 6] Testing rapid tab navigation (Care -> Dashboard -> Scan)...');
  await careBtn.click();
  await page.waitForTimeout(300);
  const careActive = await page.isVisible('text=My Care Profile, text=Appointments & Care');

  await dashboardBtn.click();
  await page.waitForTimeout(300);
  const dashboardActiveAgain = await page.isVisible('text=Good morning');

  await scanBtn.click();
  await page.waitForTimeout(300);
  const scanActiveAgain = await page.isVisible('text=AI Clinical Scanner');

  console.log('  Tab switching reliability:', { careActive, dashboardActiveAgain, scanActiveAgain });
  if (!scanActiveAgain) {
    throw new Error('Tab switching failed to return to Scan screen.');
  }

  // Step 7: Test Image Selection & AI Processing
  console.log('[Step 7] Attaching test medicine packaging image...');
  const testImagePath = path.resolve('tests/sample_medicine.png');
  const sampleBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  fs.writeFileSync(testImagePath, Buffer.from(sampleBase64, 'base64'));

  const fileInput = await page.$('input[type="file"]');
  await fileInput.setInputFiles(testImagePath);
  console.log('  File attached. Waiting for Analyzing state...');

  // Step 8: Verify Analyzing State
  await page.waitForTimeout(400);
  const isAnalyzing = await page.isVisible('text=Reading Medicine Packaging…');
  console.log('  Analyzing loading state displayed:', isAnalyzing);

  // Step 9: Wait for AI response & Result Page
  console.log('[Step 9] Awaiting Gemini AI OCR result and Result Page render...');
  const resultHeader = page.getByText('Clinical Scan Result').first();
  await resultHeader.waitFor({ timeout: 25000 });
  console.log('  ✅ Result Page successfully loaded!');

  // Step 10: Verify all Result Page components
  console.log('[Step 10] Checking clinical fields on Result Page...');
  const hasTitle = await page.isVisible('h3');
  const hasIngredients = await page.isVisible('text=Active Ingredients');
  const hasDirections = await page.isVisible('text=Visible Label Directions');
  const hasStrength = await page.isVisible('text=Strength / Potency');
  const hasWarnings = await page.isVisible('text=Visible Warnings & Label Details');
  const hasDisclaimer = await page.isVisible('text=Required Medical Confirmation Notice');
  const hasChat = await page.isVisible('text=Ask Mutterse AI');
  const hasScanAnother = await page.isVisible('text=Scan Another');

  console.log('  Result Page inspection:', {
    hasTitle,
    hasIngredients,
    hasDirections,
    hasStrength,
    hasWarnings,
    hasDisclaimer,
    hasChat,
    hasScanAnother,
  });

  if (!hasIngredients || !hasDirections || !hasStrength || !hasChat) {
    throw new Error('Result Page is missing one or more required clinical elements.');
  }

  // Step 11: Return to scanner
  console.log('[Step 11] Tapping "Scan Another" to return to Scanner View...');
  await page.locator('button:has-text("Scan Another")').first().click();
  await page.waitForTimeout(500);
  const backToScanner = await page.isVisible('text=Gallery / Upload');
  console.log('  Returned to Scanner View:', backToScanner);
  if (!backToScanner) {
    throw new Error('Failed to return to Scanner View.');
  }

  // Step 12: Check console & page errors
  console.log('[Step 12] Checking runtime errors...');
  console.log('  Console Errors count:', consoleErrors.length);
  console.log('  Page Uncaught Errors:', pageErrors.length);

  if (pageErrors.length > 0) {
    throw new Error(`Uncaught runtime error: ${pageErrors.join('; ')}`);
  }

  console.log('\n====================================================');
  console.log('🎉 SCAN NAVIGATION & SCANNING FLOW 100% VERIFIED!');
  console.log('====================================================\n');

  await browser.close();
}

verifyScanNavigationFlow().catch((err) => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
