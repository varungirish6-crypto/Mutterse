const { chromium } = require('playwright');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: exe,
  });
  const page = await browser.newPage();
  await page.goto('http://localhost:5173');
  await page.waitForTimeout(1000);

  // If login page visible, click demo login
  const demoBtn = page.locator('button:has-text("Continue as Demo")');
  if (await demoBtn.isVisible()) {
    await demoBtn.click();
    await page.waitForTimeout(1000);
  }

  // Go to Scan tab
  await page.locator('nav button').nth(2).click();
  await page.waitForTimeout(1000);

  // Upload an image
  const fileInput = page.locator('input[type="file"]').first();
  await fileInput.setInputFiles('tests/sample_medicine.png');
  await page.waitForTimeout(1500);

  const chatCount = await page.locator('h3:has-text("Ask Mutterse AI")').count();
  console.log('AI Chat Box element count in DOM:', chatCount);
  if (chatCount > 0) {
    await page.locator('h3:has-text("Ask Mutterse AI")').scrollIntoViewIfNeeded();
    console.log('AI Chat Box visible after scroll:', await page.locator('h3:has-text("Ask Mutterse AI")').isVisible());
  }

  // Check if fixed text appears
  const bodyText = await page.textContent('body');
  const targetSnippet = 'Paracetamol (acetaminophen) is';
  const hasTarget = bodyText.includes(targetSnippet);
  console.log('Fixed result text rendered directly below scanner:', hasTarget);

  // Print exact matching paragraph
  const paragraphs = await page.$$eval('p', (els) => els.map((e) => e.innerText));
  const matched = paragraphs.find((p) => p.includes('Paracetamol (acetaminophen) is'));
  console.log('Matched Paragraph Content:', matched);

  await browser.close();
})();
