const { chromium } = require('playwright');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];
const exe = edgePaths.find((p) => fs.existsSync(p));

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: exe,
  });
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
  });
  await page.goto('http://localhost:5173');
  await page.waitForTimeout(1000);

  const demoBtn = page.locator('button:has-text("Continue as Demo")');
  if (await demoBtn.isVisible()) {
    await demoBtn.click();
    await page.waitForTimeout(1000);
  }

  // Go to Scan tab
  await page.locator('nav button').nth(2).click();
  await page.waitForTimeout(1000);

  // Check if banner text exists
  const pageContent = await page.textContent('body');
  const hasBannerHeader = pageContent.includes('Powered by Google Gemini');
  const hasBannerDesc = pageContent.includes('Extract active ingredients, dosage directions');
  console.log('Banner header present:', hasBannerHeader);
  console.log('Banner description present:', hasBannerDesc);

  // Check scanner elements
  console.log('Camera button present:', await page.locator('button:has-text("Take Photo")').isVisible());
  console.log('Gallery button present:', await page.locator('button:has-text("Gallery / Upload")').isVisible());
  console.log('Ask Mutterse AI present in DOM:', (await page.locator('h3:has-text("Ask Mutterse AI")').count()) > 0);

  await browser.close();
})();
